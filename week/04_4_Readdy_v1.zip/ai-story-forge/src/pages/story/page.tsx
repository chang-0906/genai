export default function StoryPage() {
  return (
    <div className="min-h-full bg-stone-50 flex items-center justify-center">
      <div className="text-center max-w-md px-8">
        <div className="w-20 h-20 flex items-center justify-center bg-violet-100 rounded-2xl mx-auto mb-6">
          <i className="ri-quill-pen-line text-violet-500 text-4xl" />
        </div>
        <h1 className="text-2xl font-bold text-stone-800 mb-3">故事生成</h1>
        <p className="text-stone-500 leading-relaxed mb-6">
          由 D LLM 驅動的故事生成功能即將推出。完成世界觀、角色與大綱的設定後，AI 將為你生成完整的故事文本，支援章節分段輸出。
        </p>
        <span className="inline-flex items-center gap-2 px-4 py-2 bg-violet-100 text-violet-700 rounded-full text-sm font-medium">
          <i className="ri-time-line" /> Phase 2 開發中
        </span>
      </div>
    </div>
  );
}
