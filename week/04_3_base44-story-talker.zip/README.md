# Story Talker — 部屬教學

## 簡介
Story Talker 是一套 AI 協作故事創作應用，使用 Dify.ai 作為 LLM 後端，讓你依序建立世界觀、角色、大綱，最終生成完整故事。

## 系統需求
- Node.js 18+
- Dify.ai 帳號（或自架 Dify）
- Base44 帳號（用於部屬本應用，免費方案即可）

## 快速部屬步驟

### 方法一：使用 Base44 平台（推薦，最快速）
1. 前往 https://base44.com 註冊帳號
2. 建立新應用
3. 在 Base44 的程式碼編輯器中，將此 zip 中 `src/` 目錄的所有檔案複製進去
4. 在 Base44 後台建立以下 Entity（實體）：
   - WorldSetting、Character、StoryOutline、Story、StoryChapter
   （欄位定義請參考 `src/entities/` 目錄下的 JSON schema）
5. 部屬後，前往應用內的「API 設定」頁面填入 Dify API Key

### 方法二：本地 Vite 開發（需有 Base44 App ID）
```bash
# 進入專案目錄
cd story-talker

# 安裝依賴
npm install

# 複製環境變數範本並填入你的 Base44 App ID
cp .env.example .env

# 啟動開發伺服器
npm run dev
```

## Dify API 設定
本應用使用 4 個 Dify Chatbot 或 Workflow：
| 代號 | 用途         |
|------|------------|
| A    | 世界觀生成   |
| B    | 角色生成     |
| C    | 故事大綱生成 |
| D    | 故事章節生成 |

每個 Dify 應用建立後，將其 **API Key** 與 **Base URL** 填入 Story Talker 的「API 設定」頁面。

## 資料備份
zip 包中的 `data/` 目錄包含你所有的創作資料（JSON 格式），可用於備份或遷移。

## 注意事項
- API Key 存於瀏覽器 localStorage，不會上傳至伺服器
- 所有故事資料儲存於 Base44 雲端資料庫

## 聯絡與支援
- Base44 文件：https://base44.com/docs
- Dify 文件：https://docs.dify.ai
