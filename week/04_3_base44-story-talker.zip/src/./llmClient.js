/**
 * LLM Client — supports OpenAI-compatible API and Dify API with streaming
 */

export async function streamLLM({ apiConfig, messages, onChunk, onDone, onError }) {
  if (apiConfig.type === 'openai') {
    await streamOpenAI({ apiConfig, messages, onChunk, onDone, onError });
  } else if (apiConfig.type === 'dify') {
    await streamDify({ apiConfig, messages, onChunk, onDone, onError });
  }
}

async function streamOpenAI({ apiConfig, messages, onChunk, onDone, onError }) {
  const { baseUrl, model, apiKey } = apiConfig;
  const url = `${baseUrl.replace(/\/$/, '')}/chat/completions`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      stream: true,
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    onError(new Error(`API Error ${response.status}: ${err}`));
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let fullText = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value, { stream: true });
    const lines = chunk.split('\n').filter(l => l.startsWith('data: '));

    for (const line of lines) {
      const data = line.replace('data: ', '').trim();
      if (data === '[DONE]') break;
      try {
        const json = JSON.parse(data);
        const delta = json.choices?.[0]?.delta?.content || '';
        if (delta) {
          fullText += delta;
          onChunk(delta, fullText);
        }
      } catch {}
    }
  }

  onDone(fullText);
}

async function streamDify({ apiConfig, messages, onChunk, onDone, onError }) {
  const { baseUrl, apiKey } = apiConfig;
  const url = `${baseUrl.replace(/\/$/, '')}/v1/chat-messages`;

  // Build query from messages — last user message is the query
  const userMessages = messages.filter(m => m.role === 'user');
  const systemMessages = messages.filter(m => m.role === 'system');
  const query = userMessages[userMessages.length - 1]?.content || '';
  const systemPrompt = systemMessages[0]?.content || '';

  // Build conversation history (exclude last user message)
  const history = [];
  let msgList = messages.filter(m => m.role !== 'system');
  for (let i = 0; i < msgList.length - 1; i += 2) {
    if (msgList[i]?.role === 'user' && msgList[i + 1]?.role === 'assistant') {
      history.push({ role: 'user', content: msgList[i].content });
      history.push({ role: 'assistant', content: msgList[i + 1].content });
    }
  }

  const body = {
    inputs: systemPrompt ? { system_prompt: systemPrompt } : {},
    query,
    response_mode: 'streaming',
    conversation_id: '',
    user: 'story-workshop-user',
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const err = await response.text();
    onError(new Error(`Dify API Error ${response.status}: ${err}`));
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let fullText = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value, { stream: true });
    const lines = chunk.split('\n').filter(l => l.startsWith('data: '));

    for (const line of lines) {
      const data = line.replace('data: ', '').trim();
      try {
        const json = JSON.parse(data);
        if (json.event === 'message') {
          const delta = json.answer || '';
          if (delta) {
            fullText += delta;
            onChunk(delta, fullText);
          }
        } else if (json.event === 'message_end') {
          break;
        }
      } catch {}
    }
  }

  onDone(fullText);
}