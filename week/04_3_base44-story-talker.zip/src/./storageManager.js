/**
 * Storage Manager — manages story projects in localStorage
 */

const PROJECTS_KEY = 'story_workshop_projects';
const SETTINGS_KEY = 'story_workshop_settings';

// ── Projects ──────────────────────────────────────────────

export function loadProjects() {
  try {
    const raw = localStorage.getItem(PROJECTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveProject(project) {
  const projects = loadProjects();
  const idx = projects.findIndex(p => p.id === project.id);
  const updated = { ...project, updatedAt: new Date().toISOString() };
  if (idx >= 0) {
    projects[idx] = updated;
  } else {
    projects.unshift(updated);
  }
  localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
  return updated;
}

export function deleteProject(id) {
  const projects = loadProjects().filter(p => p.id !== id);
  localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
}

export function createProject(title = '未命名故事', tags = []) {
  return {
    id: `proj_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    title,
    tags,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    versions: [],       // array of story versions
    currentVersion: 0,
    setup: {
      systemPromptA: '',
      systemPromptB: '',
      userPrompt: '',
      rounds: 3,
    },
    messages: [],       // full conversation history
    status: 'draft',    // draft | running | completed
  };
}

// ── Global Settings (API configs) ─────────────────────────

export function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    return raw ? JSON.parse(raw) : getDefaultSettings();
  } catch {
    return getDefaultSettings();
  }
}

export function saveSettings(settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function getDefaultSettings() {
  return {
    theme: 'dark',
    apiA: {
      type: 'openai',
      baseUrl: 'https://api.openai.com/v1',
      model: 'gpt-4o',
      apiKey: '',
    },
    apiB: {
      type: 'openai',
      baseUrl: 'https://api.openai.com/v1',
      model: 'gpt-4o',
      apiKey: '',
    },
  };
}