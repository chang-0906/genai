/**
 * Dify API Client — streaming chat-messages
 */

const SETTINGS_KEY = 'story_talker_api_settings';

export function loadApiSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    return raw ? JSON.parse(raw) : getDefaultApiSettings();
  } catch {
    return getDefaultApiSettings();
  }
}

export function saveApiSettings(settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function getDefaultApiSettings() {
  return {
    apiA: { baseUrl: 'https://api.dify.ai', apiKey: '', label: 'A — 世界觀設定' },
    apiB: { baseUrl: 'https://api.dify.ai', apiKey: '', label: 'B — 角色設定' },
    apiC: { baseUrl: 'https://api.dify.ai', apiKey: '', label: 'C — 大綱設定' },
    apiD: { baseUrl: 'https://api.dify.ai', apiKey: '', label: 'D — 故事生成' },
  };
}

/**
 * Stream from Dify API
 * @param {object} param0
 * @param {{ baseUrl: string, apiKey: string }} param0.apiConfig
 * @param {string} param0.query - the user prompt
 * @param {function} param0.onChunk - called with (delta, fullText)
 * @param {function} param0.onDone - called with fullText
 * @param {function} param0.onError - called with error
 */
export async function streamDify({ apiConfig, query, onChunk, onDone, onError }) {
  const url = `${apiConfig.baseUrl.replace(/\/$/, '')}/v1/chat-messages`;

  let response;
  try {
    response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiConfig.apiKey}`,
      },
      body: JSON.stringify({
        inputs: {},
        query,
        response_mode: 'streaming',
        conversation_id: '',
        user: 'story-talker-user',
      }),
    });
  } catch (err) {
    onError(new Error(`無法連線：${err.message}`));
    return;
  }

  if (!response.ok) {
    const errText = await response.text();
    onError(new Error(`API 錯誤 ${response.status}: ${errText}`));
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let fullText = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value, { stream: true });
    const lines = chunk.split('\n').filter(l => l.startsWith('data: '));

    for (const line of lines) {
      const data = line.replace('data: ', '').trim();
      try {
        const json = JSON.parse(data);
        if (json.event === 'message') {
          const delta = json.answer || '';
          if (delta) {
            fullText += delta;
            onChunk(delta, fullText);
          }
        } else if (json.event === 'message_end') {
          break;
        } else if (json.event === 'error') {
          onError(new Error(json.message || 'Dify 串流錯誤'));
          return;
        }
      } catch {}
    }
  }

  onDone(fullText);
}

/**
 * Convenience: returns a Promise<string> with the full response
 */
export function callDify({ apiConfig, query }) {
  return new Promise((resolve, reject) => {
    streamDify({
      apiConfig,
      query,
      onChunk: () => {},
      onDone: resolve,
      onError: reject,
    });
  });
}