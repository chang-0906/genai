/**
 * Export Manager — Markdown / TXT / HTML / PDF
 */

export function buildMarkdown(project, onlyB = false) {
  const title = project.title;
  const lines = [`# ${title}`, '', `> 建立於 ${new Date(project.createdAt).toLocaleString('zh-TW')}`, ''];

  const msgs = onlyB
    ? project.messages.filter(m => m.role === 'writer')
    : project.messages;

  for (const msg of msgs) {
    if (msg.role === 'director') {
      if (!onlyB) {
        lines.push(`### 🎬 導演 (A) — 第 ${msg.round} 回合`);
        lines.push('');
        lines.push(msg.content);
        lines.push('');
        lines.push('---');
        lines.push('');
      }
    } else if (msg.role === 'writer') {
      lines.push(`### ✍️ 作家 (B) — 第 ${msg.round} 回合`);
      lines.push('');
      lines.push(msg.content);
      lines.push('');
      lines.push('---');
      lines.push('');
    }
  }

  return lines.join('\n');
}

export function exportAsMarkdown(project, onlyB = false) {
  const md = buildMarkdown(project, onlyB);
  downloadText(md, `${project.title}.md`, 'text/markdown');
}

export function exportAsTxt(project, onlyB = false) {
  const md = buildMarkdown(project, onlyB);
  const txt = md.replace(/#{1,6} /g, '').replace(/---/g, '──────────────────');
  downloadText(txt, `${project.title}.txt`, 'text/plain');
}

export function exportAsHtml(project, onlyB = false) {
  const msgs = onlyB
    ? project.messages.filter(m => m.role === 'writer')
    : project.messages;

  const bubbles = msgs.map(msg => {
    if (msg.role === 'director') {
      return `
        <div style="display:flex;justify-content:flex-end;margin:16px 0;">
          <div style="max-width:70%;background:#2a1e0e;border:1px solid #8b6914;border-radius:12px;padding:16px;color:#e8d5a0;">
            <div style="font-size:11px;color:#a08030;margin-bottom:8px;">🎬 導演 (A) — 第 ${msg.round} 回合</div>
            <div style="white-space:pre-wrap;font-family:serif;line-height:1.8;">${escapeHtml(msg.content)}</div>
          </div>
        </div>`;
    } else {
      return `
        <div style="display:flex;justify-content:flex-start;margin:16px 0;">
          <div style="max-width:70%;background:#0e1a2a;border:1px solid #1e4a7a;border-radius:12px;padding:16px;color:#a8c8e8;">
            <div style="font-size:11px;color:#3a7abf;margin-bottom:8px;">✍️ 作家 (B) — 第 ${msg.round} 回合</div>
            <div style="white-space:pre-wrap;font-family:serif;line-height:1.8;">${escapeHtml(msg.content)}</div>
          </div>
        </div>`;
    }
  }).join('');

  const html = `<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<title>${escapeHtml(project.title)}</title>
<style>
  body { background:#0d0a07; color:#e0d0b0; font-family: 'Noto Serif TC', serif; max-width:900px; margin:0 auto; padding:40px 20px; }
  h1 { color:#d4a840; border-bottom:1px solid #3a2a10; padding-bottom:16px; }
  .meta { color:#806030; font-size:13px; margin-bottom:32px; }
</style>
</head>
<body>
<h1>${escapeHtml(project.title)}</h1>
<div class="meta">建立於 ${new Date(project.createdAt).toLocaleString('zh-TW')}</div>
${bubbles}
</body>
</html>`;

  downloadText(html, `${project.title}.html`, 'text/html');
}

export async function exportAsPdf(project, onlyB = false) {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });

  const msgs = onlyB
    ? project.messages.filter(m => m.role === 'writer')
    : project.messages;

  doc.setFontSize(18);
  doc.setTextColor(180, 140, 40);
  doc.text(project.title, 20, 20);

  let y = 35;
  doc.setFontSize(10);
  doc.setTextColor(120, 100, 60);
  doc.text(`建立於 ${new Date(project.createdAt).toLocaleString('zh-TW')}`, 20, y);
  y += 12;

  for (const msg of msgs) {
    const label = msg.role === 'director'
      ? `[導演 A — 第 ${msg.round} 回合]`
      : `[作家 B — 第 ${msg.round} 回合]`;

    doc.setFontSize(10);
    doc.setTextColor(msg.role === 'director' ? 180 : 80, msg.role === 'director' ? 120 : 140, msg.role === 'director' ? 40 : 200);
    doc.text(label, 20, y);
    y += 6;

    doc.setFontSize(9);
    doc.setTextColor(200, 190, 170);

    const lines = doc.splitTextToSize(msg.content, 170);
    for (const line of lines) {
      if (y > 275) { doc.addPage(); y = 20; }
      doc.text(line, 20, y);
      y += 5;
    }
    y += 8;
  }

  doc.save(`${project.title}.pdf`);
}

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function downloadText(content, filename, mimeType) {
  const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}