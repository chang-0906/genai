/**
 * Prompt builders for each LLM
 */

export function buildWorldFromIdeaPrompt(idea) {
  return `這是對於故事世界觀設定的想法：
{
${idea}
}

請依據上述的設定，設計出完整豐富的故事世界觀，包含地理環境、社會結構、歷史背景、文化習俗、魔法或科技體系（若適用）等面向，以條列式或段落方式呈現。`;
}

export function buildWorldFromNovelPrompt(novel) {
  return `這是對於故事世界觀設定的現有故事：
{
${novel}
}

請依據上述的設定，統整歸納出小說中世界的世界觀，包含地理環境、社會結構、歷史背景、文化習俗、特殊設定等，以清晰的結構呈現。`;
}

export function buildCharactersPrompt({ worldContent, count }) {
  return `這是故事的世界觀設定：
{
${worldContent}
}

請依據上述的設定，設計 ${count} 個獨特的角色，每個角色請分別提供：
1. 姓名
2. 年齡
3. 身分背景描述（包含個性、經歷、動機、與世界觀的關聯）

請以清晰的格式輸出每個角色，並用 --- 分隔各角色。`;
}

export function buildOutlinePrompt({ worldContent, charactersContent, protagonists, lengthLabel, lengthDesc }) {
  return `這是故事的世界觀設定：
{
${worldContent}
}

這是故事的人物設定：
{
${charactersContent}
}

請依據上述的世界觀與人物設定，以主角「${protagonists}」為中心，進行故事設計。

請設計一篇${lengthLabel}（${lengthDesc}）的故事內容。${lengthDesc.includes('章節') ? '請提供各章節的標題與故事大綱。' : '請提供故事的整體大綱與情節走向。'}

輸出格式請結構清晰，包含故事主題、核心衝突，以及${lengthDesc.includes('章節') ? '各章節標題與大綱' : '故事大綱'}。`;
}

export function buildStoryPrompt({ worldContent, charactersContent, outlineContent, wordCount }) {
  return `這是故事的世界觀設定：
{
${worldContent}
}

這是故事的人物設定：
{
${charactersContent}
}

這是故事的情節與大綱設定：
{
${outlineContent}
}

請依據上述的世界觀與人物設定，以及故事情節，進行故事創作，請撰寫約 ${wordCount} 字的故事內容。文筆請優美流暢，情節豐富生動。`;
}

export function buildChapterPrompt({ worldContent, charactersContent, outlineContent, chapterTitle, chapterOutline, chapterIndex, totalChapters, wordCount }) {
  return `這是故事的世界觀設定：
{
${worldContent}
}

這是故事的人物設定：
{
${charactersContent}
}

這是故事的整體情節與大綱設定：
{
${outlineContent}
}

請依據上述設定，創作第 ${chapterIndex} 章（共 ${totalChapters} 章）：
章節標題：${chapterTitle}
章節大綱：${chapterOutline}

請撰寫約 ${wordCount} 字的章節內容，文筆優美流暢，情節豐富，符合整體故事風格。`;
}

export const LENGTH_CONFIG = {
  ultra_short: { label: '超短篇', wordCount: 500, chapters: 0, desc: '500字，無章節，設計故事大綱' },
  short:       { label: '短篇',   wordCount: 5000, chapters: 0, desc: '5000字，無章節，設計故事大綱' },
  medium:      { label: '中篇',   wordCount: 15000, chapters: 3, desc: '15000字，分3章節，設計章節標題與大綱' },
  long:        { label: '長篇',   wordCount: 40000, chapters: 10, desc: '40000字，分10章節，設計章節標題與大綱' },
  ultra_long:  { label: '超長篇', wordCount: 100000, chapters: 20, desc: '100000字，分20章節，設計章節標題與大綱' },
};