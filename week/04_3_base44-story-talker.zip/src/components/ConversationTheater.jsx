import { useEffect, useRef } from 'react';
import MessageBubble from './MessageBubble';
import { Loader2 } from 'lucide-react';

export default function ConversationTheater({ messages, streamingMessage, isRunning, autoScroll }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    if (autoScroll) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, streamingMessage, autoScroll]);

  if (messages.length === 0 && !isRunning) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-12 select-none">
        <div className="text-6xl mb-6 opacity-40">🎭</div>
        <p className="text-muted-foreground text-sm font-serif">舞台尚未開演</p>
        <p className="text-muted-foreground/50 text-xs mt-2">完成設定後，按下「開始創作」點亮舞台</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      {messages.map((msg, idx) => (
        <MessageBubble key={idx} message={msg} isStreaming={false} />
      ))}

      {streamingMessage && (
        <MessageBubble message={streamingMessage} isStreaming={true} />
      )}

      {isRunning && !streamingMessage && (
        <div className="flex justify-center py-4">
          <div className="flex items-center gap-3 text-muted-foreground text-sm">
            <Loader2 className="w-4 h-4 animate-spin text-gold" />
            <span className="font-serif">正在思考中…</span>
          </div>
        </div>
      )}

      <div ref={bottomRef} />
    </div>
  );
}