import { Loader2, X } from 'lucide-react';

export default function StreamingModal({ title, content, isStreaming, onClose, onConfirm }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[80vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-3">
            {isStreaming && <Loader2 className="w-4 h-4 animate-spin text-gold" />}
            <h3 className="font-serif text-base">{title}</h3>
          </div>
          {!isStreaming && (
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          <p className={`text-sm leading-relaxed story-prose whitespace-pre-wrap ${isStreaming ? 'streaming-cursor' : ''}`}>
            {content || (isStreaming ? '' : '（無內容）')}
          </p>
        </div>

        {/* Footer */}
        {!isStreaming && (
          <div className="px-6 py-4 border-t border-border flex justify-end gap-3 flex-shrink-0">
            <button onClick={onClose} className="px-4 py-2 text-sm rounded-xl bg-muted text-muted-foreground hover:bg-muted/80 transition-colors">
              丟棄
            </button>
            <button onClick={onConfirm} className="px-5 py-2 text-sm rounded-xl bg-primary text-primary-foreground hover:opacity-90 transition-opacity font-medium">
              確認保存
            </button>
          </div>
        )}
      </div>
    </div>
  );
}