import { useState } from 'react';
import { Edit3, Archive, ArchiveRestore, Trash2, ChevronDown, ChevronUp } from 'lucide-react';

export default function CardItem({ title, subtitle, content, tags = [], archived = false, onEdit, onArchive, onDelete, children, accent = 'gold' }) {
  const [expanded, setExpanded] = useState(false);
  const colorMap = {
    gold: 'border-[hsl(var(--director-border))] bg-[hsl(var(--director-bg))]',
    blue: 'border-[hsl(var(--writer-border))] bg-[hsl(var(--writer-bg))]',
    default: 'border-border bg-card',
  };

  return (
    <div className={`rounded-2xl border ${colorMap[accent] || colorMap.default} transition-all ${archived ? 'opacity-60' : ''}`}>
      <div className="flex items-start gap-3 p-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-serif font-medium text-sm">{title}</span>
            {subtitle && <span className="text-xs text-muted-foreground">{subtitle}</span>}
            {archived && <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">已封存</span>}
          </div>
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {tags.map(t => (
                <span key={t} className="text-xs bg-accent/60 text-accent-foreground px-2 py-0.5 rounded-full">{t}</span>
              ))}
            </div>
          )}
          {content && (
            <p className={`text-xs text-muted-foreground mt-2 leading-relaxed ${expanded ? '' : 'line-clamp-2'}`}>
              {content}
            </p>
          )}
          {children && <div className="mt-2">{children}</div>}
        </div>

        <div className="flex items-center gap-1 flex-shrink-0">
          {content && content.length > 120 && (
            <button onClick={() => setExpanded(e => !e)} className="p-1.5 rounded-lg hover:bg-muted/60 text-muted-foreground transition-colors">
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
          {onEdit && (
            <button onClick={onEdit} className="p-1.5 rounded-lg hover:bg-muted/60 text-muted-foreground hover:text-foreground transition-colors">
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          )}
          {onArchive && (
            <button onClick={onArchive} className="p-1.5 rounded-lg hover:bg-muted/60 text-muted-foreground hover:text-amber-400 transition-colors">
              {archived ? <ArchiveRestore className="w-3.5 h-3.5" /> : <Archive className="w-3.5 h-3.5" />}
            </button>
          )}
          {onDelete && (
            <button onClick={onDelete} className="p-1.5 rounded-lg hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}