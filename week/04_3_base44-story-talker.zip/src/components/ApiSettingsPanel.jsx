import { useState } from 'react';
import { Settings, Eye, EyeOff, ChevronDown, ChevronUp } from 'lucide-react';

const defaultApi = { type: 'openai', baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o', apiKey: '', difyBaseUrl: 'https://api.dify.ai', difyApiKey: '' };

function ApiForm({ label, color, value, onChange }) {
  const [showKey, setShowKey] = useState(false);
  const [open, setOpen] = useState(false);
  const v = { ...defaultApi, ...value };

  const update = (field, val) => onChange({ ...v, [field]: val });

  return (
    <div className={`rounded-xl border ${color === 'gold' ? 'border-[hsl(var(--director-border))] bg-[hsl(var(--director-bg))]' : 'border-[hsl(var(--writer-border))] bg-[hsl(var(--writer-bg))]'} overflow-hidden`}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-5 py-4 hover:bg-white/5 transition-colors"
      >
        <div className="flex items-center gap-3">
          <span className={`text-sm font-medium ${color === 'gold' ? 'text-amber-400' : 'text-sky-400'}`}>{label}</span>
          <span className="text-xs text-muted-foreground bg-muted/60 px-2 py-0.5 rounded-full">
            {v.type === 'openai' ? v.model || 'OpenAI 相容' : 'Dify'}
          </span>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>

      {open && (
        <div className="px-5 pb-5 space-y-4 border-t border-border/40">
          {/* Type toggle */}
          <div className="flex gap-2 pt-4">
            {['openai', 'dify'].map(t => (
              <button
                key={t}
                onClick={() => update('type', t)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${v.type === t ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-muted/80'}`}
              >
                {t === 'openai' ? 'OpenAI 相容' : 'Dify'}
              </button>
            ))}
          </div>

          {v.type === 'openai' ? (
            <>
              <Field label="Base URL" value={v.baseUrl} onChange={val => update('baseUrl', val)} placeholder="https://api.openai.com/v1" />
              <Field label="模型名稱" value={v.model} onChange={val => update('model', val)} placeholder="gpt-4o" />
              <div className="space-y-1.5">
                <label className="text-xs text-muted-foreground">API Key</label>
                <div className="relative">
                  <input
                    type={showKey ? 'text' : 'password'}
                    value={v.apiKey}
                    onChange={e => update('apiKey', e.target.value)}
                    placeholder="sk-..."
                    className="w-full bg-input border border-border rounded-lg px-3 py-2 text-sm pr-10 focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                  <button onClick={() => setShowKey(!showKey)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                    {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </>
          ) : (
            <>
              <Field label="Dify Base URL" value={v.difyBaseUrl} onChange={val => update('difyBaseUrl', val)} placeholder="https://api.dify.ai" />
              <div className="space-y-1.5">
                <label className="text-xs text-muted-foreground">Dify API Key</label>
                <div className="relative">
                  <input
                    type={showKey ? 'text' : 'password'}
                    value={v.difyApiKey}
                    onChange={e => update('difyApiKey', e.target.value)}
                    placeholder="app-..."
                    className="w-full bg-input border border-border rounded-lg px-3 py-2 text-sm pr-10 focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                  <button onClick={() => setShowKey(!showKey)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                    {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function Field({ label, value, onChange, placeholder }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs text-muted-foreground">{label}</label>
      <input
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-input border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring"
      />
    </div>
  );
}

export default function ApiSettingsPanel({ settings, onSave }) {
  const [local, setLocal] = useState(settings);

  const handleSave = () => onSave(local);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-6">
        <Settings className="w-5 h-5 text-gold" />
        <h2 className="text-lg font-serif text-foreground">API 設定</h2>
      </div>

      <ApiForm
        label="🎬 A — 導演 AI"
        color="gold"
        value={local.apiA}
        onChange={v => setLocal({ ...local, apiA: v })}
      />

      <ApiForm
        label="✍️ B — 作家 AI"
        color="blue"
        value={local.apiB}
        onChange={v => setLocal({ ...local, apiB: v })}
      />

      <button
        onClick={handleSave}
        className="w-full py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity mt-2"
      >
        儲存設定
      </button>
    </div>
  );
}