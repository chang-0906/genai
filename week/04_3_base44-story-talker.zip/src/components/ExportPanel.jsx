import { useState } from 'react';
import { Download, FileText, Code2, Globe, BookOpen } from 'lucide-react';
import { exportAsMarkdown, exportAsTxt, exportAsHtml, exportAsPdf } from '../lib/exportManager';

export default function ExportPanel({ project, onClose }) {
  const [onlyB, setOnlyB] = useState(false);
  const [exporting, setExporting] = useState('');

  const handle = async (type) => {
    setExporting(type);
    try {
      if (type === 'md') exportAsMarkdown(project, onlyB);
      else if (type === 'txt') exportAsTxt(project, onlyB);
      else if (type === 'html') exportAsHtml(project, onlyB);
      else if (type === 'pdf') await exportAsPdf(project, onlyB);
    } finally {
      setExporting('');
    }
  };

  const formats = [
    { id: 'md', label: 'Markdown', icon: FileText, ext: '.md' },
    { id: 'txt', label: '純文字', icon: BookOpen, ext: '.txt' },
    { id: 'html', label: 'HTML 對話頁面', icon: Globe, ext: '.html' },
    { id: 'pdf', label: 'PDF', icon: Code2, ext: '.pdf' },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <Download className="w-5 h-5 text-gold" />
        <h3 className="text-base font-serif">匯出故事</h3>
      </div>

      {/* Toggle A+B or only B */}
      <div className="flex rounded-xl overflow-hidden border border-border">
        <button
          onClick={() => setOnlyB(false)}
          className={`flex-1 py-2.5 text-sm transition-colors ${!onlyB ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'}`}
        >
          全部（A + B）
        </button>
        <button
          onClick={() => setOnlyB(true)}
          className={`flex-1 py-2.5 text-sm transition-colors ${onlyB ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'}`}
        >
          僅故事（B）
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {formats.map(f => {
          const Icon = f.icon;
          const loading = exporting === f.id;
          return (
            <button
              key={f.id}
              onClick={() => handle(f.id)}
              disabled={loading}
              className="flex flex-col items-center gap-2 p-4 rounded-xl border border-border bg-card hover:border-gold/40 hover:bg-accent transition-all disabled:opacity-50"
            >
              <Icon className="w-5 h-5 text-gold" />
              <span className="text-sm font-medium">{f.label}</span>
              <span className="text-xs text-muted-foreground">{f.ext}</span>
            </button>
          );
        })}
      </div>

      {onClose && (
        <button onClick={onClose} className="w-full py-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
          關閉
        </button>
      )}
    </div>
  );
}