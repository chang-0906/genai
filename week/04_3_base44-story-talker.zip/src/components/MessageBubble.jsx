import ReactMarkdown from 'react-markdown';

export default function MessageBubble({ message, isStreaming }) {
  const isDirector = message.role === 'director';

  return (
    <div className={`flex ${isDirector ? 'justify-end' : 'justify-start'} animate-fade-in`}>
      <div className={`max-w-[72%] ${isDirector ? 'animate-slide-in-right' : 'animate-slide-in-left'}`}>
        {/* Label */}
        <div className={`text-xs mb-2 flex items-center gap-1.5 ${isDirector ? 'justify-end text-amber-500/70' : 'justify-start text-sky-400/70'}`}>
          <span>{isDirector ? '🎬 導演 A' : '✍️ 作家 B'}</span>
          <span className="text-muted-foreground/50">第 {message.round} 回合</span>
        </div>

        {/* Bubble */}
        <div
          className={`rounded-2xl px-5 py-4 ${
            isDirector
              ? 'bg-[hsl(var(--director-bubble))] border border-[hsl(var(--director-border))] director-glow'
              : 'bg-[hsl(var(--writer-bubble))] border border-[hsl(var(--writer-border))] writer-glow'
          } ${isStreaming ? 'streaming-cursor' : ''}`}
        >
          <div className={`story-prose text-sm leading-relaxed ${isDirector ? 'text-amber-100/85' : 'text-sky-100/90'}`}>
            <ReactMarkdown
              components={{
                p: ({ children }) => <p className="mb-3 last:mb-0">{children}</p>,
                strong: ({ children }) => <strong className="font-semibold text-foreground">{children}</strong>,
                em: ({ children }) => <em className="italic opacity-90">{children}</em>,
                ul: ({ children }) => <ul className="list-disc ml-4 mb-2 space-y-1">{children}</ul>,
                ol: ({ children }) => <ol className="list-decimal ml-4 mb-2 space-y-1">{children}</ol>,
                li: ({ children }) => <li>{children}</li>,
                h1: ({ children }) => <h1 className="text-lg font-semibold mb-2">{children}</h1>,
                h2: ({ children }) => <h2 className="text-base font-semibold mb-2">{children}</h2>,
                h3: ({ children }) => <h3 className="text-sm font-semibold mb-1">{children}</h3>,
                blockquote: ({ children }) => (
                  <blockquote className="border-l-2 border-current/30 pl-3 my-2 opacity-80">{children}</blockquote>
                ),
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>
        </div>
      </div>
    </div>
  );
}