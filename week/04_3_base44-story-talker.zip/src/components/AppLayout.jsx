import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Globe, Users, BookOpen, Feather, Settings, Archive, Download, Loader2 } from 'lucide-react';
import { downloadProjectZip } from '../lib/projectDownload';

const NAV = [
  { to: '/', icon: Globe, label: '世界觀' },
  { to: '/characters', icon: Users, label: '角色' },
  { to: '/outlines', icon: BookOpen, label: '大綱' },
  { to: '/stories', icon: Feather, label: '故事' },
  { to: '/archive', icon: Archive, label: '封存箱' },
  { to: '/settings', icon: Settings, label: 'API 設定' },
];

export default function AppLayout({ children }) {
  const { pathname } = useLocation();
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    await downloadProjectZip();
    setDownloading(false);
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <aside className="w-16 md:w-52 flex-shrink-0 border-r border-border/50 bg-[hsl(var(--sidebar-background))] flex flex-col">
        <div className="px-4 py-5 border-b border-border/50 hidden md:block">
          <h1 className="font-serif text-base text-gold tracking-wide">Story Talker</h1>
          <p className="text-xs text-muted-foreground mt-0.5">AI 故事共創工坊</p>
        </div>
        <div className="text-2xl py-4 flex justify-center md:hidden">🎭</div>

        <nav className="flex-1 py-4 space-y-1 px-2">
          {NAV.map(({ to, icon: Icon, label }) => {
            const active = pathname === to || (to !== '/' && pathname.startsWith(to));
            return (
              <Link
                key={to}
                to={to}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors text-sm ${
                  active
                    ? 'bg-accent text-accent-foreground font-medium'
                    : 'text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] hover:text-[hsl(var(--sidebar-accent-foreground))]'
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="hidden md:block">{label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Download button */}
        <div className="px-2 pb-4">
          <button
            onClick={handleDownload}
            disabled={downloading}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors text-sm w-full text-[hsl(var(--sidebar-foreground))] hover:bg-[hsl(var(--sidebar-accent))] hover:text-gold disabled:opacity-50"
          >
            {downloading ? <Loader2 className="w-4 h-4 flex-shrink-0 animate-spin" /> : <Download className="w-4 h-4 flex-shrink-0" />}
            <span className="hidden md:block">{downloading ? '下載中…' : '項目下載'}</span>
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto min-h-screen">
        {children}
      </main>
    </div>
  );
}