import { useState, useEffect } from 'react';
import { Plus, Globe, Loader2, Wand2, FileText, PenLine, Check, Trash2, Archive, ArchiveRestore } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { loadApiSettings } from '../lib/difyClient';
import { buildWorldFromIdeaPrompt, buildWorldFromNovelPrompt } from '../lib/prompts';
import AppLayout from '../components/AppLayout';
import CardItem from '../components/CardItem';
import StreamingModal from '../components/StreamingModal';

const METHODS = [
  { id: 'manual', icon: PenLine, label: '手動建立', desc: '自行從零開始進行細部設定' },
  { id: 'ai', icon: Wand2, label: 'AI 延伸拓展', desc: '提出想法，由 A LLM 延伸設定' },
  { id: 'extract', icon: FileText, label: '從故事擷取', desc: '上傳小說，由 A LLM 提取世界觀' },
];

export default function WorldSettings() {
  const [worlds, setWorlds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState(null);
  const [method, setMethod] = useState('manual');
  const [formData, setFormData] = useState({ title: '', idea: '', novel: '', content: '' });
  const [streaming, setStreaming] = useState(false);
  const [streamContent, setStreamContent] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({ title: '', content: '' });
  const [showArchived, setShowArchived] = useState(false);
  const [selected, setSelected] = useState(new Set());

  useEffect(() => { fetchWorlds(); }, []);

  const fetchWorlds = async () => {
    setLoading(true);
    const data = await base44.entities.WorldSetting.list('-updated_date');
    setWorlds(data);
    setLoading(false);
  };

  const handleGenerate = async () => {
    const settings = loadApiSettings();
    const apiA = settings.apiA;
    if (!apiA.apiKey) { alert('請先在 API 設定中填入 A 模型的 API Key'); return; }

    let query = '';
    if (method === 'ai') {
      if (!formData.idea.trim()) return;
      query = buildWorldFromIdeaPrompt(formData.idea);
    } else if (method === 'extract') {
      if (!formData.novel.trim()) return;
      query = buildWorldFromNovelPrompt(formData.novel);
    }

    setStreaming(true);
    setStreamContent('');
    setShowModal(true);

    try {
      const url = `${apiA.baseUrl.replace(/\/$/, '')}/v1/chat-messages`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiA.apiKey}` },
        body: JSON.stringify({ inputs: {}, query, response_mode: 'streaming', conversation_id: '', user: 'story-talker' }),
      });
      if (!response.ok) throw new Error(`API 錯誤 ${response.status}`);
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let full = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        for (const line of chunk.split('\n').filter(l => l.startsWith('data: '))) {
          const data = line.replace('data: ', '').trim();
          try {
            const json = JSON.parse(data);
            if (json.event === 'message' && json.answer) { full += json.answer; setStreamContent(full); }
          } catch {}
        }
      }
    } catch (err) {
      setStreamContent(`錯誤：${err.message}`);
    }
    setStreaming(false);
  };

  const handleSaveGenerated = async () => {
    const title = formData.title || '未命名世界觀';
    await base44.entities.WorldSetting.create({ title, content: streamContent, method, archived: false, tags: [] });
    setShowModal(false);
    setMode(null);
    resetForm();
    fetchWorlds();
  };

  const handleSaveManual = async () => {
    if (!formData.content.trim()) return;
    const title = formData.title || '未命名世界觀';
    await base44.entities.WorldSetting.create({ title, content: formData.content, method: 'manual', archived: false, tags: [] });
    setMode(null);
    resetForm();
    fetchWorlds();
  };

  const handleArchive = async (w) => {
    await base44.entities.WorldSetting.update(w.id, { archived: !w.archived });
    fetchWorlds();
  };

  const handleDelete = async (id) => {
    if (!confirm('確定刪除？')) return;
    await base44.entities.WorldSetting.delete(id);
    fetchWorlds();
  };

  const handleEditSave = async () => {
    await base44.entities.WorldSetting.update(editingId, { title: editData.title, content: editData.content });
    setEditingId(null);
    fetchWorlds();
  };

  // Multi-select batch actions
  const toggleSelect = (id) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const handleBatchArchive = async () => {
    const isArchiving = !showArchived;
    for (const id of selected) {
      await base44.entities.WorldSetting.update(id, { archived: isArchiving });
    }
    setSelected(new Set());
    fetchWorlds();
  };

  const handleBatchDelete = async () => {
    if (!confirm(`確定刪除選取的 ${selected.size} 個世界觀？`)) return;
    for (const id of selected) await base44.entities.WorldSetting.delete(id);
    setSelected(new Set());
    fetchWorlds();
  };

  const resetForm = () => setFormData({ title: '', idea: '', novel: '', content: '' });

  const visible = worlds.filter(w => showArchived ? w.archived : !w.archived);

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto px-6 py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Globe className="w-6 h-6 text-gold" />
            <div>
              <h1 className="font-serif text-xl">世界觀設定</h1>
              <p className="text-xs text-muted-foreground mt-0.5">使用 A LLM 建立故事世界</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowArchived(s => !s)} className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${showArchived ? 'border-gold/40 text-gold bg-accent' : 'border-border text-muted-foreground'}`}>
              {showArchived ? '返回列表' : '封存箱'}
            </button>
            {!mode && (
              <button onClick={() => setMode('create')} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity">
                <Plus className="w-4 h-4" />新增
              </button>
            )}
          </div>
        </div>

        {/* Batch actions */}
        {selected.size > 0 && (
          <div className="flex items-center gap-3 bg-accent border border-gold/30 rounded-xl px-4 py-2.5 animate-fade-in">
            <span className="text-xs text-gold font-medium">已選取 {selected.size} 個</span>
            <div className="flex gap-2 ml-auto">
              <button onClick={handleBatchArchive} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-muted hover:bg-muted/80 text-foreground transition-colors">
                {showArchived ? <ArchiveRestore className="w-3.5 h-3.5" /> : <Archive className="w-3.5 h-3.5" />}
                {showArchived ? '取消封存' : '封存'}
              </button>
              <button onClick={handleBatchDelete} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-destructive/20 hover:bg-destructive/30 text-destructive transition-colors">
                <Trash2 className="w-3.5 h-3.5" />刪除
              </button>
              <button onClick={() => setSelected(new Set())} className="text-xs px-3 py-1.5 rounded-lg bg-muted text-muted-foreground hover:bg-muted/80">取消</button>
            </div>
          </div>
        )}

        {/* Create Form */}
        {mode === 'create' && (
          <div className="bg-card border border-border rounded-2xl p-6 space-y-5 animate-fade-in">
            <h2 className="font-serif text-base text-gold">新增世界觀</h2>
            <div className="grid grid-cols-3 gap-3">
              {METHODS.map(m => (
                <button key={m.id} onClick={() => setMethod(m.id)}
                  className={`flex flex-col items-center gap-2 p-3 rounded-xl border text-center transition-all ${method === m.id ? 'border-gold bg-accent text-foreground' : 'border-border text-muted-foreground hover:border-border/80'}`}>
                  <m.icon className="w-5 h-5" />
                  <span className="text-xs font-medium">{m.label}</span>
                  <span className="text-xs opacity-70 leading-tight">{m.desc}</span>
                </button>
              ))}
            </div>
            <input type="text" value={formData.title} onChange={e => setFormData(f => ({ ...f, title: e.target.value }))}
              placeholder="世界觀標題（選填）"
              className="w-full bg-input border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            {method === 'manual' && (
              <textarea value={formData.content} onChange={e => setFormData(f => ({ ...f, content: e.target.value }))}
                placeholder="請在此直接輸入世界觀設定的內容…" rows={8}
                className="w-full bg-input border border-border rounded-xl px-4 py-3 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring" />
            )}
            {method === 'ai' && (
              <textarea value={formData.idea} onChange={e => setFormData(f => ({ ...f, idea: e.target.value }))}
                placeholder="請描述你對這個世界觀的想法…" rows={6}
                className="w-full bg-input border border-border rounded-xl px-4 py-3 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring" />
            )}
            {method === 'extract' && (
              <textarea value={formData.novel} onChange={e => setFormData(f => ({ ...f, novel: e.target.value }))}
                placeholder="請貼入現有的小說或故事內容，由 AI 提取世界觀…" rows={8}
                className="w-full bg-input border border-border rounded-xl px-4 py-3 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring" />
            )}
            <div className="flex gap-3">
              {method === 'manual' ? (
                <button onClick={handleSaveManual} className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity">儲存</button>
              ) : (
                <button onClick={handleGenerate} disabled={streaming}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50">
                  {streaming ? <><Loader2 className="w-4 h-4 animate-spin" />生成中…</> : <><Wand2 className="w-4 h-4" />由 AI 生成</>}
                </button>
              )}
              <button onClick={() => { setMode(null); resetForm(); }} className="px-5 py-2.5 bg-muted text-muted-foreground rounded-xl text-sm hover:bg-muted/80 transition-colors">取消</button>
            </div>
          </div>
        )}

        {/* Edit inline */}
        {editingId && (
          <div className="bg-card border border-gold/30 rounded-2xl p-5 space-y-3 animate-fade-in">
            <h3 className="font-serif text-sm text-gold">編輯世界觀</h3>
            <input value={editData.title} onChange={e => setEditData(d => ({ ...d, title: e.target.value }))}
              placeholder="標題"
              className="w-full bg-input border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <textarea value={editData.content} onChange={e => setEditData(d => ({ ...d, content: e.target.value }))} rows={8}
              className="w-full bg-input border border-border rounded-xl px-4 py-3 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring" />
            <div className="flex gap-3">
              <button onClick={handleEditSave} className="flex-1 py-2 bg-primary text-primary-foreground rounded-xl text-sm hover:opacity-90">儲存</button>
              <button onClick={() => setEditingId(null)} className="px-4 py-2 bg-muted text-muted-foreground rounded-xl text-sm">取消</button>
            </div>
          </div>
        )}

        {/* List */}
        {loading ? (
          <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : visible.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground font-serif">
            {showArchived ? '封存箱是空的' : '尚無世界觀，點擊「新增」開始創作'}
          </div>
        ) : (
          <div className="space-y-3">
            {visible.map(w => (
              <div key={w.id} className="flex items-start gap-2">
                <button
                  onClick={() => toggleSelect(w.id)}
                  className={`mt-4 flex-shrink-0 w-5 h-5 rounded border transition-colors flex items-center justify-center ${selected.has(w.id) ? 'bg-primary border-primary' : 'border-border hover:border-gold/50'}`}>
                  {selected.has(w.id) && <Check className="w-3 h-3 text-primary-foreground" />}
                </button>
                <div className="flex-1">
                  <CardItem
                    title={w.title}
                    subtitle={w.method === 'ai' ? 'AI生成' : w.method === 'extract' ? '從故事擷取' : '手動'}
                    content={w.content}
                    archived={w.archived}
                    accent="gold"
                    onEdit={() => { setEditingId(w.id); setEditData({ title: w.title, content: w.content }); }}
                    onArchive={() => handleArchive(w)}
                    onDelete={() => handleDelete(w.id)}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showModal && (
        <StreamingModal
          title="AI 生成世界觀"
          content={streamContent}
          isStreaming={streaming}
          onClose={() => { setShowModal(false); setStreamContent(''); }}
          onConfirm={handleSaveGenerated}
        />
      )}
    </AppLayout>
  );
}