import { useState, useEffect } from 'react';
import { Archive, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import AppLayout from '../components/AppLayout';
import CardItem from '../components/CardItem';

export default function ArchivePage() {
  const [tab, setTab] = useState('worlds');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const TABS = [
    { id: 'worlds', label: '世界觀', entity: 'WorldSetting' },
    { id: 'characters', label: '角色', entity: 'Character' },
    { id: 'outlines', label: '大綱', entity: 'StoryOutline' },
  ];

  const fetch = async (t) => {
    setLoading(true);
    const entity = TABS.find(x => x.id === t)?.entity;
    if (!entity) return;
    const data = await base44.entities[entity].filter({ archived: true });
    setItems(data);
    setLoading(false);
  };

  useEffect(() => { fetch(tab); }, [tab]);

  const handleRestore = async (item) => {
    const entity = TABS.find(x => x.id === tab)?.entity;
    if (!entity) return;
    await base44.entities[entity].update(item.id, { archived: false });
    fetch(tab);
  };

  const handleDelete = async (id) => {
    if (!confirm('永久刪除？')) return;
    const entity = TABS.find(x => x.id === tab)?.entity;
    await base44.entities[entity].delete(id);
    fetch(tab);
  };

  const getTitle = (item) => item.title || item.name || '（無標題）';
  const getContent = (item) => item.content || item.background || '';

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto px-6 py-8 space-y-6">
        <div className="flex items-center gap-3">
          <Archive className="w-6 h-6 text-gold" />
          <div>
            <h1 className="font-serif text-xl">封存箱</h1>
            <p className="text-xs text-muted-foreground mt-0.5">已封存的世界觀、角色與大綱</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-4 py-2 rounded-xl text-sm transition-colors ${tab === t.id ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-muted/80'}`}>
              {t.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : items.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground font-serif">封存箱是空的</div>
        ) : (
          <div className="space-y-3">
            {items.map(item => (
              <CardItem key={item.id}
                title={getTitle(item)}
                content={getContent(item)}
                archived={true}
                accent="default"
                onArchive={() => handleRestore(item)}
                onDelete={() => handleDelete(item.id)}
              />
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}