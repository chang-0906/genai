import { useState, useEffect } from 'react';
import { Plus, Users, Loader2, Wand2, Check, Trash2, Archive, ArchiveRestore, X, Hash } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { loadApiSettings } from '../lib/difyClient';
import { buildCharactersPrompt } from '../lib/prompts';
import AppLayout from '../components/AppLayout';

export default function Characters() {
  const [characters, setCharacters] = useState([]);
  const [worlds, setWorlds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState(null);
  const [selectedWorld, setSelectedWorld] = useState('');
  const [count, setCount] = useState(3);
  const [generating, setGenerating] = useState(false);
  const [generatedChars, setGeneratedChars] = useState([]);
  const [showArchived, setShowArchived] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({});
  const [selected, setSelected] = useState(new Set());
  const [activeWorldFilter, setActiveWorldFilter] = useState(null);
  const [activeTagFilter, setActiveTagFilter] = useState(null);

  useEffect(() => {
    Promise.all([
      base44.entities.Character.list('-updated_date'),
      base44.entities.WorldSetting.filter({ archived: false }),
    ]).then(([chars, ws]) => {
      setCharacters(chars);
      setWorlds(ws);
      setLoading(false);
    });
  }, []);

  const refetch = async () => {
    const chars = await base44.entities.Character.list('-updated_date');
    setCharacters(chars);
  };

  const getWorldTitle = (id) => worlds.find(w => w.id === id)?.title || '';

  // All user-defined tags across all chars
  const allUserTags = [...new Set(characters.flatMap(c => (c.tags || []).filter(t => t !== getWorldTitle(c.worldSettingId))))];

  const handleGenerate = async () => {
    if (!selectedWorld) { alert('請選擇世界觀'); return; }
    const world = worlds.find(w => w.id === selectedWorld);
    if (!world) return;
    const settings = loadApiSettings();
    const apiB = settings.apiB;
    if (!apiB.apiKey) { alert('請先在 API 設定中填入 B 模型的 API Key'); return; }

    setGenerating(true);
    const query = buildCharactersPrompt({ worldContent: world.content, count });

    try {
      const url = `${apiB.baseUrl.replace(/\/$/, '')}/v1/chat-messages`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiB.apiKey}` },
        body: JSON.stringify({ inputs: {}, query, response_mode: 'blocking', conversation_id: '', user: 'story-talker' }),
      });
      if (!response.ok) throw new Error(`API 錯誤 ${response.status}`);
      const json = await response.json();
      const text = json.answer || '';

      const parts = text.split(/---+/).map(p => p.trim()).filter(Boolean);
      const parsed = parts.map((part, i) => {
        const nameMatch = part.match(/姓名[：:]\s*(.+)/);
        const ageMatch = part.match(/年齡[：:]\s*(.+)/);
        const bgMatch = part.match(/身分背景描述[：:]\s*([\s\S]+?)(?=\n\n|\n姓名|\n年齡|$)/);
        return {
          _tempId: i,
          name: nameMatch ? nameMatch[1].trim() : `角色 ${i + 1}`,
          age: ageMatch ? ageMatch[1].trim() : '',
          background: bgMatch ? bgMatch[1].trim() : part,
          keep: true,
          role: 'supporting',
          worldSettingId: selectedWorld,
          archived: false,
          tags: [],
          _userTags: [],
        };
      });
      setGeneratedChars(parsed);
    } catch (err) {
      alert(`生成失敗：${err.message}`);
    }
    setGenerating(false);
  };

  const handleSaveGenerated = async () => {
    const toSave = generatedChars.filter(c => c.keep);
    const worldTitle = getWorldTitle(selectedWorld);
    for (const c of toSave) {
      const { _tempId, keep, _userTags, ...data } = c;
      // world tag first, then user tags
      data.tags = [worldTitle, ...(_userTags || [])];
      await base44.entities.Character.create(data);
    }
    setGeneratedChars([]);
    setMode(null);
    setSelectedWorld('');
    refetch();
  };

  const handleArchive = async (c) => {
    await base44.entities.Character.update(c.id, { archived: !c.archived });
    refetch();
  };

  const handleDelete = async (id) => {
    if (!confirm('確定刪除？')) return;
    await base44.entities.Character.delete(id);
    refetch();
  };

  const handleEditSave = async () => {
    await base44.entities.Character.update(editingId, editData);
    setEditingId(null);
    refetch();
  };

  const toggleSelect = (id) => {
    setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  const handleBatchArchive = async () => {
    for (const id of selected) await base44.entities.Character.update(id, { archived: !showArchived });
    setSelected(new Set()); refetch();
  };
  const handleBatchDelete = async () => {
    if (!confirm(`確定刪除 ${selected.size} 個角色？`)) return;
    for (const id of selected) await base44.entities.Character.delete(id);
    setSelected(new Set()); refetch();
  };

  // Tag editor for existing chars
  const [tagInput, setTagInput] = useState('');
  const addTag = async (c) => {
    const t = tagInput.trim().replace(/^#/, '');
    if (!t) return;
    const worldTitle = getWorldTitle(c.worldSettingId);
    const existing = (c.tags || []).filter(x => x !== worldTitle);
    if (existing.includes(t)) { setTagInput(''); return; }
    const newTags = [worldTitle, ...existing, t];
    await base44.entities.Character.update(c.id, { tags: newTags });
    setTagInput('');
    refetch();
  };
  const removeTag = async (c, tag) => {
    const worldTitle = getWorldTitle(c.worldSettingId);
    if (tag === worldTitle) return; // can't remove world tag
    const newTags = (c.tags || []).filter(t => t !== tag);
    await base44.entities.Character.update(c.id, { tags: newTags });
    refetch();
  };

  const visible = characters.filter(c => {
    if (showArchived ? !c.archived : c.archived) return false;
    if (activeWorldFilter && c.worldSettingId !== activeWorldFilter) return false;
    if (activeTagFilter) {
      const worldTitle = getWorldTitle(c.worldSettingId);
      const userTags = (c.tags || []).filter(t => t !== worldTitle);
      if (!userTags.includes(activeTagFilter)) return false;
    }
    return true;
  });

  // Group by world
  const worldGroups = worlds.reduce((acc, w) => {
    const chars = visible.filter(c => c.worldSettingId === w.id);
    if (chars.length > 0) acc.push({ world: w, chars });
    return acc;
  }, []);
  const ungrouped = visible.filter(c => !c.worldSettingId || !worlds.find(w => w.id === c.worldSettingId));

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto px-6 py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-gold" />
            <div>
              <h1 className="font-serif text-xl">角色設定</h1>
              <p className="text-xs text-muted-foreground mt-0.5">使用 B LLM 建立故事角色</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setShowArchived(s => !s)} className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${showArchived ? 'border-gold/40 text-gold bg-accent' : 'border-border text-muted-foreground'}`}>
              {showArchived ? '返回列表' : '封存箱'}
            </button>
            {!mode && <button onClick={() => setMode('create')} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90">
              <Plus className="w-4 h-4" />新增
            </button>}
          </div>
        </div>

        {/* Filters */}
        <div className="space-y-2">
          {/* World filter */}
          <div className="flex flex-wrap gap-2">
            <button onClick={() => { setActiveWorldFilter(null); setActiveTagFilter(null); }}
              className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${!activeWorldFilter && !activeTagFilter ? 'border-gold/40 text-gold bg-accent' : 'border-border text-muted-foreground'}`}>
              全部
            </button>
            {worlds.map(w => (
              <button key={w.id} onClick={() => { setActiveWorldFilter(f => f === w.id ? null : w.id); setActiveTagFilter(null); }}
                className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${activeWorldFilter === w.id ? 'border-amber-400/60 bg-amber-500/10 text-amber-300' : 'border-border text-muted-foreground'}`}>
                🌍 {w.title}
              </button>
            ))}
          </div>
          {/* User tag filter */}
          {allUserTags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {allUserTags.map(tag => (
                <button key={tag} onClick={() => { setActiveTagFilter(t => t === tag ? null : tag); setActiveWorldFilter(null); }}
                  className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${activeTagFilter === tag ? 'border-sky-400/60 bg-sky-500/10 text-sky-300' : 'border-border text-muted-foreground'}`}>
                  #{tag}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Batch actions */}
        {selected.size > 0 && (
          <div className="flex items-center gap-3 bg-accent border border-gold/30 rounded-xl px-4 py-2.5 animate-fade-in">
            <span className="text-xs text-gold font-medium">已選取 {selected.size} 個</span>
            <div className="flex gap-2 ml-auto">
              <button onClick={handleBatchArchive} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-muted hover:bg-muted/80 text-foreground transition-colors">
                {showArchived ? <ArchiveRestore className="w-3.5 h-3.5" /> : <Archive className="w-3.5 h-3.5" />}
                {showArchived ? '取消封存' : '封存'}
              </button>
              <button onClick={handleBatchDelete} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-destructive/20 hover:bg-destructive/30 text-destructive transition-colors">
                <Trash2 className="w-3.5 h-3.5" />刪除
              </button>
              <button onClick={() => setSelected(new Set())} className="text-xs px-3 py-1.5 rounded-lg bg-muted text-muted-foreground hover:bg-muted/80">取消</button>
            </div>
          </div>
        )}

        {/* Create Form */}
        {mode === 'create' && (
          <div className="bg-card border border-border rounded-2xl p-6 space-y-4 animate-fade-in">
            <h2 className="font-serif text-base text-gold">AI 生成角色</h2>
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">選擇世界觀</label>
              <select value={selectedWorld} onChange={e => setSelectedWorld(e.target.value)}
                className="w-full bg-input border border-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring">
                <option value="">— 選擇世界觀 —</option>
                {worlds.map(w => <option key={w.id} value={w.id}>{w.title}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">生成角色數量</label>
              <input type="number" min={1} max={20} value={count} onChange={e => setCount(parseInt(e.target.value) || 1)}
                className="w-24 bg-input border border-border rounded-xl px-3 py-2 text-sm text-center focus:outline-none focus:ring-1 focus:ring-ring" />
            </div>
            <div className="flex gap-3">
              <button onClick={handleGenerate} disabled={generating || !selectedWorld}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 disabled:opacity-50">
                {generating ? <><Loader2 className="w-4 h-4 animate-spin" />生成中…</> : <><Wand2 className="w-4 h-4" />AI 生成角色</>}
              </button>
              <button onClick={() => { setMode(null); setGeneratedChars([]); }} className="px-5 py-2.5 bg-muted text-muted-foreground rounded-xl text-sm hover:bg-muted/80">取消</button>
            </div>

            {generatedChars.length > 0 && (
              <div className="space-y-3 pt-2">
                <p className="text-xs text-muted-foreground">選擇要保留的角色，並可新增標籤：</p>
                {generatedChars.map((c, i) => (
                  <div key={c._tempId} className={`border rounded-xl p-4 transition-colors ${c.keep ? 'border-gold/40 bg-[hsl(var(--director-bg))]' : 'border-border bg-muted/30 opacity-50'}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <input type="text" value={c.name} onChange={e => setGeneratedChars(prev => prev.map((x, j) => j === i ? { ...x, name: e.target.value } : x))}
                            className="font-serif font-medium text-sm bg-transparent border-b border-border/50 focus:outline-none focus:border-gold/50 w-32" />
                          <input type="text" value={c.age} onChange={e => setGeneratedChars(prev => prev.map((x, j) => j === i ? { ...x, age: e.target.value } : x))}
                            placeholder="年齡" className="text-xs text-muted-foreground bg-transparent border-b border-border/50 focus:outline-none w-16" />
                          <select value={c.role} onChange={e => setGeneratedChars(prev => prev.map((x, j) => j === i ? { ...x, role: e.target.value } : x))}
                            className="text-xs bg-muted border border-border rounded-lg px-2 py-1">
                            <option value="protagonist">主角</option>
                            <option value="supporting">配角</option>
                            <option value="antagonist">反派</option>
                          </select>
                        </div>
                        <p className="text-xs text-muted-foreground leading-relaxed">{c.background}</p>
                        {/* Tag input for generated char */}
                        <div className="flex flex-wrap gap-1 items-center">
                          <span className="text-xs bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full">
                            🌍 {getWorldTitle(selectedWorld)}
                          </span>
                          {(c._userTags || []).map(t => (
                            <span key={t} className="text-xs bg-sky-500/20 text-sky-300 border border-sky-400/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                              #{t}
                              <button onClick={() => setGeneratedChars(prev => prev.map((x, j) => j === i ? { ...x, _userTags: x._userTags.filter(u => u !== t) } : x))}>
                                <X className="w-2.5 h-2.5" />
                              </button>
                            </span>
                          ))}
                          <input
                            type="text"
                            placeholder="#標籤"
                            className="text-xs bg-transparent border-b border-border/40 focus:outline-none w-20 px-1"
                            onKeyDown={e => {
                              if (e.key === 'Enter' || e.key === ' ') {
                                const t = e.target.value.trim().replace(/^#/, '');
                                if (t) setGeneratedChars(prev => prev.map((x, j) => j === i && !x._userTags.includes(t) ? { ...x, _userTags: [...x._userTags, t] } : x));
                                e.target.value = '';
                              }
                            }}
                          />
                        </div>
                      </div>
                      <button onClick={() => setGeneratedChars(prev => prev.map((x, j) => j === i ? { ...x, keep: !x.keep } : x))}
                        className={`text-xs px-2.5 py-1 rounded-lg border transition-colors flex-shrink-0 ${c.keep ? 'border-gold/40 text-gold bg-accent' : 'border-border text-muted-foreground'}`}>
                        {c.keep ? '保留' : '丟棄'}
                      </button>
                    </div>
                  </div>
                ))}
                <button onClick={handleSaveGenerated} className="w-full py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90">
                  儲存選取的角色
                </button>
              </div>
            )}
          </div>
        )}

        {/* Edit form */}
        {editingId && (
          <div className="bg-card border border-gold/30 rounded-2xl p-5 space-y-3 animate-fade-in">
            <h3 className="font-serif text-sm text-gold">編輯角色</h3>
            {[['name', '姓名'], ['age', '年齡']].map(([k, l]) => (
              <div key={k}>
                <label className="text-xs text-muted-foreground mb-1 block">{l}</label>
                <input value={editData[k] || ''} onChange={e => setEditData(d => ({ ...d, [k]: e.target.value }))}
                  className="w-full bg-input border border-border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
              </div>
            ))}
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">身分背景描述</label>
              <textarea value={editData.background || ''} onChange={e => setEditData(d => ({ ...d, background: e.target.value }))} rows={4}
                className="w-full bg-input border border-border rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring" />
            </div>
            <div className="flex gap-3">
              <button onClick={handleEditSave} className="flex-1 py-2 bg-primary text-primary-foreground rounded-xl text-sm hover:opacity-90">儲存</button>
              <button onClick={() => setEditingId(null)} className="px-4 py-2 bg-muted text-muted-foreground rounded-xl text-sm">取消</button>
            </div>
          </div>
        )}

        {/* List */}
        {loading ? (
          <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : visible.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground font-serif">{showArchived ? '封存箱是空的' : '尚無角色'}</div>
        ) : (
          <div className="space-y-6">
            {[...worldGroups, ...(ungrouped.length > 0 ? [{ world: null, chars: ungrouped }] : [])].map(({ world, chars }) => (
              <div key={world?.id || '__ungrouped__'}>
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs font-medium text-amber-400/80">{world ? `🌍 ${world.title}` : '其他'}</span>
                  <div className="flex-1 h-px bg-border/50" />
                </div>
                <div className="space-y-3">
                  {chars.map(c => {
                    const worldTitle = getWorldTitle(c.worldSettingId);
                    const userTags = (c.tags || []).filter(t => t !== worldTitle);
                    return (
                      <div key={c.id} className="flex items-start gap-2">
                        <button
                          onClick={() => toggleSelect(c.id)}
                          className={`mt-4 flex-shrink-0 w-5 h-5 rounded border transition-colors flex items-center justify-center ${selected.has(c.id) ? 'bg-primary border-primary' : 'border-border hover:border-gold/50'}`}>
                          {selected.has(c.id) && <Check className="w-3 h-3 text-primary-foreground" />}
                        </button>
                        <div className="flex-1">
                          <div className={`rounded-2xl border border-[hsl(var(--writer-border))] bg-[hsl(var(--writer-bg))] transition-all ${c.archived ? 'opacity-60' : ''}`}>
                            <div className="p-4 space-y-2">
                              <div className="flex items-start gap-3">
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap mb-1">
                                    <span className="font-serif font-medium text-sm">{c.name}</span>
                                    {c.age && <span className="text-xs text-muted-foreground">{c.age}歲</span>}
                                    <span className="text-xs text-muted-foreground">·</span>
                                    <span className="text-xs text-muted-foreground">{c.role === 'protagonist' ? '主角' : c.role === 'antagonist' ? '反派' : '配角'}</span>
                                    {c.archived && <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">已封存</span>}
                                  </div>
                                  {/* Tags */}
                                  <div className="flex flex-wrap gap-1 mb-2">
                                    {worldTitle && (
                                      <span className="text-xs bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full">
                                        🌍 {worldTitle}
                                      </span>
                                    )}
                                    {userTags.map(t => (
                                      <span key={t} className="text-xs bg-sky-500/20 text-sky-300 border border-sky-400/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                                        #{t}
                                        <button onClick={() => removeTag(c, t)} className="hover:text-white"><X className="w-2.5 h-2.5" /></button>
                                      </span>
                                    ))}
                                  </div>
                                  {/* Tag input */}
                                  <div className="flex items-center gap-1">
                                    <Hash className="w-3 h-3 text-muted-foreground/50" />
                                    <input
                                      type="text"
                                      value={editingId === c.id ? tagInput : ''}
                                      placeholder="新增標籤…"
                                      className="text-xs bg-transparent border-b border-border/30 focus:outline-none focus:border-sky-400/50 w-24 px-1"
                                      onFocus={() => { setTagInput(''); }}
                                      onChange={e => setTagInput(e.target.value)}
                                      onKeyDown={e => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                          const t = tagInput.trim().replace(/^#/, '');
                                          if (t) addTag(c);
                                        }
                                      }}
                                      onBlur={() => { if (tagInput.trim()) addTag(c); }}
                                    />
                                  </div>
                                  {c.background && (
                                    <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 mt-1">{c.background}</p>
                                  )}
                                </div>
                                <div className="flex items-center gap-1 flex-shrink-0">
                                  <button onClick={() => { setEditingId(c.id); setEditData({ name: c.name, age: c.age, background: c.background }); }}
                                    className="p-1.5 rounded-lg hover:bg-muted/60 text-muted-foreground hover:text-foreground transition-colors">
                                    <Plus className="w-3.5 h-3.5 rotate-45" />
                                  </button>
                                  <button onClick={() => handleArchive(c)}
                                    className="p-1.5 rounded-lg hover:bg-muted/60 text-muted-foreground hover:text-amber-400 transition-colors">
                                    {c.archived ? <ArchiveRestore className="w-3.5 h-3.5" /> : <Archive className="w-3.5 h-3.5" />}
                                  </button>
                                  <button onClick={() => handleDelete(c.id)}
                                    className="p-1.5 rounded-lg hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors">
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}