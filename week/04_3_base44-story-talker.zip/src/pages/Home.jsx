import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Plus, BookOpen, Tag, Trash2, Clock, Sun, Moon } from 'lucide-react';
import { loadProjects, saveProject, deleteProject, createProject, loadSettings, saveSettings } from '../lib/storageManager';

export default function Home() {
  const [projects, setProjects] = useState([]);
  const [settings, setSettings] = useState(loadSettings());
  const [newTitle, setNewTitle] = useState('');
  const [newTags, setNewTags] = useState('');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    setProjects(loadProjects());
    applyTheme(loadSettings().theme);
  }, []);

  const applyTheme = (theme) => {
    document.documentElement.classList.toggle('light', theme === 'light');
  };

  const toggleTheme = () => {
    const next = settings.theme === 'dark' ? 'light' : 'dark';
    const updated = { ...settings, theme: next };
    setSettings(updated);
    saveSettings(updated);
    applyTheme(next);
  };

  const handleCreate = () => {
    const title = newTitle.trim() || '未命名故事';
    const tags = newTags.split(',').map(t => t.trim()).filter(Boolean);
    const project = createProject(title, tags);
    saveProject(project);
    setProjects(loadProjects());
    setNewTitle('');
    setNewTags('');
    setCreating(false);
  };

  const handleDelete = (e, id) => {
    e.preventDefault();
    if (confirm('確定刪除這個故事？')) {
      deleteProject(id);
      setProjects(loadProjects());
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-2xl">🎭</span>
          <div>
            <h1 className="text-xl font-serif text-foreground tracking-wide">AI 故事工坊</h1>
            <p className="text-xs text-muted-foreground mt-0.5">讓兩個 AI 共同創造你的故事</p>
          </div>
        </div>
        <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
          {settings.theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-10">
        {/* New Project */}
        <div className="mb-10">
          {!creating ? (
            <button
              onClick={() => setCreating(true)}
              className="w-full py-4 border-2 border-dashed border-border hover:border-gold/50 rounded-2xl flex items-center justify-center gap-2 text-muted-foreground hover:text-gold transition-all group"
            >
              <Plus className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span className="font-medium">新建故事</span>
            </button>
          ) : (
            <div className="bg-card border border-border rounded-2xl p-6 space-y-4 animate-fade-in gold-glow">
              <h3 className="font-serif text-base text-gold">新建故事</h3>
              <input
                autoFocus
                type="text"
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleCreate()}
                placeholder="故事標題…"
                className="w-full bg-input border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring"
              />
              <input
                type="text"
                value={newTags}
                onChange={e => setNewTags(e.target.value)}
                placeholder="標籤（用逗號分隔，例如：奇幻, 愛情）"
                className="w-full bg-input border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring"
              />
              <div className="flex gap-3">
                <button onClick={handleCreate} className="flex-1 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity">
                  建立
                </button>
                <button onClick={() => setCreating(false)} className="flex-1 py-2.5 bg-muted text-muted-foreground rounded-xl text-sm hover:bg-muted/80 transition-colors">
                  取消
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Project List */}
        {projects.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-5xl mb-4 opacity-30">📖</div>
            <p className="text-muted-foreground font-serif">尚無故事，建立你的第一個吧</p>
          </div>
        ) : (
          <div className="space-y-3">
            <h2 className="text-xs text-muted-foreground uppercase tracking-widest mb-4">故事列表 ({projects.length})</h2>
            {projects.map(p => (
              <Link
                key={p.id}
                to={`/studio/${p.id}`}
                className="group block bg-card border border-border hover:border-gold/30 rounded-2xl p-5 transition-all hover:gold-glow"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1.5">
                      <BookOpen className="w-4 h-4 text-gold/60 flex-shrink-0" />
                      <span className="font-serif text-base truncate">{p.title}</span>
                      <StatusBadge status={p.status} />
                    </div>

                    {p.tags?.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mb-2">
                        {p.tags.map(tag => (
                          <span key={tag} className="inline-flex items-center gap-1 text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded-full">
                            <Tag className="w-2.5 h-2.5" />
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center gap-1 text-xs text-muted-foreground/60">
                      <Clock className="w-3 h-3" />
                      <span>{new Date(p.updatedAt).toLocaleString('zh-TW')}</span>
                      {p.versions?.length > 0 && <span className="ml-2">· {p.versions.length} 個版本</span>}
                    </div>
                  </div>

                  <button
                    onClick={e => handleDelete(e, p.id)}
                    className="opacity-0 group-hover:opacity-100 p-2 rounded-lg hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-all flex-shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function StatusBadge({ status }) {
  const map = {
    draft: { label: '草稿', cls: 'bg-muted text-muted-foreground' },
    running: { label: '進行中', cls: 'bg-amber-500/20 text-amber-400' },
    completed: { label: '已完成', cls: 'bg-emerald-500/20 text-emerald-400' },
  };
  const s = map[status] || map.draft;
  return <span className={`text-xs px-2 py-0.5 rounded-full ${s.cls}`}>{s.label}</span>;
}