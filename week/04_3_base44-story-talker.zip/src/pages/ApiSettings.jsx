import { useState } from 'react';
import { Settings, Eye, EyeOff, Save } from 'lucide-react';
import { loadApiSettings, saveApiSettings } from '../lib/difyClient';
import AppLayout from '../components/AppLayout';

const API_KEYS = ['apiA', 'apiB', 'apiC', 'apiD'];

export default function ApiSettings() {
  const [settings, setSettings] = useState(loadApiSettings());
  const [showKeys, setShowKeys] = useState({});
  const [saved, setSaved] = useState(false);

  const update = (key, field, val) => {
    setSettings(s => ({ ...s, [key]: { ...s[key], [field]: val } }));
  };

  const handleSave = () => {
    saveApiSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const colors = { apiA: 'text-amber-400', apiB: 'text-sky-400', apiC: 'text-emerald-400', apiD: 'text-violet-400' };

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto px-6 py-8 space-y-6">
        <div className="flex items-center gap-3">
          <Settings className="w-6 h-6 text-gold" />
          <div>
            <h1 className="font-serif text-xl">API 設定</h1>
            <p className="text-xs text-muted-foreground mt-0.5">設定你的 Dify API 連線</p>
          </div>
        </div>

        <div className="bg-muted/30 border border-border rounded-xl p-4 text-xs text-muted-foreground leading-relaxed">
          <p>本應用使用 <strong className="text-foreground">Dify.ai</strong> 作為 LLM 後端。請在 Dify 設定好各自的 System Prompt，再將 API Key 貼入下方。</p>
          <p className="mt-1">各模型各司其職：A=世界觀、B=角色、C=大綱、D=故事生成。</p>
        </div>

        <div className="space-y-4">
          {API_KEYS.map(key => {
            const cfg = settings[key];
            const showKey = showKeys[key];
            return (
              <div key={key} className="bg-card border border-border rounded-2xl p-5 space-y-4">
                <h3 className={`font-serif text-base font-medium ${colors[key]}`}>{cfg.label}</h3>

                <div className="space-y-3">
                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">Dify Base URL</label>
                    <input
                      type="text"
                      value={cfg.baseUrl}
                      onChange={e => update(key, 'baseUrl', e.target.value)}
                      placeholder="https://api.dify.ai"
                      className="w-full bg-input border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-muted-foreground mb-1.5 block">API Key</label>
                    <div className="relative">
                      <input
                        type={showKey ? 'text' : 'password'}
                        value={cfg.apiKey}
                        onChange={e => update(key, 'apiKey', e.target.value)}
                        placeholder="app-..."
                        className="w-full bg-input border border-border rounded-xl px-4 py-2.5 text-sm pr-10 focus:outline-none focus:ring-1 focus:ring-ring"
                      />
                      <button
                        onClick={() => setShowKeys(s => ({ ...s, [key]: !s[key] }))}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      >
                        {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <button onClick={handleSave}
          className={`w-full flex items-center justify-center gap-2 py-3 rounded-2xl text-sm font-medium transition-all ${saved ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-primary text-primary-foreground hover:opacity-90'}`}>
          <Save className="w-4 h-4" />
          {saved ? '已儲存！' : '儲存設定'}
        </button>
      </div>
    </AppLayout>
  );
}