import { useState, useEffect } from 'react';
import { Plus, Feather, Loader2, Play, Download, Check, Trash2, Archive, ArchiveRestore, Edit3 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { base44 } from '@/api/base44Client';
import { loadApiSettings } from '../lib/difyClient';
import { buildStoryPrompt, buildChapterPrompt, LENGTH_CONFIG } from '../lib/prompts';
import AppLayout from '../components/AppLayout';
import CardItem from '../components/CardItem';

function mdToMarkdownFile(story, chapters) {
  const chapterText = chapters.map(c => `## ${c.title}\n\n${c.content}`).join('\n\n---\n\n');
  const blob = new Blob([`# ${story.title}\n\n${chapterText}`], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `${story.title}.md`; a.click();
  URL.revokeObjectURL(url);
}

export default function Stories() {
  const [stories, setStories] = useState([]);
  const [outlines, setOutlines] = useState([]);
  const [worlds, setWorlds] = useState([]);
  const [characters, setCharacters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState(null);
  const [selectedOutline, setSelectedOutline] = useState('');
  const [storyTitle, setStoryTitle] = useState('');
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState('');
  const [viewingId, setViewingId] = useState(null);
  const [viewChapters, setViewChapters] = useState([]);
  const [loadingChapters, setLoadingChapters] = useState(false);
  const [selected, setSelected] = useState(new Set());
  const [editingId, setEditingId] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editChapterId, setEditChapterId] = useState(null);
  const [editChapterData, setEditChapterData] = useState({ title: '', content: '' });

  useEffect(() => {
    Promise.all([
      base44.entities.Story.list('-updated_date'),
      base44.entities.StoryOutline.filter({ archived: false }),
      base44.entities.WorldSetting.list(),
      base44.entities.Character.list(),
    ]).then(([s, o, w, c]) => {
      setStories(s); setOutlines(o); setWorlds(w); setCharacters(c);
      setLoading(false);
    });
  }, []);

  const refetch = async () => {
    const data = await base44.entities.Story.list('-updated_date');
    setStories(data);
  };

  const loadChapters = async (storyId) => {
    setLoadingChapters(true);
    const chapters = await base44.entities.StoryChapter.filter({ storyId });
    setViewChapters(chapters.sort((a, b) => a.chapterIndex - b.chapterIndex));
    setLoadingChapters(false);
  };

  const handleView = async (id) => {
    if (viewingId === id) { setViewingId(null); setViewChapters([]); return; }
    setViewingId(id);
    await loadChapters(id);
  };

  const getOutlineData = (outline) => {
    const worldContent = (outline.worldSettingIds || [])
      .map(id => worlds.find(w => w.id === id)).filter(Boolean)
      .map(w => `【${w.title}】\n${w.content}`).join('\n\n');
    const charsContent = (outline.characterIds || [])
      .map(id => characters.find(c => c.id === id)).filter(Boolean)
      .map(c => `【${c.name}】${c.age ? ' ' + c.age + '歲' : ''}\n${c.background}`).join('\n\n');
    return { worldContent, charsContent };
  };

  const handleGenerate = async () => {
    if (!selectedOutline) { alert('請選擇大綱'); return; }
    const settings = loadApiSettings();
    const apiD = settings.apiD;
    if (!apiD.apiKey) { alert('請先在 API 設定中填入 D 模型的 API Key'); return; }

    const outline = outlines.find(o => o.id === selectedOutline);
    if (!outline) return;
    const lenConf = LENGTH_CONFIG[outline.length];
    const { worldContent, charsContent } = getOutlineData(outline);
    const title = storyTitle || `故事 — ${outline.title}`;

    const story = await base44.entities.Story.create({
      title, outlineId: selectedOutline, chapters: '[]', status: 'generating', archived: false,
    });

    setGenerating(true);
    setMode(null);

    const callDify = async (query) => {
      const url = `${apiD.baseUrl.replace(/\/$/, '')}/v1/chat-messages`;
      const r = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiD.apiKey}` },
        body: JSON.stringify({ inputs: {}, query, response_mode: 'blocking', conversation_id: '', user: 'story-talker' }),
      });
      if (!r.ok) throw new Error(`API 錯誤 ${r.status}`);
      const j = await r.json();
      return j.answer || '';
    };

    try {
      if (lenConf.chapters === 0) {
        setProgress('生成故事內容中…');
        const query = buildStoryPrompt({ worldContent, charactersContent: charsContent, outlineContent: outline.content, wordCount: lenConf.wordCount });
        const content = await callDify(query);
        await base44.entities.StoryChapter.create({ storyId: story.id, chapterIndex: 0, title: '故事正文', content });
      } else {
        const chapterWordCount = Math.round(lenConf.wordCount / lenConf.chapters);
        const chapterLines = outline.content.split('\n').filter(l => /第[一二三四五六七八九十\d]+章|Chapter\s*\d+/i.test(l));
        for (let i = 0; i < lenConf.chapters; i++) {
          const chapterTitle = chapterLines[i] ? chapterLines[i].replace(/[：:].+/, '').trim() : `第 ${i + 1} 章`;
          const chapterOutline = chapterLines[i] ? outline.content.split(chapterLines[i])[1]?.split(chapterLines[i + 1] || '==END==')[0]?.trim() || '' : '';
          setProgress(`生成第 ${i + 1}/${lenConf.chapters} 章：${chapterTitle}`);
          const query = buildChapterPrompt({
            worldContent, charactersContent: charsContent, outlineContent: outline.content,
            chapterTitle, chapterOutline, chapterIndex: i + 1, totalChapters: lenConf.chapters, wordCount: chapterWordCount,
          });
          const content = await callDify(query);
          await base44.entities.StoryChapter.create({ storyId: story.id, chapterIndex: i, title: chapterTitle, content });
        }
      }
      await base44.entities.Story.update(story.id, { status: 'completed' });
    } catch (err) {
      await base44.entities.Story.update(story.id, { status: 'draft' });
      alert(`生成失敗：${err.message}`);
    }

    setGenerating(false);
    setProgress('');
    setSelectedOutline('');
    setStoryTitle('');
    refetch();
  };

  const handleEditTitleSave = async () => {
    await base44.entities.Story.update(editingId, { title: editTitle });
    setEditingId(null);
    refetch();
  };

  const handleEditChapterSave = async () => {
    await base44.entities.StoryChapter.update(editChapterId, { title: editChapterData.title, content: editChapterData.content });
    setEditChapterId(null);
    await loadChapters(viewingId);
  };

  const handleDelete = async (id) => {
    if (!confirm('確定刪除？此操作也會刪除所有章節。')) return;
    const chapters = await base44.entities.StoryChapter.filter({ storyId: id });
    for (const c of chapters) await base44.entities.StoryChapter.delete(c.id);
    await base44.entities.Story.delete(id);
    if (viewingId === id) { setViewingId(null); setViewChapters([]); }
    refetch();
  };

  const handleArchive = async (s) => {
    await base44.entities.Story.update(s.id, { archived: !s.archived });
    refetch();
  };

  const handleExport = async (s) => {
    const chapters = await base44.entities.StoryChapter.filter({ storyId: s.id });
    mdToMarkdownFile(s, chapters.sort((a, b) => a.chapterIndex - b.chapterIndex));
  };

  const toggleSelect = (id) => {
    setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };
  const handleBatchDelete = async () => {
    if (!confirm(`確定刪除 ${selected.size} 個故事？`)) return;
    for (const id of selected) {
      const chapters = await base44.entities.StoryChapter.filter({ storyId: id });
      for (const c of chapters) await base44.entities.StoryChapter.delete(c.id);
      await base44.entities.Story.delete(id);
    }
    setSelected(new Set()); refetch();
  };
  const handleBatchArchive = async () => {
    for (const id of selected) await base44.entities.Story.update(id, { archived: true });
    setSelected(new Set()); refetch();
  };

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto px-6 py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Feather className="w-6 h-6 text-gold" />
            <div>
              <h1 className="font-serif text-xl">故事生成</h1>
              <p className="text-xs text-muted-foreground mt-0.5">使用 D LLM 生成完整故事</p>
            </div>
          </div>
          {!mode && !generating && (
            <button onClick={() => setMode('create')} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90">
              <Plus className="w-4 h-4" />新增
            </button>
          )}
        </div>

        {generating && (
          <div className="bg-card border border-gold/30 rounded-2xl p-6 flex items-center gap-4 animate-fade-in">
            <Loader2 className="w-6 h-6 animate-spin text-gold flex-shrink-0" />
            <div>
              <p className="font-serif text-sm text-gold">故事生成中…</p>
              <p className="text-xs text-muted-foreground mt-0.5">{progress}</p>
            </div>
          </div>
        )}

        {/* Batch actions */}
        {selected.size > 0 && (
          <div className="flex items-center gap-3 bg-accent border border-gold/30 rounded-xl px-4 py-2.5 animate-fade-in">
            <span className="text-xs text-gold font-medium">已選取 {selected.size} 個</span>
            <div className="flex gap-2 ml-auto">
              <button onClick={handleBatchArchive} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-muted hover:bg-muted/80 text-foreground">
                <Archive className="w-3.5 h-3.5" />封存
              </button>
              <button onClick={handleBatchDelete} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-destructive/20 hover:bg-destructive/30 text-destructive">
                <Trash2 className="w-3.5 h-3.5" />刪除
              </button>
              <button onClick={() => setSelected(new Set())} className="text-xs px-3 py-1.5 rounded-lg bg-muted text-muted-foreground hover:bg-muted/80">取消</button>
            </div>
          </div>
        )}

        {mode === 'create' && (
          <div className="bg-card border border-border rounded-2xl p-6 space-y-4 animate-fade-in">
            <h2 className="font-serif text-base text-gold">生成新故事</h2>
            <input type="text" value={storyTitle} onChange={e => setStoryTitle(e.target.value)}
              placeholder="故事標題（選填）"
              className="w-full bg-input border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block">選擇大綱</label>
              <select value={selectedOutline} onChange={e => setSelectedOutline(e.target.value)}
                className="w-full bg-input border border-border rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring">
                <option value="">— 選擇大綱 —</option>
                {outlines.map(o => <option key={o.id} value={o.id}>{o.title} ({LENGTH_CONFIG[o.length]?.label})</option>)}
              </select>
            </div>
            {selectedOutline && (() => {
              const o = outlines.find(x => x.id === selectedOutline);
              const lc = o ? LENGTH_CONFIG[o.length] : null;
              return lc ? (
                <div className="text-xs text-muted-foreground bg-muted/40 rounded-xl p-3">
                  📖 {lc.label}・{lc.wordCount.toLocaleString()} 字・{lc.chapters > 0 ? `${lc.chapters} 章節，各章節分別儲存` : '無章節，單次生成'}
                </div>
              ) : null;
            })()}
            <div className="flex gap-3">
              <button onClick={handleGenerate} disabled={!selectedOutline}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 disabled:opacity-50">
                <Play className="w-4 h-4" />開始生成
              </button>
              <button onClick={() => setMode(null)} className="px-5 py-2.5 bg-muted text-muted-foreground rounded-xl text-sm hover:bg-muted/80">取消</button>
            </div>
          </div>
        )}

        {/* Chapter edit form */}
        {editChapterId && (
          <div className="bg-card border border-gold/30 rounded-2xl p-5 space-y-3 animate-fade-in">
            <h3 className="font-serif text-sm text-gold">編輯章節</h3>
            <input value={editChapterData.title} onChange={e => setEditChapterData(d => ({ ...d, title: e.target.value }))}
              className="w-full bg-input border border-border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <textarea value={editChapterData.content} onChange={e => setEditChapterData(d => ({ ...d, content: e.target.value }))} rows={12}
              className="w-full bg-input border border-border rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring font-serif leading-relaxed" />
            <div className="flex gap-3">
              <button onClick={handleEditChapterSave} className="flex-1 py-2 bg-primary text-primary-foreground rounded-xl text-sm hover:opacity-90">儲存</button>
              <button onClick={() => setEditChapterId(null)} className="px-4 py-2 bg-muted text-muted-foreground rounded-xl text-sm">取消</button>
            </div>
          </div>
        )}

        {/* List */}
        {loading ? (
          <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : stories.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground font-serif">尚無故事，從大綱開始生成吧</div>
        ) : (
          <div className="space-y-4">
            {stories.map(s => (
              <div key={s.id}>
                <div className="flex items-start gap-2">
                  <button onClick={() => toggleSelect(s.id)}
                    className={`mt-4 flex-shrink-0 w-5 h-5 rounded border transition-colors flex items-center justify-center ${selected.has(s.id) ? 'bg-primary border-primary' : 'border-border hover:border-gold/50'}`}>
                    {selected.has(s.id) && <Check className="w-3 h-3 text-primary-foreground" />}
                  </button>
                  <div className="flex-1">
                    <div className="rounded-2xl border border-border bg-card">
                      <div className="p-4 space-y-2">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            {editingId === s.id ? (
                              <div className="flex items-center gap-2">
                                <input value={editTitle} onChange={e => setEditTitle(e.target.value)}
                                  className="flex-1 bg-input border border-border rounded-lg px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
                                <button onClick={handleEditTitleSave} className="text-xs px-2 py-1 bg-primary text-primary-foreground rounded-lg">儲存</button>
                                <button onClick={() => setEditingId(null)} className="text-xs px-2 py-1 bg-muted text-muted-foreground rounded-lg">取消</button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <span className="font-serif font-medium text-sm">{s.title}</span>
                                <button onClick={() => { setEditingId(s.id); setEditTitle(s.title); }}
                                  className="p-0.5 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                                  <Edit3 className="w-3 h-3" />
                                </button>
                              </div>
                            )}
                            <p className="text-xs text-muted-foreground mt-0.5">
                              {s.status === 'generating' ? '⏳ 生成中' : s.status === 'completed' ? '✅ 已完成' : '草稿'}
                            </p>
                          </div>
                          <div className="flex items-center gap-1 flex-shrink-0">
                            <button onClick={() => handleView(s.id)} className="text-xs px-2.5 py-1.5 rounded-lg border border-border hover:border-gold/40 text-muted-foreground hover:text-gold transition-colors">
                              {viewingId === s.id ? '收起' : '閱讀'}
                            </button>
                            <button onClick={() => handleExport(s)} className="text-xs px-2.5 py-1.5 rounded-lg border border-border hover:border-gold/40 text-muted-foreground hover:text-gold transition-colors flex items-center gap-1">
                              <Download className="w-3 h-3" />匯出
                            </button>
                            <button onClick={() => handleArchive(s)} className="p-1.5 rounded-lg hover:bg-muted/60 text-muted-foreground hover:text-amber-400 transition-colors">
                              {s.archived ? <ArchiveRestore className="w-3.5 h-3.5" /> : <Archive className="w-3.5 h-3.5" />}
                            </button>
                            <button onClick={() => handleDelete(s.id)} className="p-1.5 rounded-lg hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Chapter viewer */}
                      {viewingId === s.id && (
                        <div className="border-t border-border px-4 pb-4 pt-4 space-y-6">
                          {loadingChapters ? (
                            <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
                          ) : viewChapters.length === 0 ? (
                            <p className="text-sm text-muted-foreground font-serif">（無章節內容）</p>
                          ) : (
                            viewChapters.map(ch => (
                              <div key={ch.id}>
                                <div className="flex items-center justify-between mb-2">
                                  <h3 className="font-serif text-sm font-semibold text-gold">{ch.title}</h3>
                                  <button onClick={() => { setEditChapterId(ch.id); setEditChapterData({ title: ch.title, content: ch.content }); }}
                                    className="p-1 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                                <div className="text-sm leading-relaxed story-prose prose prose-invert prose-sm max-w-none">
                                  <ReactMarkdown
                                    components={{
                                      p: ({ children }) => <p className="mb-3 last:mb-0">{children}</p>,
                                      strong: ({ children }) => <strong className="font-semibold text-foreground">{children}</strong>,
                                      em: ({ children }) => <em className="italic">{children}</em>,
                                      h1: ({ children }) => <h1 className="text-lg font-serif font-bold mb-2 mt-4 text-gold">{children}</h1>,
                                      h2: ({ children }) => <h2 className="text-base font-serif font-semibold mb-2 mt-3 text-gold/80">{children}</h2>,
                                      h3: ({ children }) => <h3 className="text-sm font-semibold mb-1 mt-2">{children}</h3>,
                                      ul: ({ children }) => <ul className="list-disc ml-4 mb-2 space-y-1">{children}</ul>,
                                      ol: ({ children }) => <ol className="list-decimal ml-4 mb-2 space-y-1">{children}</ol>,
                                      blockquote: ({ children }) => <blockquote className="border-l-2 border-gold/30 pl-3 my-2 opacity-80 italic">{children}</blockquote>,
                                      hr: () => <hr className="border-border/50 my-4" />,
                                    }}
                                  >
                                    {ch.content}
                                  </ReactMarkdown>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}