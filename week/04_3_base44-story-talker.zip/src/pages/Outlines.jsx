import { useState, useEffect } from 'react';
import { Plus, BookOpen, Loader2, Wand2, Check, Trash2, Archive, ArchiveRestore, Edit3, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { loadApiSettings } from '../lib/difyClient';
import { buildOutlinePrompt, LENGTH_CONFIG } from '../lib/prompts';
import AppLayout from '../components/AppLayout';
import CardItem from '../components/CardItem';

export default function Outlines() {
  const [outlines, setOutlines] = useState([]);
  const [worlds, setWorlds] = useState([]);
  const [characters, setCharacters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState(null);
  const [form, setForm] = useState({ title: '', selectedWorlds: [], selectedChars: [], protagonists: [], length: 'short' });
  const [generating, setGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [activeLength, setActiveLength] = useState(null);
  const [selected, setSelected] = useState(new Set());
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({ title: '', content: '' });

  useEffect(() => {
    Promise.all([
      base44.entities.StoryOutline.list('-updated_date'),
      base44.entities.WorldSetting.filter({ archived: false }),
      base44.entities.Character.filter({ archived: false }),
    ]).then(([o, ws, chars]) => {
      setOutlines(o);
      setWorlds(ws);
      setCharacters(chars);
      setLoading(false);
    });
  }, []);

  const refetch = async () => {
    const data = await base44.entities.StoryOutline.list('-updated_date');
    setOutlines(data);
  };

  const handleGenerate = async () => {
    if (form.selectedWorlds.length === 0) { alert('請至少選擇一個世界觀'); return; }
    const settings = loadApiSettings();
    const apiC = settings.apiC;
    if (!apiC.apiKey) { alert('請先在 API 設定中填入 C 模型的 API Key'); return; }

    const worldContent = worlds.filter(w => form.selectedWorlds.includes(w.id)).map(w => `【${w.title}】\n${w.content}`).join('\n\n');
    const charsContent = characters.filter(c => form.selectedChars.includes(c.id)).map(c => `【${c.name}】 ${c.age ? c.age + '歲，' : ''}${c.role === 'protagonist' ? '主角' : '配角'}\n${c.background}`).join('\n\n');
    const protagonistNames = characters.filter(c => form.protagonists.includes(c.id)).map(c => c.name).join('、') || '未指定';
    const lenConf = LENGTH_CONFIG[form.length];

    const query = buildOutlinePrompt({
      worldContent, charactersContent: charsContent || '（未指定角色）', protagonists: protagonistNames,
      lengthLabel: lenConf.label, lengthDesc: lenConf.desc,
    });

    setGenerating(true);
    setGeneratedContent('');
    try {
      const url = `${apiC.baseUrl.replace(/\/$/, '')}/v1/chat-messages`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiC.apiKey}` },
        body: JSON.stringify({ inputs: {}, query, response_mode: 'blocking', conversation_id: '', user: 'story-talker' }),
      });
      if (!response.ok) throw new Error(`API 錯誤 ${response.status}`);
      const json = await response.json();
      setGeneratedContent(json.answer || '');
    } catch (err) {
      alert(`生成失敗：${err.message}`);
    }
    setGenerating(false);
  };

  const handleSave = async () => {
    if (!generatedContent) return;
    const title = form.title || `大綱 — ${LENGTH_CONFIG[form.length].label}`;
    await base44.entities.StoryOutline.create({
      title, length: form.length, content: generatedContent,
      worldSettingIds: form.selectedWorlds, characterIds: form.selectedChars,
      protagonistIds: form.protagonists, archived: false,
    });
    setMode(null); setGeneratedContent('');
    setForm({ title: '', selectedWorlds: [], selectedChars: [], protagonists: [], length: 'short' });
    refetch();
  };

  const handleEditSave = async () => {
    await base44.entities.StoryOutline.update(editingId, { title: editData.title, content: editData.content });
    setEditingId(null);
    refetch();
  };

  const handleArchive = async (o) => {
    await base44.entities.StoryOutline.update(o.id, { archived: !o.archived });
    refetch();
  };
  const handleDelete = async (id) => {
    if (!confirm('確定刪除？')) return;
    await base44.entities.StoryOutline.delete(id);
    refetch();
  };

  const toggleSelect = (id) => {
    setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };
  const handleBatchArchive = async () => {
    for (const id of selected) await base44.entities.StoryOutline.update(id, { archived: !showArchived });
    setSelected(new Set()); refetch();
  };
  const handleBatchDelete = async () => {
    if (!confirm(`確定刪除 ${selected.size} 個大綱？`)) return;
    for (const id of selected) await base44.entities.StoryOutline.delete(id);
    setSelected(new Set()); refetch();
  };

  const toggleArr = (arr, val) => arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val];

  const visible = outlines.filter(o => {
    if (showArchived ? !o.archived : o.archived) return false;
    if (activeLength && o.length !== activeLength) return false;
    return true;
  });

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto px-6 py-8 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BookOpen className="w-6 h-6 text-gold" />
            <div>
              <h1 className="font-serif text-xl">故事大綱</h1>
              <p className="text-xs text-muted-foreground mt-0.5">使用 C LLM 設計故事大綱</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setShowArchived(s => !s)} className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${showArchived ? 'border-gold/40 text-gold bg-accent' : 'border-border text-muted-foreground'}`}>
              {showArchived ? '返回列表' : '封存箱'}
            </button>
            {!mode && <button onClick={() => setMode('create')} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90">
              <Plus className="w-4 h-4" />新增
            </button>}
          </div>
        </div>

        {!mode && (
          <div className="flex flex-wrap gap-2">
            <button onClick={() => setActiveLength(null)} className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${!activeLength ? 'border-gold/40 text-gold bg-accent' : 'border-border text-muted-foreground'}`}>全部</button>
            {Object.entries(LENGTH_CONFIG).map(([k, v]) => (
              <button key={k} onClick={() => setActiveLength(k === activeLength ? null : k)} className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${activeLength === k ? 'border-gold/40 text-gold bg-accent' : 'border-border text-muted-foreground'}`}>
                {v.label}
              </button>
            ))}
          </div>
        )}

        {/* Batch actions */}
        {selected.size > 0 && (
          <div className="flex items-center gap-3 bg-accent border border-gold/30 rounded-xl px-4 py-2.5 animate-fade-in">
            <span className="text-xs text-gold font-medium">已選取 {selected.size} 個</span>
            <div className="flex gap-2 ml-auto">
              <button onClick={handleBatchArchive} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-muted hover:bg-muted/80 text-foreground transition-colors">
                {showArchived ? <ArchiveRestore className="w-3.5 h-3.5" /> : <Archive className="w-3.5 h-3.5" />}
                {showArchived ? '取消封存' : '封存'}
              </button>
              <button onClick={handleBatchDelete} className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-destructive/20 hover:bg-destructive/30 text-destructive transition-colors">
                <Trash2 className="w-3.5 h-3.5" />刪除
              </button>
              <button onClick={() => setSelected(new Set())} className="text-xs px-3 py-1.5 rounded-lg bg-muted text-muted-foreground hover:bg-muted/80">取消</button>
            </div>
          </div>
        )}

        {/* Create Form */}
        {mode === 'create' && (
          <div className="bg-card border border-border rounded-2xl p-6 space-y-5 animate-fade-in">
            <h2 className="font-serif text-base text-gold">新增故事大綱</h2>
            <input type="text" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              placeholder="大綱標題（選填）"
              className="w-full bg-input border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <div>
              <label className="text-xs text-muted-foreground mb-2 block">故事長度</label>
              <div className="flex flex-wrap gap-2">
                {Object.entries(LENGTH_CONFIG).map(([k, v]) => (
                  <button key={k} onClick={() => setForm(f => ({ ...f, length: k }))}
                    className={`text-xs px-3 py-2 rounded-xl border transition-colors ${form.length === k ? 'border-gold bg-accent text-foreground' : 'border-border text-muted-foreground'}`}>
                    <div className="font-medium">{v.label}</div>
                    <div className="opacity-60">{v.wordCount.toLocaleString()}字</div>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-2 block">選擇世界觀</label>
              <div className="flex flex-wrap gap-2">
                {worlds.map(w => (
                  <button key={w.id} onClick={() => setForm(f => ({ ...f, selectedWorlds: toggleArr(f.selectedWorlds, w.id) }))}
                    className={`text-xs px-3 py-1.5 rounded-xl border transition-colors ${form.selectedWorlds.includes(w.id) ? 'border-gold/40 bg-accent text-foreground' : 'border-border text-muted-foreground'}`}>
                    {w.title}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-2 block">選擇角色</label>
              <div className="flex flex-wrap gap-2">
                {characters.map(c => (
                  <button key={c.id} onClick={() => setForm(f => ({ ...f, selectedChars: toggleArr(f.selectedChars, c.id) }))}
                    className={`text-xs px-3 py-1.5 rounded-xl border transition-colors ${form.selectedChars.includes(c.id) ? 'border-gold/40 bg-accent text-foreground' : 'border-border text-muted-foreground'}`}>
                    {c.name}
                  </button>
                ))}
              </div>
            </div>
            {form.selectedChars.length > 0 && (
              <div>
                <label className="text-xs text-muted-foreground mb-2 block">指定主角</label>
                <div className="flex flex-wrap gap-2">
                  {characters.filter(c => form.selectedChars.includes(c.id)).map(c => (
                    <button key={c.id} onClick={() => setForm(f => ({ ...f, protagonists: toggleArr(f.protagonists, c.id) }))}
                      className={`text-xs px-3 py-1.5 rounded-xl border transition-colors ${form.protagonists.includes(c.id) ? 'border-amber-400/60 bg-amber-500/10 text-amber-300' : 'border-border text-muted-foreground'}`}>
                      ★ {c.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <div className="flex gap-3">
              <button onClick={handleGenerate} disabled={generating}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 disabled:opacity-50">
                {generating ? <><Loader2 className="w-4 h-4 animate-spin" />生成中…</> : <><Wand2 className="w-4 h-4" />AI 生成大綱</>}
              </button>
              <button onClick={() => { setMode(null); setGeneratedContent(''); }} className="px-5 py-2.5 bg-muted text-muted-foreground rounded-xl text-sm hover:bg-muted/80">取消</button>
            </div>
            {generatedContent && (
              <div className="space-y-3">
                <textarea value={generatedContent} onChange={e => setGeneratedContent(e.target.value)} rows={10}
                  className="w-full bg-input border border-border rounded-xl px-4 py-3 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring font-serif leading-relaxed" />
                <button onClick={handleSave} className="w-full py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90">儲存大綱</button>
              </div>
            )}
          </div>
        )}

        {/* Edit form */}
        {editingId && (
          <div className="bg-card border border-gold/30 rounded-2xl p-5 space-y-3 animate-fade-in">
            <h3 className="font-serif text-sm text-gold">編輯大綱</h3>
            <input value={editData.title} onChange={e => setEditData(d => ({ ...d, title: e.target.value }))}
              className="w-full bg-input border border-border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-ring" />
            <textarea value={editData.content} onChange={e => setEditData(d => ({ ...d, content: e.target.value }))} rows={10}
              className="w-full bg-input border border-border rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring font-serif leading-relaxed" />
            <div className="flex gap-3">
              <button onClick={handleEditSave} className="flex-1 py-2 bg-primary text-primary-foreground rounded-xl text-sm hover:opacity-90">儲存</button>
              <button onClick={() => setEditingId(null)} className="px-4 py-2 bg-muted text-muted-foreground rounded-xl text-sm">取消</button>
            </div>
          </div>
        )}

        {/* List */}
        {loading ? (
          <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : visible.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground font-serif">尚無大綱</div>
        ) : (
          <div className="space-y-3">
            {visible.map(o => (
              <div key={o.id} className="flex items-start gap-2">
                <button onClick={() => toggleSelect(o.id)}
                  className={`mt-4 flex-shrink-0 w-5 h-5 rounded border transition-colors flex items-center justify-center ${selected.has(o.id) ? 'bg-primary border-primary' : 'border-border hover:border-gold/50'}`}>
                  {selected.has(o.id) && <Check className="w-3 h-3 text-primary-foreground" />}
                </button>
                <div className="flex-1">
                  <CardItem
                    title={o.title}
                    subtitle={LENGTH_CONFIG[o.length]?.label || o.length}
                    content={o.content}
                    archived={o.archived}
                    accent="default"
                    onEdit={() => { setEditingId(o.id); setEditData({ title: o.title, content: o.content }); }}
                    onArchive={() => handleArchive(o)}
                    onDelete={() => handleDelete(o.id)}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}