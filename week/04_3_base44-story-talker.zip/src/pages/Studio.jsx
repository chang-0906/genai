import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play, Square, Settings, Download, ChevronRight, RotateCcw, Edit3, ScrollText, Sun, Moon, History } from 'lucide-react';
import ConversationTheater from '../components/ConversationTheater';
import ApiSettingsPanel from '../components/ApiSettingsPanel';
import ExportPanel from '../components/ExportPanel';
import { loadProjects, saveProject, loadSettings, saveSettings } from '../lib/storageManager';
import { streamLLM } from '../lib/llmClient';

const PANELS = { none: 'none', settings: 'settings', export: 'export', history: 'history' };

export default function Studio() {
  const { projectId } = useParams();
  const [project, setProject] = useState(null);
  const [globalSettings, setGlobalSettings] = useState(loadSettings());
  const [panel, setPanel] = useState(PANELS.none);
  const [isRunning, setIsRunning] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [afterRound, setAfterRound] = useState(null); // null | 'done'
  const [correctionPrompt, setCorrectionPrompt] = useState('');
  const [continuationRounds, setContinuationRounds] = useState(3);
  const [theme, setTheme] = useState(loadSettings().theme);
  const abortRef = useRef(false);

  useEffect(() => {
    const all = loadProjects();
    const found = all.find(p => p.id === projectId);
    if (found) setProject(found);
    document.documentElement.classList.toggle('light', theme === 'light');
  }, [projectId]);

  const updateProject = useCallback((updates) => {
    setProject(prev => {
      const next = { ...prev, ...updates };
      saveProject(next);
      return next;
    });
  }, []);

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    const s = { ...globalSettings, theme: next };
    setGlobalSettings(s);
    saveSettings(s);
    document.documentElement.classList.toggle('light', next === 'light');
  };

  const handleSaveSettings = (s) => {
    setGlobalSettings(s);
    saveSettings(s);
    setPanel(PANELS.none);
  };

  // Build messages for A (director)
  const buildDirectorMessages = (project, userPromptOverride) => {
    const msgs = [
      { role: 'system', content: project.setup.systemPromptA || '你是一位優秀的故事導演，負責評估並引導故事的走向、節奏與深度。' },
    ];
    // Add conversation history
    for (const m of project.messages) {
      if (m.role === 'director') {
        msgs.push({ role: 'assistant', content: m.content });
      } else if (m.role === 'writer') {
        msgs.push({ role: 'user', content: `[作家的故事內容]\n${m.content}` });
      }
    }
    // Initial or continuation prompt
    const up = userPromptOverride || project.setup.userPrompt;
    msgs.push({ role: 'user', content: up });
    return msgs;
  };

  const buildWriterMessages = (project, directorInstruction) => {
    const msgs = [
      { role: 'system', content: project.setup.systemPromptB || '你是一位才華洋溢的故事作家，根據導演的指示用優美的文字創作故事。' },
    ];
    for (const m of project.messages) {
      if (m.role === 'writer') {
        msgs.push({ role: 'assistant', content: m.content });
      } else if (m.role === 'director') {
        msgs.push({ role: 'user', content: m.content });
      }
    }
    msgs.push({ role: 'user', content: directorInstruction });
    return msgs;
  };

  const getApiConfig = (apiConf) => {
    if (apiConf.type === 'dify') {
      return { type: 'dify', baseUrl: apiConf.difyBaseUrl, apiKey: apiConf.difyApiKey };
    }
    return { type: 'openai', baseUrl: apiConf.baseUrl, model: apiConf.model, apiKey: apiConf.apiKey };
  };

  const runRounds = async (roundCount, initialPrompt) => {
    if (!project) return;
    abortRef.current = false;
    setIsRunning(true);
    setAfterRound(null);

    // Save a version snapshot before starting
    const versionEntry = {
      id: Date.now(),
      createdAt: new Date().toISOString(),
      label: `版本 ${(project.versions?.length || 0) + 1}`,
      messages: [...(project.messages || [])],
    };
    const updatedVersions = [...(project.versions || []), versionEntry];

    let currentMessages = [...(project.messages || [])];
    let currentProject = { ...project, versions: updatedVersions, status: 'running' };
    saveProject(currentProject);
    setProject(currentProject);

    const promptForDirector = initialPrompt || project.setup.userPrompt;

    for (let round = 1; round <= roundCount; round++) {
      if (abortRef.current) break;

      // ── A: Director ──
      const directorMsgs = buildDirectorMessages({ ...currentProject, messages: currentMessages }, round === 1 ? promptForDirector : undefined);
      let directorText = '';

      const dirRound = currentMessages.filter(m => m.role === 'director').length + 1;
      setStreamingMessage({ role: 'director', content: '', round: dirRound });

      await new Promise((resolve) => {
        streamLLM({
          apiConfig: getApiConfig(globalSettings.apiA),
          messages: directorMsgs,
          onChunk: (_, full) => {
            directorText = full;
            setStreamingMessage({ role: 'director', content: full, round: dirRound });
          },
          onDone: (full) => {
            directorText = full;
            resolve();
          },
          onError: (err) => {
            console.error('Director error:', err);
            directorText = `[錯誤: ${err.message}]`;
            resolve();
          },
        });
      });

      if (abortRef.current) break;

      const dirMsg = { role: 'director', content: directorText, round: dirRound };
      currentMessages = [...currentMessages, dirMsg];
      setStreamingMessage(null);
      currentProject = { ...currentProject, messages: currentMessages };
      setProject(currentProject);
      saveProject(currentProject);

      await new Promise(r => setTimeout(r, 300));

      // ── B: Writer ──
      const writerMsgs = buildWriterMessages({ ...currentProject, messages: currentMessages }, directorText);
      let writerText = '';

      const wrtRound = currentMessages.filter(m => m.role === 'writer').length + 1;
      setStreamingMessage({ role: 'writer', content: '', round: wrtRound });

      await new Promise((resolve) => {
        streamLLM({
          apiConfig: getApiConfig(globalSettings.apiB),
          messages: writerMsgs,
          onChunk: (_, full) => {
            writerText = full;
            setStreamingMessage({ role: 'writer', content: full, round: wrtRound });
          },
          onDone: (full) => {
            writerText = full;
            resolve();
          },
          onError: (err) => {
            console.error('Writer error:', err);
            writerText = `[錯誤: ${err.message}]`;
            resolve();
          },
        });
      });

      if (abortRef.current) break;

      const wrtMsg = { role: 'writer', content: writerText, round: wrtRound };
      currentMessages = [...currentMessages, wrtMsg];
      setStreamingMessage(null);
      currentProject = { ...currentProject, messages: currentMessages };
      setProject(currentProject);
      saveProject(currentProject);

      await new Promise(r => setTimeout(r, 300));
    }

    const finalProject = { ...currentProject, messages: currentMessages, status: 'completed' };
    saveProject(finalProject);
    setProject(finalProject);
    setIsRunning(false);
    setAfterRound('done');
  };

  const handleStart = () => {
    if (!project?.setup?.userPrompt?.trim()) return;
    updateProject({ messages: [], status: 'draft' });
    setProject(prev => ({ ...prev, messages: [] }));
    setTimeout(() => runRounds(project.setup.rounds || 3), 100);
  };

  const handleStop = () => {
    abortRef.current = true;
    setIsRunning(false);
    setStreamingMessage(null);
  };

  const handleContinue = () => {
    setAfterRound(null);
    runRounds(continuationRounds);
  };

  const handleCorrect = () => {
    if (!correctionPrompt.trim()) return;
    setAfterRound(null);
    const prompt = `[使用者修正要求]\n${correctionPrompt}\n\n請根據以上修正要求，重新評估並引導故事的走向。`;
    setCorrectionPrompt('');
    runRounds(continuationRounds, prompt);
  };

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground font-serif">載入中…</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top Bar */}
      <header className="border-b border-border/50 px-4 py-3 flex items-center gap-3 flex-shrink-0">
        <Link to="/" className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <div className="flex-1 min-w-0">
          <EditableTitle project={project} onSave={t => updateProject({ title: t })} />
        </div>
        <div className="flex items-center gap-1.5">
          <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground">
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          <button onClick={() => setPanel(p => p === PANELS.history ? PANELS.none : PANELS.history)} className={`p-2 rounded-lg transition-colors ${panel === PANELS.history ? 'bg-accent text-accent-foreground' : 'hover:bg-muted text-muted-foreground'}`}>
            <History className="w-4 h-4" />
          </button>
          <button onClick={() => setPanel(p => p === PANELS.export ? PANELS.none : PANELS.export)} className={`p-2 rounded-lg transition-colors ${panel === PANELS.export ? 'bg-accent text-accent-foreground' : 'hover:bg-muted text-muted-foreground'}`} disabled={project.messages.length === 0}>
            <Download className="w-4 h-4" />
          </button>
          <button onClick={() => setPanel(p => p === PANELS.settings ? PANELS.none : PANELS.settings)} className={`p-2 rounded-lg transition-colors ${panel === PANELS.settings ? 'bg-accent text-accent-foreground' : 'hover:bg-muted text-muted-foreground'}`}>
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Main: Theater */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto">
            <ConversationTheater
              messages={project.messages}
              streamingMessage={streamingMessage}
              isRunning={isRunning}
              autoScroll={autoScroll}
            />
          </div>

          {/* Bottom Controls */}
          <div className="border-t border-border/50 px-4 py-4 space-y-3 flex-shrink-0">
            {afterRound === 'done' && !isRunning && (
              <AfterRoundPanel
                continuationRounds={continuationRounds}
                setContinuationRounds={setContinuationRounds}
                correctionPrompt={correctionPrompt}
                setCorrectionPrompt={setCorrectionPrompt}
                onContinue={handleContinue}
                onCorrect={handleCorrect}
                onExport={() => setPanel(PANELS.export)}
              />
            )}

            {!afterRound && (
              <SetupBar
                project={project}
                onUpdate={updates => updateProject({ setup: { ...project.setup, ...updates } })}
                isRunning={isRunning}
                onStart={handleStart}
                onStop={handleStop}
                autoScroll={autoScroll}
                onToggleScroll={() => setAutoScroll(s => !s)}
              />
            )}
          </div>
        </div>

        {/* Side Panel */}
        {panel !== PANELS.none && (
          <aside className="w-80 border-l border-border/50 bg-card overflow-y-auto flex-shrink-0">
            <div className="p-5">
              {panel === PANELS.settings && (
                <ApiSettingsPanel settings={globalSettings} onSave={handleSaveSettings} />
              )}
              {panel === PANELS.export && (
                <ExportPanel project={project} onClose={() => setPanel(PANELS.none)} />
              )}
              {panel === PANELS.history && (
                <VersionHistory project={project} onRestore={(msgs) => {
                  updateProject({ messages: msgs });
                  setPanel(PANELS.none);
                }} />
              )}
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────

function EditableTitle({ project, onSave }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(project.title);

  if (editing) {
    return (
      <input
        autoFocus
        value={val}
        onChange={e => setVal(e.target.value)}
        onBlur={() => { onSave(val); setEditing(false); }}
        onKeyDown={e => e.key === 'Enter' && (onSave(val), setEditing(false))}
        className="bg-transparent border-b border-gold/50 text-sm font-serif focus:outline-none w-full max-w-xs"
      />
    );
  }
  return (
    <button onClick={() => setEditing(true)} className="flex items-center gap-1.5 hover:text-gold transition-colors group">
      <span className="font-serif text-sm truncate max-w-xs">{project.title}</span>
      <Edit3 className="w-3 h-3 opacity-0 group-hover:opacity-60 transition-opacity" />
    </button>
  );
}

function SetupBar({ project, onUpdate, isRunning, onStart, onStop, autoScroll, onToggleScroll }) {
  const [expanded, setExpanded] = useState(true);
  const s = project.setup;

  return (
    <div className="space-y-3">
      <button onClick={() => setExpanded(e => !e)} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
        <ScrollText className="w-3.5 h-3.5" />
        <span>故事設定</span>
        <ChevronRight className={`w-3 h-3 transition-transform ${expanded ? 'rotate-90' : ''}`} />
      </button>

      {expanded && (
        <div className="space-y-3 animate-fade-in">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-amber-500/70 mb-1 block">🎬 導演 System Prompt (A)</label>
              <textarea
                value={s.systemPromptA}
                onChange={e => onUpdate({ systemPromptA: e.target.value })}
                placeholder="你是一位優秀的故事導演…"
                rows={3}
                disabled={isRunning}
                className="w-full bg-[hsl(var(--director-bg))] border border-[hsl(var(--director-border))] rounded-xl px-3 py-2 text-xs resize-none focus:outline-none focus:ring-1 focus:ring-ring disabled:opacity-50"
              />
            </div>
            <div>
              <label className="text-xs text-sky-400/70 mb-1 block">✍️ 作家 System Prompt (B)</label>
              <textarea
                value={s.systemPromptB}
                onChange={e => onUpdate({ systemPromptB: e.target.value })}
                placeholder="你是一位才華洋溢的故事作家…"
                rows={3}
                disabled={isRunning}
                className="w-full bg-[hsl(var(--writer-bg))] border border-[hsl(var(--writer-border))] rounded-xl px-3 py-2 text-xs resize-none focus:outline-none focus:ring-1 focus:ring-ring disabled:opacity-50"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-muted-foreground mb-1 block">故事設定 / 主題</label>
            <textarea
              value={s.userPrompt}
              onChange={e => onUpdate({ userPrompt: e.target.value })}
              placeholder="請描述你想要的故事主題、設定、角色、世界觀…"
              rows={3}
              disabled={isRunning}
              className="w-full bg-input border border-border rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring disabled:opacity-50"
            />
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <label className="text-xs text-muted-foreground">回合數</label>
              <input
                type="number"
                min={1} max={20}
                value={s.rounds}
                onChange={e => onUpdate({ rounds: parseInt(e.target.value) || 1 })}
                disabled={isRunning}
                className="w-16 bg-input border border-border rounded-lg px-2 py-1 text-sm text-center focus:outline-none focus:ring-1 focus:ring-ring disabled:opacity-50"
              />
            </div>

            <button
              onClick={onToggleScroll}
              className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${autoScroll ? 'border-gold/40 text-gold bg-accent' : 'border-border text-muted-foreground hover:border-border/80'}`}
            >
              自動滾動 {autoScroll ? '✓' : ''}
            </button>

            <div className="flex-1" />

            {isRunning ? (
              <button onClick={onStop} className="flex items-center gap-2 px-5 py-2.5 bg-destructive text-destructive-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity">
                <Square className="w-4 h-4" />
                停止
              </button>
            ) : (
              <button
                onClick={onStart}
                disabled={!s.userPrompt?.trim()}
                className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Play className="w-4 h-4" />
                開始創作
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function AfterRoundPanel({ continuationRounds, setContinuationRounds, correctionPrompt, setCorrectionPrompt, onContinue, onCorrect, onExport }) {
  const [mode, setMode] = useState(null); // null | 'continue' | 'correct'

  return (
    <div className="bg-card border border-border rounded-2xl p-4 space-y-4 animate-fade-in gold-glow">
      <div className="flex items-center gap-2">
        <span className="text-gold font-serif text-sm">✨ 本輪創作完成</span>
      </div>

      {!mode && (
        <div className="flex flex-wrap gap-2">
          <button onClick={() => setMode('continue')} className="flex items-center gap-1.5 px-4 py-2 bg-primary text-primary-foreground rounded-xl text-sm hover:opacity-90 transition-opacity">
            <Play className="w-3.5 h-3.5" />
            繼續創作
          </button>
          <button onClick={() => setMode('correct')} className="flex items-center gap-1.5 px-4 py-2 bg-muted text-foreground rounded-xl text-sm hover:bg-muted/80 transition-colors">
            <Edit3 className="w-3.5 h-3.5" />
            修正故事
          </button>
          <button onClick={onExport} className="flex items-center gap-1.5 px-4 py-2 bg-muted text-foreground rounded-xl text-sm hover:bg-muted/80 transition-colors">
            <Download className="w-3.5 h-3.5" />
            匯出
          </button>
        </div>
      )}

      {mode === 'continue' && (
        <div className="space-y-3 animate-fade-in">
          <div className="flex items-center gap-3">
            <label className="text-xs text-muted-foreground">繼續回合數</label>
            <input type="number" min={1} max={20} value={continuationRounds} onChange={e => setContinuationRounds(parseInt(e.target.value) || 1)}
              className="w-16 bg-input border border-border rounded-lg px-2 py-1 text-sm text-center focus:outline-none focus:ring-1 focus:ring-ring" />
          </div>
          <div className="flex gap-2">
            <button onClick={onContinue} className="flex-1 py-2 bg-primary text-primary-foreground rounded-xl text-sm hover:opacity-90 transition-opacity">繼續</button>
            <button onClick={() => setMode(null)} className="px-4 py-2 bg-muted text-muted-foreground rounded-xl text-sm hover:bg-muted/80">返回</button>
          </div>
        </div>
      )}

      {mode === 'correct' && (
        <div className="space-y-3 animate-fade-in">
          <textarea
            value={correctionPrompt}
            onChange={e => setCorrectionPrompt(e.target.value)}
            placeholder="描述需要修正的地方，例如：請調整角色性格、改變故事結局方向…"
            rows={3}
            className="w-full bg-input border border-border rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-ring"
          />
          <div className="flex items-center gap-3">
            <label className="text-xs text-muted-foreground">修正回合數</label>
            <input type="number" min={1} max={20} value={continuationRounds} onChange={e => setContinuationRounds(parseInt(e.target.value) || 1)}
              className="w-16 bg-input border border-border rounded-lg px-2 py-1 text-sm text-center focus:outline-none focus:ring-1 focus:ring-ring" />
          </div>
          <div className="flex gap-2">
            <button onClick={onCorrect} disabled={!correctionPrompt.trim()} className="flex-1 py-2 bg-primary text-primary-foreground rounded-xl text-sm hover:opacity-90 transition-opacity disabled:opacity-40">送出修正</button>
            <button onClick={() => setMode(null)} className="px-4 py-2 bg-muted text-muted-foreground rounded-xl text-sm hover:bg-muted/80">返回</button>
          </div>
        </div>
      )}
    </div>
  );
}

function VersionHistory({ project, onRestore }) {
  const versions = project.versions || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <History className="w-5 h-5 text-gold" />
        <h3 className="font-serif text-base">版本歷史</h3>
      </div>

      {versions.length === 0 ? (
        <p className="text-muted-foreground text-sm">尚無版本記錄</p>
      ) : (
        <div className="space-y-2">
          {[...versions].reverse().map(v => (
            <div key={v.id} className="border border-border rounded-xl p-3 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-medium">{v.label}</p>
                  <p className="text-xs text-muted-foreground">{new Date(v.createdAt).toLocaleString('zh-TW')}</p>
                  <p className="text-xs text-muted-foreground">{v.messages.length} 則訊息</p>
                </div>
                <button
                  onClick={() => onRestore(v.messages)}
                  className="flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg bg-accent text-accent-foreground hover:bg-accent/80 transition-colors flex-shrink-0"
                >
                  <RotateCcw className="w-3 h-3" />
                  還原
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}