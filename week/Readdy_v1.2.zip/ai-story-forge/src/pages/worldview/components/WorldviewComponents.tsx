import { useState } from 'react';
import { worldviewsDB, type WorldView } from '../../../utils/db';
import { expandWorldviewIdea, extractWorldviewFromNovel, loadApiSettings } from '../../../utils/difyApi';
import ContentCard from '../../../components/base/ContentCard';
import { exportAsMarkdown, exportAsPDF } from '../../../utils/exportUtils';

interface ManualFormData {
  title: string;
  geography: string;
  history: string;
  society: string;
  rules: string;
  culture: string;
}

const EMPTY_FORM: ManualFormData = { title: '', geography: '', history: '', society: '', rules: '', culture: '' };

interface ManualCreationProps {
  onSaved: (wv: WorldView) => void;
}

export function ManualCreation({ onSaved }: ManualCreationProps) {
  const [form, setForm] = useState<ManualFormData>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const update = (key: keyof ManualFormData, val: string) => setForm((p) => ({ ...p, [key]: val }));

  const handleSave = async () => {
    if (!form.title.trim()) return;
    setSaving(true);
    try {
      const content = [
        form.geography && `【地理環境】\n${form.geography}`,
        form.history && `【歷史背景】\n${form.history}`,
        form.society && `【社會結構】\n${form.society}`,
        form.rules && `【獨特規則】\n${form.rules}`,
        form.culture && `【文化特色】\n${form.culture}`,
      ].filter(Boolean).join('\n\n');

      const wv = await worldviewsDB.create({ title: form.title, content, method: 'manual', archived: false });
      onSaved(wv);
      setForm(EMPTY_FORM);
    } finally {
      setSaving(false);
    }
  };

  const fields: { key: keyof ManualFormData; label: string; icon: string; placeholder: string }[] = [
    { key: 'geography', label: '地理環境', icon: 'ri-map-2-line', placeholder: '描述地形、氣候、地標...' },
    { key: 'history', label: '歷史背景', icon: 'ri-ancient-gate-line', placeholder: '重要歷史事件、年代...' },
    { key: 'society', label: '社會結構', icon: 'ri-community-line', placeholder: '政治體制、階級、組織...' },
    { key: 'rules', label: '獨特規則 / 法則', icon: 'ri-magic-line', placeholder: '魔法系統、科技規則、禁忌...' },
    { key: 'culture', label: '文化特色', icon: 'ri-palette-line', placeholder: '習俗、藝術、宗教信仰...' },
  ];

  return (
    <div className="space-y-5">
      <div>
        <label className="block text-sm font-semibold text-stone-700 mb-2">世界觀名稱 *</label>
        <input
          value={form.title}
          onChange={(e) => update('title', e.target.value)}
          placeholder="為這個世界取一個名字..."
          className="w-full px-4 py-3 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 bg-white"
        />
      </div>

      <div className="grid grid-cols-1 gap-4">
        {fields.map((f) => (
          <div key={f.key}>
            <label className="flex items-center gap-2 text-sm font-semibold text-stone-700 mb-2">
              <div className="w-5 h-5 flex items-center justify-center">
                <i className={`${f.icon} text-amber-500`} />
              </div>
              {f.label}
            </label>
            <textarea
              value={form[f.key]}
              onChange={(e) => update(f.key, e.target.value)}
              placeholder={f.placeholder}
              rows={3}
              className="w-full px-4 py-3 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 bg-white resize-none leading-relaxed"
            />
          </div>
        ))}
      </div>

      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={!form.title.trim() || saving}
          className="flex items-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
        >
          {saving ? <><i className="ri-loader-4-line animate-spin" /> 儲存中...</> : <><i className="ri-save-line" /> 儲存世界觀</>}
        </button>
      </div>
    </div>
  );
}

interface AICreationProps {
  onSaved: (wv: WorldView) => void;
  mode: 'expand' | 'extract';
}

export function AICreation({ onSaved, mode }: AICreationProps) {
  const [title, setTitle] = useState('');
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const handleGenerate = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setError('');
    setResult('');
    try {
      const settings = loadApiSettings();
      const answer = mode === 'expand'
        ? await expandWorldviewIdea(settings.aLlm, input)
        : await extractWorldviewFromNovel(settings.aLlm, input);
      setResult(answer);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : '生成失敗，請確認 API 設定');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!title.trim() || !result.trim()) return;
    setSaving(true);
    try {
      const wv = await worldviewsDB.create({ title, content: result, method: mode === 'expand' ? 'ai' : 'extract', archived: false });
      onSaved(wv);
      setTitle('');
      setInput('');
      setResult('');
    } finally {
      setSaving(false);
    }
  };

  const inputLabel = mode === 'expand' ? '你的世界觀想法' : '現有小說或故事內容';
  const inputPlaceholder = mode === 'expand'
    ? '輸入你對這個世界的想法，可以是關鍵字、片段描述或簡短概念...'
    : '貼入小說、故事或相關資料，AI 將從中提取世界觀設定...';
  const btnLabel = mode === 'expand' ? '讓 AI 延伸擴展' : '讓 AI 提取世界觀';
  const btnIcon = mode === 'expand' ? 'ri-sparkling-line' : 'ri-scissors-cut-line';

  return (
    <div className="space-y-5">
      <div>
        <label className="block text-sm font-semibold text-stone-700 mb-2">{inputLabel}</label>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={inputPlaceholder}
          rows={6}
          className="w-full px-4 py-3 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 bg-white resize-none leading-relaxed"
        />
      </div>

      <button
        onClick={handleGenerate}
        disabled={!input.trim() || loading}
        className="flex items-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
      >
        {loading
          ? <><i className="ri-loader-4-line animate-spin" /> AI 生成中...</>
          : <><i className={btnIcon} /> {btnLabel}</>
        }
      </button>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-700 flex gap-2">
          <i className="ri-error-warning-line flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {result && (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <i className="ri-sparkling-2-line text-amber-500" />
              <span className="text-sm font-semibold text-amber-800">AI 生成結果</span>
              <span className="text-xs text-amber-600 ml-auto">可以在下方編輯後儲存</span>
            </div>
            <textarea
              value={result}
              onChange={(e) => setResult(e.target.value)}
              className="w-full min-h-56 text-sm text-stone-700 bg-white border border-amber-200 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-amber-400 resize-y leading-relaxed"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-stone-700 mb-2">為此世界觀命名 *</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="為這個 AI 生成的世界命名..."
              className="w-full px-4 py-3 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 bg-white"
            />
          </div>

          <div className="flex justify-end">
            <button
              onClick={handleSave}
              disabled={!title.trim() || saving}
              className="flex items-center gap-2 px-6 py-3 bg-stone-800 hover:bg-stone-900 disabled:opacity-50 text-white rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
            >
              {saving ? <><i className="ri-loader-4-line animate-spin" /> 儲存中...</> : <><i className="ri-save-line" /> 儲存世界觀</>}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

interface WorldviewListProps {
  worldviews: WorldView[];
  onUpdate: (id: string, data: Partial<WorldView>) => void;
  onDelete: (id: string) => void;
}

export function WorldviewList({ worldviews, onUpdate, onDelete }: WorldviewListProps) {
  const methodLabel: Record<string, { label: string; color: string }> = {
    manual: { label: '手動建立', color: 'bg-stone-500' },
    ai: { label: 'AI 擴展', color: 'bg-amber-500' },
    extract: { label: 'AI 提取', color: 'bg-teal-500' },
  };

  if (worldviews.length === 0) {
    return (
      <div className="text-center py-16 text-stone-400">
        <div className="w-16 h-16 flex items-center justify-center mx-auto mb-3">
          <i className="ri-earth-line text-4xl" />
        </div>
        <p className="font-medium">尚無世界觀</p>
        <p className="text-sm mt-1">在上方選擇一種方式開始創造你的第一個世界吧！</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
      {worldviews.map((wv) => {
        const m = methodLabel[wv.method] || methodLabel.manual;
        return (
          <ContentCard
            key={wv.id}
            title={wv.title}
            content={wv.content}
            badges={[{ label: m.label, color: m.color }]}
            onEdit={(content, title) => onUpdate(wv.id, { content, title: title ?? wv.title })}
            onArchive={() => onUpdate(wv.id, { archived: true })}
            onDelete={() => onDelete(wv.id)}
            onExportMd={() => exportAsMarkdown(wv.title, wv.content)}
            onExportPdf={() => exportAsPDF(wv.title, wv.content)}
          />
        );
      })}
    </div>
  );
}
