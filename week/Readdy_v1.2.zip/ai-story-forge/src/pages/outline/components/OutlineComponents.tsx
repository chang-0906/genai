import { useState } from 'react';
import type { WorldView, Character, Outline } from '../../../utils/db';
import ContentCard from '../../../components/base/ContentCard';
import { exportAsMarkdown, exportAsPDF } from '../../../utils/exportUtils';

export const STORY_LENGTHS = [
  { key: 'ultrashort', label: '超短篇', sub: '~500 字', wordCount: 500, chapters: null, icon: 'ri-article-line', color: 'bg-sky-100 text-sky-700 border-sky-300' },
  { key: 'short', label: '短篇', sub: '~5,000 字', wordCount: 5000, chapters: null, icon: 'ri-file-text-line', color: 'bg-teal-100 text-teal-700 border-teal-300' },
  { key: 'medium', label: '中篇', sub: '~15,000 字 · 3 章', wordCount: 15000, chapters: 3, icon: 'ri-book-2-line', color: 'bg-amber-100 text-amber-700 border-amber-300' },
  { key: 'long', label: '長篇', sub: '~40,000 字 · 10 章', wordCount: 40000, chapters: 10, icon: 'ri-book-open-line', color: 'bg-orange-100 text-orange-700 border-orange-300' },
  { key: 'ultralong', label: '超長篇', sub: '~100,000 字 · 20 章', wordCount: 100000, chapters: 20, icon: 'ri-booklet-line', color: 'bg-rose-100 text-rose-700 border-rose-300' },
] as const;

export type StoryLengthKey = typeof STORY_LENGTHS[number]['key'];

interface WorldviewSelectorProps {
  worldviews: WorldView[];
  selectedId: string;
  onSelect: (id: string) => void;
}

export function WorldviewSelectorOutline({ worldviews, selectedId, onSelect }: WorldviewSelectorProps) {
  if (worldviews.length === 0) {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800 flex gap-2">
        <i className="ri-information-line flex-shrink-0 mt-0.5" />
        <span>尚無世界觀，請先前往「世界觀創造」頁面建立。</span>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {worldviews.map((wv) => (
        <button
          key={wv.id}
          onClick={() => onSelect(wv.id)}
          className={`text-left px-4 py-3 rounded-xl border-2 transition-all cursor-pointer ${
            selectedId === wv.id ? 'border-teal-500 bg-teal-50' : 'border-stone-200 bg-white hover:border-teal-300'
          }`}
        >
          <p className="font-semibold text-sm text-stone-800 truncate">{wv.title}</p>
          <p className="text-xs text-stone-500 mt-1 line-clamp-2">{wv.content.slice(0, 80)}...</p>
        </button>
      ))}
    </div>
  );
}

interface CharacterSelectorProps {
  characters: Character[];
  selectedIds: string[];
  onToggle: (id: string) => void;
}

export function CharacterSelector({ characters, selectedIds, onToggle }: CharacterSelectorProps) {
  if (characters.length === 0) {
    return (
      <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 text-sm text-rose-800 flex gap-2">
        <i className="ri-information-line flex-shrink-0 mt-0.5" />
        <span>尚無角色，請先前往「角色設定」頁面建立角色。</span>
      </div>
    );
  }
  return (
    <div className="space-y-3">
      <p className="text-sm text-stone-500">選擇要加入故事的角色（可多選）</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {characters.map((c) => {
          const isSelected = selectedIds.includes(c.id);
          return (
            <button
              key={c.id}
              onClick={() => onToggle(c.id)}
              className={`text-left px-4 py-3 rounded-xl border-2 transition-all cursor-pointer flex items-start gap-3 ${
                isSelected ? 'border-teal-500 bg-teal-50' : 'border-stone-200 bg-white hover:border-teal-300'
              }`}
            >
              <div className={`w-7 h-7 flex items-center justify-center rounded-full flex-shrink-0 mt-0.5 ${isSelected ? 'bg-teal-500' : 'bg-stone-200'}`}>
                {isSelected
                  ? <i className="ri-check-line text-white text-xs" />
                  : <i className="ri-user-line text-stone-500 text-xs" />
                }
              </div>
              <div className="min-w-0">
                <p className="font-semibold text-sm text-stone-800">{c.name}</p>
                <p className="text-xs text-stone-500">{c.age} 歲 · {c.worldviewTitle}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

interface StoryLengthSelectorProps {
  selected: StoryLengthKey | '';
  onSelect: (key: StoryLengthKey) => void;
}

export function StoryLengthSelector({ selected, onSelect }: StoryLengthSelectorProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
      {STORY_LENGTHS.map((s) => (
        <button
          key={s.key}
          onClick={() => onSelect(s.key)}
          className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all cursor-pointer ${
            selected === s.key
              ? 'border-teal-500 bg-teal-50'
              : 'border-stone-200 bg-white hover:border-teal-300'
          }`}
        >
          <div className={`w-10 h-10 flex items-center justify-center rounded-xl border ${s.color}`}>
            <i className={`${s.icon} text-lg`} />
          </div>
          <p className="font-bold text-sm text-stone-800">{s.label}</p>
          <p className="text-xs text-stone-500 text-center">{s.sub}</p>
        </button>
      ))}
    </div>
  );
}

interface OutlineCardListProps {
  outlines: Outline[];
  filterLength?: StoryLengthKey | 'all';
  onUpdate: (id: string, data: Partial<Outline>) => void;
  onDelete: (id: string) => void;
}

export function OutlineCardList({ outlines, filterLength = 'all', onUpdate, onDelete }: OutlineCardListProps) {
  const filtered = filterLength === 'all' ? outlines : outlines.filter((o) => o.storyLength === filterLength);

  if (filtered.length === 0) {
    return (
      <div className="text-center py-12 text-stone-400">
        <div className="w-14 h-14 flex items-center justify-center mx-auto mb-3">
          <i className="ri-file-list-3-line text-4xl" />
        </div>
        <p className="font-medium">尚無大綱</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
      {filtered.map((outline) => {
        const lengthInfo = STORY_LENGTHS.find((s) => s.key === outline.storyLength);
        const chaptersText = outline.chapters.length > 0
          ? `${outline.chapters.length} 個章節`
          : '無分章節';

        const fullContent = [
          outline.content,
          outline.chapters.length > 0 ? '\n\n【章節大綱】\n' + outline.chapters.map(
            (ch) => `第 ${ch.index} 章：${ch.title}\n${ch.summary}`
          ).join('\n\n') : '',
        ].join('');

        return (
          <ContentCard
            key={outline.id}
            title={outline.title}
            content={outline.content}
            badges={[
              { label: lengthInfo?.label ?? '', color: 'bg-teal-600' },
              { label: outline.wordCount.toLocaleString() + ' 字', color: 'bg-stone-500' },
              { label: chaptersText, color: 'bg-stone-400' },
            ]}
            tags={outline.characterNames ?? []}
            onEdit={(content, title) => onUpdate(outline.id, { content, title: title ?? outline.title })}
            onArchive={() => onUpdate(outline.id, { archived: true })}
            onDelete={() => onDelete(outline.id)}
            onExportMd={() => exportAsMarkdown(outline.title, fullContent)}
            onExportPdf={() => exportAsPDF(outline.title, fullContent)}
          >
            {outline.chapters.length > 0 && (
              <div className="mt-3 space-y-2">
                <p className="text-xs font-semibold text-stone-500 uppercase tracking-wider">章節列表</p>
                <div className="space-y-2">
                  {outline.chapters.map((ch) => (
                    <div key={ch.index} className="flex gap-3 text-sm">
                      <span className="flex-shrink-0 w-10 h-6 flex items-center justify-center bg-teal-100 text-teal-700 rounded text-xs font-bold">
                        Ch.{ch.index}
                      </span>
                      <div>
                        <p className="font-medium text-stone-700">{ch.title}</p>
                        <p className="text-xs text-stone-500 line-clamp-2">{ch.summary}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </ContentCard>
        );
      })}
    </div>
  );
}
