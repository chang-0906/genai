import { useState, useEffect } from 'react';
import { worldviewsDB, charactersDB, outlinesDB, type WorldView, type Character, type Outline } from '../../utils/db';
import { generateOutline, loadApiSettings } from '../../utils/difyApi';
import { mockOutlines } from '../../mocks/outlines';
import {
  WorldviewSelectorOutline,
  CharacterSelector,
  StoryLengthSelector,
  OutlineCardList,
  STORY_LENGTHS,
  type StoryLengthKey,
} from './components/OutlineComponents';

type Step = 'select-world' | 'select-chars' | 'select-length' | 'review';

function parseChaptersFromText(text: string, chapterCount: number) {
  const results: { index: number; title: string; summary: string }[] = [];
  const regex = /第\s*(\d+)\s*章[：:\s]*([^\n]+)\n?([\s\S]*?)(?=第\s*\d+\s*章|$)/g;
  let match;
  while ((match = regex.exec(text)) !== null) {
    const idx = parseInt(match[1]);
    if (idx <= chapterCount) {
      results.push({ index: idx, title: match[2].trim(), summary: match[3].trim().slice(0, 300) });
    }
  }
  if (results.length === 0 && chapterCount > 0) {
    // Fallback: split by lines
    for (let i = 1; i <= chapterCount; i++) {
      results.push({ index: i, title: `第 ${i} 章`, summary: '' });
    }
  }
  return results;
}

export default function OutlinePage() {
  const [step, setStep] = useState<Step>('select-world');
  const [worldviews, setWorldviews] = useState<WorldView[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [selectedWorldviewId, setSelectedWorldviewId] = useState('');
  const [selectedCharIds, setSelectedCharIds] = useState<string[]>([]);
  const [selectedLength, setSelectedLength] = useState<StoryLengthKey | ''>('');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const [generatedContent, setGeneratedContent] = useState('');
  const [outlineTitle, setOutlineTitle] = useState('');
  const [outlines, setOutlines] = useState<Outline[]>([]);
  const [loadedOutlines, setLoadedOutlines] = useState(false);
  const [activeFilter, setActiveFilter] = useState<StoryLengthKey | 'all'>('all');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [wvAll, charAll, outAll] = await Promise.all([
        worldviewsDB.getAll(),
        charactersDB.getAll(),
        outlinesDB.getAll(),
      ]);
      setWorldviews(wvAll.filter((w) => !w.archived).sort((a, b) => b.createdAt - a.createdAt));
      setCharacters(charAll.filter((c) => !c.archived).sort((a, b) => b.createdAt - a.createdAt));
      const activeOutlines = outAll.filter((o) => !o.archived).sort((a, b) => b.createdAt - a.createdAt);
      if (activeOutlines.length === 0) {
        await Promise.all(mockOutlines.map((m) => outlinesDB.create(m)));
        const seeded = await outlinesDB.getAll();
        setOutlines(seeded.filter((o) => !o.archived).sort((a, b) => b.createdAt - a.createdAt));
      } else {
        setOutlines(activeOutlines);
      }
    } catch {
      setWorldviews([]);
      setCharacters([]);
      setOutlines([]);
    } finally {
      setLoadedOutlines(true);
    }
  };

  const selectedWorldview = worldviews.find((w) => w.id === selectedWorldviewId);
  const selectedLengthInfo = STORY_LENGTHS.find((s) => s.key === selectedLength);
  const selectedChars = characters.filter((c) => selectedCharIds.includes(c.id));

  const toggleChar = (id: string) => {
    setSelectedCharIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  };

  const handleGenerate = async () => {
    if (!selectedWorldview || !selectedLengthInfo) return;
    setGenerating(true);
    setError('');
    setGeneratedContent('');
    try {
      const settings = loadApiSettings();
      const charsContent = selectedChars.map((c) => `${c.name}（${c.age}歲）：${c.background}`).join('\n\n');
      const result = await generateOutline(
        settings.cLlm,
        selectedWorldview.content,
        charsContent,
        selectedLengthInfo.label,
        selectedLengthInfo.wordCount,
        selectedLengthInfo.chapters,
      );
      setGeneratedContent(result);
      setStep('review');
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : '生成失敗，請確認 API 設定');
    } finally {
      setGenerating(false);
    }
  };

  const handleSave = async () => {
    if (!selectedWorldview || !selectedLengthInfo || !outlineTitle.trim()) return;
    setSaving(true);
    try {
      const chapters = selectedLengthInfo.chapters
        ? parseChaptersFromText(generatedContent, selectedLengthInfo.chapters)
        : [];
      const outline = await outlinesDB.create({
        title: outlineTitle,
        worldviewId: selectedWorldview.id,
        worldviewTitle: selectedWorldview.title,
        characterIds: selectedCharIds,
        characterNames: selectedChars.map((c) => c.name),
        storyLength: selectedLengthInfo.key,
        wordCount: selectedLengthInfo.wordCount,
        chapters,
        content: generatedContent,
        archived: false,
      });
      setOutlines((prev) => [outline, ...prev]);
      setStep('select-world');
      setSelectedWorldviewId('');
      setSelectedCharIds([]);
      setSelectedLength('');
      setGeneratedContent('');
      setOutlineTitle('');
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateOutline = async (id: string, data: Partial<Outline>) => {
    await outlinesDB.update(id, data);
    if (data.archived) {
      setOutlines((prev) => prev.filter((o) => o.id !== id));
    } else {
      setOutlines((prev) => prev.map((o) => (o.id === id ? { ...o, ...data } : o)));
    }
  };

  const handleDeleteOutline = async (id: string) => {
    await outlinesDB.delete(id);
    setOutlines((prev) => prev.filter((o) => o.id !== id));
  };

  const steps = [
    { key: 'select-world', label: '選擇世界觀', icon: 'ri-earth-line' },
    { key: 'select-chars', label: '選擇角色', icon: 'ri-user-3-line' },
    { key: 'select-length', label: '選擇長度', icon: 'ri-ruler-line' },
    { key: 'review', label: '審閱大綱', icon: 'ri-eye-line' },
  ];

  const lengthCounts: Record<string, number> = {};
  outlines.forEach((o) => { lengthCounts[o.storyLength] = (lengthCounts[o.storyLength] || 0) + 1; });

  return (
    <div className="min-h-full bg-stone-50">
      {/* Header */}
      <div className="bg-white border-b border-stone-200 px-8 py-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 flex items-center justify-center bg-teal-100 rounded-xl">
            <i className="ri-file-list-3-line text-teal-600 text-xl" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-stone-800">大綱規劃</h1>
            <p className="text-stone-500 text-sm">規劃故事結構與章節大綱 · 由 C LLM 驅動</p>
          </div>
          <span className="ml-auto bg-teal-100 text-teal-700 text-xs font-bold px-3 py-1.5 rounded-full">
            {outlines.length} 份大綱
          </span>
        </div>
      </div>

      <div className="px-8 py-6 space-y-8 max-w-5xl">
        {/* Creation Panel */}
        <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
          {/* Step Indicator */}
          <div className="flex border-b border-stone-100">
            {steps.map((s, idx) => {
              const currentIdx = steps.findIndex((x) => x.key === step);
              const isPast = idx < currentIdx;
              const isActive = s.key === step;
              return (
                <div
                  key={s.key}
                  className={`flex-1 flex flex-col items-center gap-1 px-3 py-4 text-xs font-medium border-b-2 transition-all ${
                    isActive ? 'border-teal-500 text-teal-600 bg-teal-50'
                    : isPast ? 'border-teal-400 text-teal-600 bg-teal-50/50'
                    : 'border-transparent text-stone-400'
                  }`}
                >
                  <div className="w-7 h-7 flex items-center justify-center">
                    {isPast
                      ? <i className="ri-check-line text-teal-500 text-lg" />
                      : <i className={`${s.icon} text-base`} />
                    }
                  </div>
                  <span className="whitespace-nowrap">{s.label}</span>
                </div>
              );
            })}
          </div>

          <div className="p-6">
            {/* Step 1 */}
            {step === 'select-world' && (
              <div className="space-y-4">
                <h3 className="font-bold text-stone-800">選擇要使用的世界觀</h3>
                <WorldviewSelectorOutline
                  worldviews={worldviews}
                  selectedId={selectedWorldviewId}
                  onSelect={setSelectedWorldviewId}
                />
                <div className="flex justify-end">
                  <button
                    onClick={() => setStep('select-chars')}
                    disabled={!selectedWorldviewId}
                    className="flex items-center gap-2 px-6 py-3 bg-teal-500 hover:bg-teal-600 disabled:opacity-50 text-white rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
                  >
                    下一步 <i className="ri-arrow-right-line" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2 */}
            {step === 'select-chars' && (
              <div className="space-y-4">
                <h3 className="font-bold text-stone-800">選擇故事角色</h3>
                <CharacterSelector
                  characters={characters}
                  selectedIds={selectedCharIds}
                  onToggle={toggleChar}
                />
                <div className="flex justify-between">
                  <button
                    onClick={() => setStep('select-world')}
                    className="flex items-center gap-2 px-5 py-3 text-stone-600 hover:bg-stone-100 rounded-xl font-medium text-sm cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-arrow-left-line" /> 返回
                  </button>
                  <button
                    onClick={() => setStep('select-length')}
                    className="flex items-center gap-2 px-6 py-3 bg-teal-500 hover:bg-teal-600 text-white rounded-xl font-medium text-sm cursor-pointer whitespace-nowrap"
                  >
                    {selectedCharIds.length > 0 ? `已選 ${selectedCharIds.length} 個角色 · ` : ''}下一步 <i className="ri-arrow-right-line" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3 */}
            {step === 'select-length' && (
              <div className="space-y-5">
                <div>
                  <h3 className="font-bold text-stone-800 mb-1">選擇故事長度</h3>
                  <p className="text-sm text-stone-500">不同長度的大綱結構不同，請依創作計劃選擇</p>
                </div>
                <StoryLengthSelector selected={selectedLength} onSelect={setSelectedLength} />

                {error && (
                  <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-700 flex gap-2">
                    <i className="ri-error-warning-line flex-shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <button
                    onClick={() => { setStep('select-chars'); setError(''); }}
                    className="flex items-center gap-2 px-5 py-3 text-stone-600 hover:bg-stone-100 rounded-xl font-medium text-sm cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-arrow-left-line" /> 返回
                  </button>
                  <button
                    onClick={handleGenerate}
                    disabled={!selectedLength || generating}
                    className="flex items-center gap-2 px-6 py-3 bg-teal-500 hover:bg-teal-600 disabled:opacity-50 text-white rounded-xl font-medium text-sm cursor-pointer whitespace-nowrap"
                  >
                    {generating
                      ? <><i className="ri-loader-4-line animate-spin" /> AI 規劃大綱中...</>
                      : <><i className="ri-sparkling-line" /> 生成大綱</>
                    }
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Review */}
            {step === 'review' && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-stone-800">審閱生成的大綱</h3>
                    <p className="text-sm text-stone-500 mt-0.5">
                      {selectedLengthInfo?.label} · {selectedLengthInfo?.wordCount.toLocaleString()} 字
                      {selectedLengthInfo?.chapters ? ` · ${selectedLengthInfo.chapters} 章` : ''}
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {selectedChars.map((c) => (
                      <span key={c.id} className="text-xs bg-teal-100 text-teal-700 px-2 py-0.5 rounded-full">{c.name}</span>
                    ))}
                  </div>
                </div>

                <div className="bg-teal-50 border border-teal-200 rounded-xl p-4">
                  <p className="text-xs font-semibold text-teal-700 mb-2 flex items-center gap-1">
                    <i className="ri-sparkling-2-line" /> AI 生成結果（可直接編輯）
                  </p>
                  <textarea
                    value={generatedContent}
                    onChange={(e) => setGeneratedContent(e.target.value)}
                    className="w-full min-h-60 text-sm text-stone-700 bg-white border border-teal-200 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-teal-400 resize-y leading-relaxed"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-stone-700 mb-2">為此大綱命名 *</label>
                  <input
                    value={outlineTitle}
                    onChange={(e) => setOutlineTitle(e.target.value)}
                    placeholder="輸入這份大綱的標題..."
                    className="w-full px-4 py-3 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 bg-white"
                  />
                </div>

                <div className="flex justify-between">
                  <button
                    onClick={() => { setStep('select-length'); setGeneratedContent(''); }}
                    className="flex items-center gap-2 px-5 py-3 text-stone-600 hover:bg-stone-100 rounded-xl font-medium text-sm cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-arrow-left-line" /> 重新生成
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={!outlineTitle.trim() || !generatedContent.trim() || saving}
                    className="flex items-center gap-2 px-6 py-3 bg-stone-800 hover:bg-stone-900 disabled:opacity-50 text-white rounded-xl font-medium text-sm cursor-pointer whitespace-nowrap"
                  >
                    {saving ? <><i className="ri-loader-4-line animate-spin" /> 儲存中...</> : <><i className="ri-save-line" /> 儲存大綱</>}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Outline List with Length Filter Tabs */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-stone-800">已規劃的大綱</h2>
          </div>

          {/* Filter Tabs */}
          <div className="flex gap-2 mb-5 flex-wrap">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                activeFilter === 'all' ? 'bg-teal-500 text-white' : 'bg-white text-stone-600 border border-stone-200 hover:border-teal-300'
              }`}
            >
              全部 ({outlines.length})
            </button>
            {STORY_LENGTHS.map((s) => {
              const count = lengthCounts[s.key] || 0;
              if (count === 0) return null;
              return (
                <button
                  key={s.key}
                  onClick={() => setActiveFilter(s.key)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                    activeFilter === s.key ? 'bg-teal-500 text-white' : 'bg-white text-stone-600 border border-stone-200 hover:border-teal-300'
                  }`}
                >
                  {s.label} ({count})
                </button>
              );
            })}
          </div>

          {loadedOutlines ? (
            <OutlineCardList
              outlines={outlines}
              filterLength={activeFilter}
              onUpdate={handleUpdateOutline}
              onDelete={handleDeleteOutline}
            />
          ) : (
            <div className="flex items-center justify-center py-16 text-stone-400">
              <i className="ri-loader-4-line animate-spin text-2xl mr-3" />
              <span>載入中...</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
