import { useState, useEffect } from 'react';
import { worldviewsDB, charactersDB, type WorldView, type Character } from '../../utils/db';
import { generateCharacters, loadApiSettings } from '../../utils/difyApi';
import { mockCharacters } from '../../mocks/characters';
import { CharacterCard, CharacterList, WorldviewSelector, parseCharactersFromAI } from './components/CharacterComponents';

type Step = 'select-world' | 'set-count' | 'review';

interface PendingChar {
  name: string;
  age: string;
  background: string;
  kept: boolean | null; // null = unreviewed, true = keep, false = discard
}

export default function CharactersPage() {
  const [step, setStep] = useState<Step>('select-world');
  const [worldviews, setWorldviews] = useState<WorldView[]>([]);
  const [selectedWorldviewId, setSelectedWorldviewId] = useState('');
  const [charCount, setCharCount] = useState(3);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const [pendingChars, setPendingChars] = useState<PendingChar[]>([]);
  const [savedChars, setSavedChars] = useState<Character[]>([]);
  const [loadedSaved, setLoadedSaved] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [wvAll, charAll] = await Promise.all([worldviewsDB.getAll(), charactersDB.getAll()]);
      const activeWv = wvAll.filter((w) => !w.archived).sort((a, b) => b.createdAt - a.createdAt);
      const activeChars = charAll.filter((c) => !c.archived).sort((a, b) => b.createdAt - a.createdAt);

      setWorldviews(activeWv);

      // Seed mock characters if empty
      if (activeChars.length === 0) {
        await Promise.all(mockCharacters.map((c) => charactersDB.create(c)));
        const seeded = await charactersDB.getAll();
        setSavedChars(seeded.filter((c) => !c.archived).sort((a, b) => b.createdAt - a.createdAt));
      } else {
        setSavedChars(activeChars);
      }
    } catch {
      setWorldviews([]);
      setSavedChars([]);
    } finally {
      setLoadedSaved(true);
    }
  };

  const selectedWorldview = worldviews.find((w) => w.id === selectedWorldviewId);

  const handleGenerate = async () => {
    if (!selectedWorldview) return;
    setGenerating(true);
    setError('');
    try {
      const settings = loadApiSettings();
      const raw = await generateCharacters(settings.bLlm, selectedWorldview.content, charCount);
      const parsed = parseCharactersFromAI(raw);
      setPendingChars(parsed.map((c) => ({ ...c, kept: null })));
      setStep('review');
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : '生成失敗，請確認 API 設定');
    } finally {
      setGenerating(false);
    }
  };

  const updatePending = (idx: number, data: Partial<PendingChar>) => {
    setPendingChars((prev) => prev.map((c, i) => (i === idx ? { ...c, ...data } : c)));
  };

  const handleSaveAll = async () => {
    if (!selectedWorldview) return;
    const toSave = pendingChars.filter((c) => c.kept !== false);
    const created = await Promise.all(
      toSave.map((c) =>
        charactersDB.create({
          worldviewId: selectedWorldview.id,
          worldviewTitle: selectedWorldview.title,
          name: c.name,
          age: c.age,
          background: c.background,
          archived: false,
        })
      )
    );
    setSavedChars((prev) => [...created, ...prev]);
    setPendingChars([]);
    setStep('select-world');
    setSelectedWorldviewId('');
  };

  const handleUpdateSaved = async (id: string, data: Partial<Character>) => {
    await charactersDB.update(id, data);
    if (data.archived) {
      setSavedChars((prev) => prev.filter((c) => c.id !== id));
    } else {
      setSavedChars((prev) => prev.map((c) => (c.id === id ? { ...c, ...data } : c)));
    }
  };

  const handleDeleteSaved = async (id: string) => {
    await charactersDB.delete(id);
    setSavedChars((prev) => prev.filter((c) => c.id !== id));
  };

  const steps = [
    { key: 'select-world', label: '選擇世界觀', icon: 'ri-earth-line' },
    { key: 'set-count', label: '設定角色數量', icon: 'ri-user-add-line' },
    { key: 'review', label: '審閱角色', icon: 'ri-user-search-line' },
  ];

  return (
    <div className="min-h-full bg-stone-50">
      {/* Header */}
      <div className="bg-white border-b border-stone-200 px-8 py-6">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-10 h-10 flex items-center justify-center bg-rose-100 rounded-xl">
            <i className="ri-user-3-line text-rose-500 text-xl" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-stone-800">角色設定</h1>
            <p className="text-stone-500 text-sm">設計故事中的人物角色 · 由 B LLM 驅動</p>
          </div>
          <span className="ml-auto bg-rose-100 text-rose-700 text-xs font-bold px-3 py-1.5 rounded-full">
            {savedChars.length} 個角色
          </span>
        </div>
      </div>

      <div className="px-8 py-6 space-y-8 max-w-5xl">
        {/* Step Panel */}
        <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden">
          {/* Step Indicator */}
          <div className="flex border-b border-stone-100">
            {steps.map((s, idx) => {
              const currentIdx = steps.findIndex((x) => x.key === step);
              const isPast = idx < currentIdx;
              const isActive = s.key === step;
              return (
                <div
                  key={s.key}
                  className={`flex-1 flex flex-col items-center gap-1 px-4 py-4 text-xs font-medium border-b-2 transition-all ${
                    isActive
                      ? 'border-rose-500 text-rose-600 bg-rose-50'
                      : isPast
                      ? 'border-teal-400 text-teal-600 bg-teal-50'
                      : 'border-transparent text-stone-400'
                  }`}
                >
                  <div className="w-7 h-7 flex items-center justify-center">
                    {isPast ? (
                      <i className="ri-check-line text-teal-500 text-lg" />
                    ) : (
                      <i className={`${s.icon} text-base`} />
                    )}
                  </div>
                  <span>{s.label}</span>
                </div>
              );
            })}
          </div>

          <div className="p-6">
            {/* Step 1: Select Worldview */}
            {step === 'select-world' && (
              <div className="space-y-4">
                <h3 className="font-bold text-stone-800">選擇要使用的世界觀</h3>
                <WorldviewSelector
                  worldviews={worldviews}
                  selectedId={selectedWorldviewId}
                  onSelect={setSelectedWorldviewId}
                />
                <div className="flex justify-end pt-2">
                  <button
                    onClick={() => setStep('set-count')}
                    disabled={!selectedWorldviewId}
                    className="flex items-center gap-2 px-6 py-3 bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
                  >
                    下一步 <i className="ri-arrow-right-line" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Set Character Count */}
            {step === 'set-count' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-bold text-stone-800 mb-1">設定角色數量</h3>
                  <p className="text-sm text-stone-500">
                    基於世界觀「<strong>{selectedWorldview?.title}</strong>」，要生成幾個角色？
                  </p>
                </div>

                <div>
                  <div className="flex items-center gap-4 mb-3">
                    <span className="text-sm text-stone-600">角色數量：</span>
                    <div className="flex items-center gap-3 bg-stone-100 rounded-xl px-2 py-1">
                      <button
                        onClick={() => setCharCount((c) => Math.max(1, c - 1))}
                        className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white text-stone-600 transition-colors cursor-pointer"
                      >
                        <i className="ri-subtract-line" />
                      </button>
                      <span className="text-2xl font-bold text-stone-800 min-w-10 text-center">{charCount}</span>
                      <button
                        onClick={() => setCharCount((c) => Math.min(10, c + 1))}
                        className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white text-stone-600 transition-colors cursor-pointer"
                      >
                        <i className="ri-add-line" />
                      </button>
                    </div>
                    <span className="text-sm text-stone-400">（最多 10 個）</span>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {[1, 2, 3, 4, 5, 6, 8].map((n) => (
                      <button
                        key={n}
                        onClick={() => setCharCount(n)}
                        className={`px-4 py-2 rounded-xl text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                          charCount === n
                            ? 'bg-rose-500 text-white'
                            : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                        }`}
                      >
                        {n} 個
                      </button>
                    ))}
                  </div>
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-700 flex gap-2">
                    <i className="ri-error-warning-line flex-shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="flex justify-between pt-2">
                  <button
                    onClick={() => { setStep('select-world'); setError(''); }}
                    className="flex items-center gap-2 px-5 py-3 text-stone-600 hover:bg-stone-100 rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-arrow-left-line" /> 返回
                  </button>
                  <button
                    onClick={handleGenerate}
                    disabled={generating}
                    className="flex items-center gap-2 px-6 py-3 bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
                  >
                    {generating
                      ? <><i className="ri-loader-4-line animate-spin" /> AI 生成角色中...</>
                      : <><i className="ri-sparkling-line" /> 生成 {charCount} 個角色</>
                    }
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Review Characters */}
            {step === 'review' && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-stone-800">審閱生成的角色</h3>
                    <p className="text-sm text-stone-500 mt-0.5">選擇要保留或捨棄的角色，也可以修改後保留</p>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-stone-500">
                    <i className="ri-check-line text-teal-500" />
                    {pendingChars.filter((c) => c.kept !== false).length} / {pendingChars.length} 將保留
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {pendingChars.map((c, idx) => (
                    <CharacterCard
                      key={idx}
                      char={{
                        id: `pending-${idx}`,
                        worldviewId: selectedWorldviewId,
                        worldviewTitle: selectedWorldview?.title,
                        name: c.name,
                        age: c.age,
                        background: c.background,
                        archived: false,
                        createdAt: 0,
                        updatedAt: 0,
                      }}
                      isReviewing
                      onKeep={() => updatePending(idx, { kept: true })}
                      onDiscard={() => updatePending(idx, { kept: false })}
                      onEdit={(data) => updatePending(idx, {
                        name: data.name ?? c.name,
                        age: data.age ?? c.age,
                        background: data.background ?? c.background,
                        kept: true,
                      })}
                    />
                  ))}
                </div>

                <div className="flex justify-between pt-2">
                  <button
                    onClick={() => { setStep('set-count'); setPendingChars([]); }}
                    className="flex items-center gap-2 px-5 py-3 text-stone-600 hover:bg-stone-100 rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-arrow-left-line" /> 重新生成
                  </button>
                  <button
                    onClick={handleSaveAll}
                    disabled={pendingChars.filter((c) => c.kept !== false).length === 0}
                    className="flex items-center gap-2 px-6 py-3 bg-teal-500 hover:bg-teal-600 disabled:opacity-50 text-white rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-save-line" /> 儲存 {pendingChars.filter((c) => c.kept !== false).length} 個角色
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Saved Characters */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-stone-800">已設定的角色</h2>
            {savedChars.length > 0 && (
              <p className="text-sm text-stone-500">共 {savedChars.length} 個角色</p>
            )}
          </div>
          {loadedSaved ? (
            <CharacterList
              characters={savedChars}
              onUpdate={handleUpdateSaved}
              onDelete={handleDeleteSaved}
            />
          ) : (
            <div className="flex items-center justify-center py-16 text-stone-400">
              <i className="ri-loader-4-line animate-spin text-2xl mr-3" />
              <span>載入中...</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
