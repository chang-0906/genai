import { useState } from 'react';
import type { Character, WorldView } from '../../../utils/db';
import ContentCard from '../../../components/base/ContentCard';

interface ParsedCharacter {
  name: string;
  age: string;
  background: string;
}

export function parseCharactersFromAI(text: string): ParsedCharacter[] {
  const results: ParsedCharacter[] = [];
  // Try to split by numbered sections like "角色1" or "1." or "---"
  const sections = text.split(/(?:\n\s*(?:#{1,3}|\-{3,}|角色\s*\d+|第\s*\d+\s*個角色|\d+\s*[.、])\s*)/);
  
  for (const section of sections) {
    if (!section.trim()) continue;
    const nameMatch = section.match(/(?:姓名|名字|名稱)[：:]\s*(.+)/);
    const ageMatch = section.match(/(?:年齡|歲)[：:]\s*(.+)/);
    const bgMatch = section.match(/(?:身分|背景|描述|身份背景)[：:]\s*([\s\S]+?)(?=(?:姓名|名字|年齡|$))/);

    if (nameMatch) {
      results.push({
        name: nameMatch[1].trim(),
        age: ageMatch ? ageMatch[1].trim() : '不明',
        background: bgMatch ? bgMatch[1].trim() : section.trim(),
      });
    }
  }

  // Fallback: if parsing failed, return one block
  if (results.length === 0 && text.trim()) {
    results.push({ name: '未命名角色', age: '不明', background: text.trim() });
  }

  return results;
}

interface CharacterCardProps {
  char: Character;
  onKeep?: () => void;
  onDiscard?: () => void;
  onEdit?: (data: Partial<Character>) => void;
  onArchive?: () => void;
  onDelete?: () => void;
  isReviewing?: boolean;
}

export function CharacterCard({ char, onKeep, onDiscard, onEdit, onArchive, onDelete, isReviewing }: CharacterCardProps) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(char.name);
  const [age, setAge] = useState(char.age);
  const [background, setBackground] = useState(char.background);

  const handleSave = () => {
    onEdit?.({ name, age, background });
    setEditing(false);
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden hover:border-stone-300 transition-all">
      {/* Header */}
      <div className="flex items-start justify-between px-5 py-4 border-b border-stone-100 bg-gradient-to-r from-stone-50 to-white">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center flex-shrink-0">
            <i className="ri-user-3-line text-rose-500 text-lg" />
          </div>
          <div>
            {editing ? (
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="text-sm font-bold border border-amber-300 rounded-lg px-2 py-1 bg-amber-50 focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
            ) : (
              <h3 className="font-bold text-stone-800 text-base">{char.name}</h3>
            )}
            <div className="flex items-center gap-2 mt-0.5">
              {editing ? (
                <input
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="text-xs border border-amber-300 rounded px-2 py-0.5 bg-amber-50 focus:outline-none w-20"
                  placeholder="年齡"
                />
              ) : (
                <span className="text-xs text-stone-500 bg-stone-100 px-2 py-0.5 rounded-full">{char.age} 歲</span>
              )}
              {char.worldviewTitle && (
                <span className="text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">{char.worldviewTitle}</span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {!isReviewing && (
            <>
              <button
                onClick={() => setEditing(!editing)}
                className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-stone-100 text-stone-500 hover:text-stone-700 transition-colors cursor-pointer"
              >
                <i className="ri-pencil-line text-sm" />
              </button>
              {onArchive && (
                <button
                  onClick={onArchive}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-stone-100 text-stone-500 hover:text-stone-700 transition-colors cursor-pointer"
                  title="封存"
                >
                  <i className="ri-archive-line text-sm" />
                </button>
              )}
              {onDelete && (
                <button
                  onClick={onDelete}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-red-50 text-stone-500 hover:text-red-600 transition-colors cursor-pointer"
                  title="刪除"
                >
                  <i className="ri-delete-bin-line text-sm" />
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Background */}
      <div className="px-5 py-4">
        <p className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2">身分背景</p>
        {editing ? (
          <textarea
            value={background}
            onChange={(e) => setBackground(e.target.value)}
            rows={4}
            className="w-full text-sm text-stone-700 border border-amber-300 rounded-xl p-3 bg-amber-50 focus:outline-none focus:ring-2 focus:ring-amber-400 resize-none leading-relaxed"
          />
        ) : (
          <p className="text-sm text-stone-600 leading-relaxed">{char.background}</p>
        )}

        {editing && (
          <div className="flex justify-end gap-2 mt-3">
            <button
              onClick={() => { setEditing(false); setName(char.name); setAge(char.age); setBackground(char.background); }}
              className="px-4 py-2 text-sm text-stone-600 hover:bg-stone-100 rounded-lg cursor-pointer whitespace-nowrap"
            >取消</button>
            <button
              onClick={handleSave}
              className="px-4 py-2 text-sm bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-medium cursor-pointer whitespace-nowrap"
            >儲存</button>
          </div>
        )}
      </div>

      {/* Review Actions */}
      {isReviewing && (
        <div className="flex border-t border-stone-100">
          <button
            onClick={onDiscard}
            className="flex-1 flex items-center justify-center gap-2 py-3 text-sm text-stone-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-close-circle-line" /> 捨棄
          </button>
          <div className="w-px bg-stone-100" />
          <button
            onClick={() => setEditing(!editing)}
            className="flex-1 flex items-center justify-center gap-2 py-3 text-sm text-stone-500 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-edit-line" /> 修改
          </button>
          <div className="w-px bg-stone-100" />
          <button
            onClick={onKeep}
            className="flex-1 flex items-center justify-center gap-2 py-3 text-sm text-stone-500 hover:text-teal-600 hover:bg-teal-50 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-check-line" /> 保留
          </button>
        </div>
      )}
    </div>
  );
}

interface CharacterListProps {
  characters: Character[];
  onUpdate: (id: string, data: Partial<Character>) => void;
  onDelete: (id: string) => void;
}

export function CharacterList({ characters, onUpdate, onDelete }: CharacterListProps) {
  if (characters.length === 0) {
    return (
      <div className="text-center py-16 text-stone-400">
        <div className="w-16 h-16 flex items-center justify-center mx-auto mb-3">
          <i className="ri-group-line text-4xl" />
        </div>
        <p className="font-medium">尚無角色</p>
        <p className="text-sm mt-1">在上方選擇世界觀並生成角色吧！</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
      {characters.map((char) => (
        <CharacterCard
          key={char.id}
          char={char}
          onEdit={(data) => onUpdate(char.id, data)}
          onArchive={() => onUpdate(char.id, { archived: true })}
          onDelete={() => onDelete(char.id)}
        />
      ))}
    </div>
  );
}

interface WorldviewSelectorProps {
  worldviews: WorldView[];
  selectedId: string;
  onSelect: (id: string) => void;
}

export function WorldviewSelector({ worldviews, selectedId, onSelect }: WorldviewSelectorProps) {
  if (worldviews.length === 0) {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-800 flex gap-2">
        <i className="ri-information-line flex-shrink-0 mt-0.5" />
        <span>尚無世界觀，請先前往「世界觀創造」建立世界觀。</span>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {worldviews.map((wv) => (
        <button
          key={wv.id}
          onClick={() => onSelect(wv.id)}
          className={`text-left px-4 py-3 rounded-xl border-2 transition-all cursor-pointer ${
            selectedId === wv.id
              ? 'border-amber-500 bg-amber-50'
              : 'border-stone-200 bg-white hover:border-amber-300'
          }`}
        >
          <p className="font-semibold text-sm text-stone-800 truncate">{wv.title}</p>
          <p className="text-xs text-stone-500 mt-1 line-clamp-2">{wv.content.slice(0, 80)}...</p>
        </button>
      ))}
    </div>
  );
}
