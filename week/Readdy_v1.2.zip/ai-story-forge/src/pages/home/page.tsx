import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { worldviewsDB, charactersDB, outlinesDB } from '../../utils/db';
import { loadApiSettings, isApiConfigured } from '../../utils/difyApi';

interface StatCard {
  label: string;
  count: number;
  icon: string;
  color: string;
  bgColor: string;
  to: string;
}

export default function HomePage() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({ worldviews: 0, characters: 0, outlines: 0 });
  const [apiStatus, setApiStatus] = useState({ a: false, b: false, c: false, d: false });

  useEffect(() => {
    loadStats();
    checkApi();
  }, []);

  const loadStats = async () => {
    try {
      const [wv, ch, out] = await Promise.all([
        worldviewsDB.getAll(),
        charactersDB.getAll(),
        outlinesDB.getAll(),
      ]);
      setStats({
        worldviews: wv.filter((w) => !w.archived).length,
        characters: ch.filter((c) => !c.archived).length,
        outlines: out.filter((o) => !o.archived).length,
      });
    } catch {
      setStats({ worldviews: 0, characters: 0, outlines: 0 });
    }
  };

  const checkApi = () => {
    const s = loadApiSettings();
    setApiStatus({
      a: isApiConfigured(s.aLlm),
      b: isApiConfigured(s.bLlm),
      c: isApiConfigured(s.cLlm),
      d: isApiConfigured(s.dLlm),
    });
  };

  const statCards: StatCard[] = [
    { label: '世界觀', count: stats.worldviews, icon: 'ri-earth-line', color: 'text-amber-600', bgColor: 'bg-amber-100', to: '/worldview' },
    { label: '角色', count: stats.characters, icon: 'ri-user-3-line', color: 'text-rose-600', bgColor: 'bg-rose-100', to: '/characters' },
    { label: '大綱', count: stats.outlines, icon: 'ri-file-list-3-line', color: 'text-teal-600', bgColor: 'bg-teal-100', to: '/outline' },
  ];

  const flowSteps = [
    { num: '01', label: '世界觀創造', desc: '設定故事世界的背景基礎', icon: 'ri-earth-line', color: 'text-amber-500', to: '/worldview', llm: 'A LLM', ready: apiStatus.a },
    { num: '02', label: '角色設定', desc: '設計故事中的人物角色', icon: 'ri-user-3-line', color: 'text-rose-500', to: '/characters', llm: 'B LLM', ready: apiStatus.b },
    { num: '03', label: '大綱規劃', desc: '規劃故事結構與章節', icon: 'ri-file-list-3-line', color: 'text-teal-500', to: '/outline', llm: 'C LLM', ready: apiStatus.c },
    { num: '04', label: '故事生成', desc: '由 AI 生成完整故事文本', icon: 'ri-quill-pen-line', color: 'text-violet-500', to: '/story', llm: 'D LLM', ready: apiStatus.d },
  ];

  const apiReady = Object.values(apiStatus).filter(Boolean).length;

  return (
    <div className="min-h-full bg-stone-50">
      {/* Hero */}
      <div className="bg-white border-b border-stone-200 px-8 py-10">
        <div className="max-w-3xl">
          <div className="flex items-center gap-4 mb-4">
            <img
              src="https://public.readdy.ai/ai/img_res/33134f09-22a1-4f62-b068-2a1e1b0eb504.png"
              alt="AI Story Forge"
              className="w-14 h-14 object-contain rounded-2xl"
            />
            <div>
              <h1 className="text-3xl font-bold text-stone-800">AI Story Forge</h1>
              <p className="text-stone-500 mt-1">人類與 AI 協同創作故事的工作坊</p>
            </div>
          </div>
          <p className="text-stone-600 leading-relaxed">
            從世界觀到故事，一步一步完成你的創作。連結你的 dify.ai 模型，讓 AI 成為你的故事夥伴。
          </p>
        </div>
      </div>

      <div className="px-8 py-6 space-y-8 max-w-5xl">
        {/* API Status Banner */}
        {apiReady < 4 && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 flex items-start gap-4">
            <div className="w-10 h-10 flex items-center justify-center bg-amber-100 rounded-xl flex-shrink-0">
              <i className="ri-key-line text-amber-600 text-xl" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-amber-800">尚未完整設定 API</p>
              <p className="text-sm text-amber-700 mt-1">
                目前已設定 {apiReady}/4 個 LLM，部分 AI 功能將無法使用。請前往側邊欄底部的「API 設定」完成設定。
              </p>
              <div className="flex gap-3 mt-3 flex-wrap">
                {(['A', 'B', 'C', 'D'] as const).map((key, i) => {
                  const ready = [apiStatus.a, apiStatus.b, apiStatus.c, apiStatus.d][i];
                  return (
                    <span key={key} className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1 rounded-full ${ready ? 'bg-teal-100 text-teal-700' : 'bg-stone-200 text-stone-500'}`}>
                      {ready ? <i className="ri-check-line" /> : <i className="ri-close-line" />}
                      {key} LLM
                    </span>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          {statCards.map((s) => (
            <button
              key={s.label}
              onClick={() => navigate(s.to)}
              className="bg-white rounded-2xl border border-stone-200 p-6 hover:border-stone-300 transition-all cursor-pointer text-left group"
            >
              <div className={`w-12 h-12 flex items-center justify-center ${s.bgColor} rounded-xl mb-4`}>
                <i className={`${s.icon} ${s.color} text-2xl`} />
              </div>
              <p className="text-3xl font-bold text-stone-800">{s.count}</p>
              <p className="text-stone-500 text-sm mt-1">{s.label}</p>
            </button>
          ))}
        </div>

        {/* Creation Flow */}
        <div>
          <h2 className="text-lg font-bold text-stone-800 mb-4">創作流程</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {flowSteps.map((s, idx) => (
              <button
                key={s.num}
                onClick={() => navigate(s.to)}
                className="bg-white rounded-2xl border border-stone-200 p-5 hover:border-stone-300 transition-all cursor-pointer text-left group"
              >
                <div className="flex items-start justify-between mb-4">
                  <span className="text-3xl font-black text-stone-200 group-hover:text-stone-300 transition-colors">{s.num}</span>
                  <span className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${s.ready ? 'bg-teal-100 text-teal-700' : 'bg-stone-100 text-stone-500'}`}>
                    {s.ready ? <i className="ri-check-line" /> : <i className="ri-link-unlink-line" />}
                    {s.llm}
                  </span>
                </div>
                <div className="w-9 h-9 flex items-center justify-center mb-3">
                  <i className={`${s.icon} ${s.color} text-2xl`} />
                </div>
                <p className="font-bold text-stone-800 text-sm">{s.label}</p>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">{s.desc}</p>
                {idx < flowSteps.length - 1 && (
                  <div className="mt-4 flex items-center gap-1 text-xs text-stone-400">
                    <i className="ri-arrow-right-line" /> 下一步
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Tips */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6">
          <h3 className="font-bold text-stone-800 mb-4 flex items-center gap-2">
            <i className="ri-lightbulb-line text-amber-500" /> 快速開始
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-stone-600">
            <div className="flex gap-3">
              <div className="w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                <i className="ri-number-1 text-amber-500" />
              </div>
              <p>前往側邊欄底部的「API 設定」，為每個創作階段設定對應的 dify.ai API Key</p>
            </div>
            <div className="flex gap-3">
              <div className="w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                <i className="ri-number-2 text-amber-500" />
              </div>
              <p>先在「世界觀創造」頁面建立故事世界的背景設定</p>
            </div>
            <div className="flex gap-3">
              <div className="w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                <i className="ri-number-3 text-amber-500" />
              </div>
              <p>接著在「角色設定」頁面基於世界觀生成故事角色</p>
            </div>
            <div className="flex gap-3">
              <div className="w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                <i className="ri-number-4 text-amber-500" />
              </div>
              <p>最後在「大綱規劃」頁面規劃故事結構，為故事生成做好準備</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
