export interface ApiConfig {
  baseUrl: string;
  apiKey: string;
}

export interface ApiSettings {
  aLlm: ApiConfig; // 世界觀設定模型
  bLlm: ApiConfig; // 角色設定模型
  cLlm: ApiConfig; // 大綱設定模型
  dLlm: ApiConfig; // 故事生成模型
}

const API_SETTINGS_KEY = 'ai-story-forge-api-settings';

export const defaultApiSettings: ApiSettings = {
  aLlm: { baseUrl: '', apiKey: '' },
  bLlm: { baseUrl: '', apiKey: '' },
  cLlm: { baseUrl: '', apiKey: '' },
  dLlm: { baseUrl: '', apiKey: '' },
};

export function loadApiSettings(): ApiSettings {
  try {
    const raw = localStorage.getItem(API_SETTINGS_KEY);
    if (!raw) return { ...defaultApiSettings };
    return JSON.parse(raw) as ApiSettings;
  } catch {
    return { ...defaultApiSettings };
  }
}

export function saveApiSettings(settings: ApiSettings): void {
  localStorage.setItem(API_SETTINGS_KEY, JSON.stringify(settings));
}

export function isApiConfigured(config: ApiConfig): boolean {
  return Boolean(config.baseUrl.trim() && config.apiKey.trim());
}

interface DifyResponse {
  answer: string;
  conversation_id: string;
  message_id: string;
}

async function callDifyApi(config: ApiConfig, query: string): Promise<string> {
  if (!isApiConfigured(config)) {
    throw new Error('API 尚未設定，請先在設定中填入 Base URL 與 API Key');
  }

  const baseUrl = config.baseUrl.endsWith('/') ? config.baseUrl.slice(0, -1) : config.baseUrl;

  const response = await fetch(`${baseUrl}/chat-messages`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${config.apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      inputs: {},
      query,
      response_mode: 'blocking',
      conversation_id: '',
      user: 'ai-story-forge-user',
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`API 錯誤 (${response.status}): ${errText}`);
  }

  const data = await response.json() as DifyResponse;
  return data.answer || '';
}

// ─── A LLM: 世界觀設定 ────────────────────────────────────────────────────────
export async function expandWorldviewIdea(config: ApiConfig, idea: string): Promise<string> {
  const query = `這是對於故事世界觀設定的想法：
{
${idea}
}
請依據上述的設定，設計出完整且豐富的世界觀，包括：地理環境、歷史背景、社會結構、獨特規則或法則、文化特色，以及影響故事走向的重要設定。請以條理清晰的方式呈現。`;
  return callDifyApi(config, query);
}

export async function extractWorldviewFromNovel(config: ApiConfig, novel: string): Promise<string> {
  const query = `這是一篇用於故事世界觀設定的現有故事或小說：
{
${novel}
}
請依據上述內容，統整歸納出小說中世界的世界觀，包括：地理環境、歷史背景、社會結構、獨特規則或法則、文化特色，以及所有影響故事走向的重要設定。請以條理清晰的方式整理呈現。`;
  return callDifyApi(config, query);
}

// ─── B LLM: 角色設定 ──────────────────────────────────────────────────────────
export async function generateCharacters(
  config: ApiConfig,
  worldviewContent: string,
  count: number
): Promise<string> {
  const query = `這是故事的世界觀設定：
{
${worldviewContent}
}
請依據上述的世界觀設定，設計 ${count} 個具有深度的角色，每個角色需包含：
1. 姓名（符合世界觀風格）
2. 年齡
3. 身分背景描述（包含職業、出身、個性特質、與世界觀的關聯，以及可能在故事中扮演的角色）

請以清楚的格式分隔每個角色，讓每個角色的三項資訊一目了然。`;
  return callDifyApi(config, query);
}

// ─── C LLM: 大綱設定 ──────────────────────────────────────────────────────────
export async function generateOutline(
  config: ApiConfig,
  worldviewContent: string,
  charactersContent: string,
  storyLengthLabel: string,
  wordCount: number,
  chapterCount: number | null
): Promise<string> {
  const lengthInstruction = chapterCount
    ? `分 ${chapterCount} 個章節，設計每章的標題與情節大綱，故事總長約 ${wordCount.toLocaleString()} 字`
    : `設計完整的故事大綱，故事總長約 ${wordCount.toLocaleString()} 字`;

  const query = `這是故事的世界觀設定：
{
${worldviewContent}
}
這是故事的人物設定：
{
${charactersContent}
}
請依據上述的世界觀與人物設定，進行故事設計，請設計「${storyLengthLabel}」的故事內容。
要求：${lengthInstruction}

請包含：
- 故事主題與核心衝突
- 開場、發展、高潮、結局的整體架構
${chapterCount ? `- 每個章節的標題、字數目標、與情節重點摘要` : `- 完整的情節大綱`}
- 主配角在故事中的角色轉變`;
  return callDifyApi(config, query);
}

// ─── D LLM: 故事生成 ──────────────────────────────────────────────────────────
export async function generateStory(
  config: ApiConfig,
  worldviewContent: string,
  charactersContent: string,
  outlineContent: string,
  wordCount: number
): Promise<string> {
  const query = `這是故事的世界觀設定：
{
${worldviewContent}
}
這是故事的人物設定：
{
${charactersContent}
}
這是故事的情節與大綱設定：
{
${outlineContent}
}
請依據上述的世界觀與人物設定，以及故事情節，進行故事創作，請設計約 ${wordCount.toLocaleString()} 字的故事內容。
要求：文字流暢優美，人物對話自然生動，場景描寫具有臨場感，情節發展符合大綱設定。`;
  return callDifyApi(config, query);
}

export async function generateStoryChapter(
  config: ApiConfig,
  worldviewContent: string,
  charactersContent: string,
  outlineContent: string,
  chapterTitle: string,
  chapterSummary: string,
  chapterWordCount: number,
  chapterIndex: number,
  totalChapters: number
): Promise<string> {
  const query = `這是故事的世界觀設定：
{
${worldviewContent}
}
這是故事的人物設定：
{
${charactersContent}
}
這是故事的整體情節與大綱設定：
{
${outlineContent}
}
請依據上述的世界觀與人物設定，以及故事情節，進行故事創作。
現在請創作第 ${chapterIndex}/${totalChapters} 章：「${chapterTitle}」
本章大綱：${chapterSummary}
本章目標字數：約 ${chapterWordCount.toLocaleString()} 字

要求：文字流暢優美，人物對話自然生動，場景描寫具有臨場感，情節發展符合本章大綱設定，同時與整體故事架構保持一致。`;
  return callDifyApi(config, query);
}
