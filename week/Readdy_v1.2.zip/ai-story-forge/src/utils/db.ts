export interface WorldView {
  id: string;
  title: string;
  content: string;
  method: 'manual' | 'ai' | 'extract';
  archived: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface Character {
  id: string;
  worldviewId: string;
  worldviewTitle?: string;
  name: string;
  age: string;
  background: string;
  archived: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface OutlineChapter {
  index: number;
  title: string;
  summary: string;
}

export interface Outline {
  id: string;
  title: string;
  worldviewId: string;
  worldviewTitle?: string;
  characterIds: string[];
  characterNames?: string[];
  storyLength: 'ultrashort' | 'short' | 'medium' | 'long' | 'ultralong';
  wordCount: number;
  chapters: OutlineChapter[];
  content: string;
  archived: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface StoryChapter {
  index: number;
  title: string;
  content: string;
}

export interface Story {
  id: string;
  outlineId: string;
  title: string;
  chapters: StoryChapter[];
  createdAt: number;
}

const DB_NAME = 'ai-story-forge';
const DB_VERSION = 1;

let dbInstance: IDBDatabase | null = null;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('worldviews')) {
        const ws = db.createObjectStore('worldviews', { keyPath: 'id' });
        ws.createIndex('archived', 'archived');
        ws.createIndex('createdAt', 'createdAt');
      }
      if (!db.objectStoreNames.contains('characters')) {
        const cs = db.createObjectStore('characters', { keyPath: 'id' });
        cs.createIndex('worldviewId', 'worldviewId');
        cs.createIndex('archived', 'archived');
      }
      if (!db.objectStoreNames.contains('outlines')) {
        const os = db.createObjectStore('outlines', { keyPath: 'id' });
        os.createIndex('worldviewId', 'worldviewId');
        os.createIndex('storyLength', 'storyLength');
        os.createIndex('archived', 'archived');
      }
      if (!db.objectStoreNames.contains('stories')) {
        const ss = db.createObjectStore('stories', { keyPath: 'id' });
        ss.createIndex('outlineId', 'outlineId');
      }
    };
    request.onsuccess = (e) => {
      dbInstance = (e.target as IDBOpenDBRequest).result;
      resolve(dbInstance);
    };
    request.onerror = () => reject(request.error);
  });
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

async function getAll<T>(storeName: string): Promise<T[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = () => reject(req.error);
  });
}

async function getById<T>(storeName: string, id: string): Promise<T | undefined> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.get(id);
    req.onsuccess = () => resolve(req.result as T | undefined);
    req.onerror = () => reject(req.error);
  });
}

async function put<T>(storeName: string, item: T): Promise<T> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.put(item);
    req.onsuccess = () => resolve(item);
    req.onerror = () => reject(req.error);
  });
}

async function remove(storeName: string, id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// ─── WorldViews ───────────────────────────────────────────────────────────────
export const worldviewsDB = {
  getAll: () => getAll<WorldView>('worldviews'),
  getById: (id: string) => getById<WorldView>('worldviews', id),
  create: (data: Omit<WorldView, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = Date.now();
    const item: WorldView = { ...data, id: generateId(), createdAt: now, updatedAt: now };
    return put<WorldView>('worldviews', item);
  },
  update: async (id: string, data: Partial<WorldView>) => {
    const existing = await getById<WorldView>('worldviews', id);
    if (!existing) throw new Error('WorldView not found');
    const updated = { ...existing, ...data, updatedAt: Date.now() };
    return put<WorldView>('worldviews', updated);
  },
  delete: (id: string) => remove('worldviews', id),
};

// ─── Characters ───────────────────────────────────────────────────────────────
export const charactersDB = {
  getAll: () => getAll<Character>('characters'),
  getById: (id: string) => getById<Character>('characters', id),
  create: (data: Omit<Character, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = Date.now();
    const item: Character = { ...data, id: generateId(), createdAt: now, updatedAt: now };
    return put<Character>('characters', item);
  },
  update: async (id: string, data: Partial<Character>) => {
    const existing = await getById<Character>('characters', id);
    if (!existing) throw new Error('Character not found');
    const updated = { ...existing, ...data, updatedAt: Date.now() };
    return put<Character>('characters', updated);
  },
  delete: (id: string) => remove('characters', id),
};

// ─── Outlines ─────────────────────────────────────────────────────────────────
export const outlinesDB = {
  getAll: () => getAll<Outline>('outlines'),
  getById: (id: string) => getById<Outline>('outlines', id),
  create: (data: Omit<Outline, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = Date.now();
    const item: Outline = { ...data, id: generateId(), createdAt: now, updatedAt: now };
    return put<Outline>('outlines', item);
  },
  update: async (id: string, data: Partial<Outline>) => {
    const existing = await getById<Outline>('outlines', id);
    if (!existing) throw new Error('Outline not found');
    const updated = { ...existing, ...data, updatedAt: Date.now() };
    return put<Outline>('outlines', updated);
  },
  delete: (id: string) => remove('outlines', id),
};

// ─── Stories ──────────────────────────────────────────────────────────────────
export const storiesDB = {
  getAll: () => getAll<Story>('stories'),
  getById: (id: string) => getById<Story>('stories', id),
  create: (data: Omit<Story, 'id' | 'createdAt'>) => {
    const item: Story = { ...data, id: generateId(), createdAt: Date.now() };
    return put<Story>('stories', item);
  },
  update: async (id: string, data: Partial<Story>) => {
    const existing = await getById<Story>('stories', id);
    if (!existing) throw new Error('Story not found');
    return put<Story>('stories', { ...existing, ...data });
  },
  delete: (id: string) => remove('stories', id),
};

// ─── Export All ───────────────────────────────────────────────────────────────
export async function exportAllData() {
  const [worldviews, characters, outlines, stories] = await Promise.all([
    worldviewsDB.getAll(),
    charactersDB.getAll(),
    outlinesDB.getAll(),
    storiesDB.getAll(),
  ]);
  return { worldviews, characters, outlines, stories, exportedAt: new Date().toISOString() };
}
