import { exportAllData } from './db';

// ─── Project ZIP Download ──────────────────────────────────────────────────────
const README_MD = `# AI Story Forge

**AI Story Forge** 是一款 AI 輔助互動創作故事應用，整合 dify.ai 的 LLM API，讓使用者可以串接自己的 AI 模型，協助構建世界觀、角色、大綱，並生成完整故事。

## 核心功能

| 功能模組 | 說明 |
|----------|------|
| 🌍 世界觀創造 | 手動建立 / AI 擴展 / AI 從小說提取 三種模式 |
| 👤 角色設定  | 選擇世界觀 → AI 批量生成角色 → 留/棄/修改審閱流程 |
| 📋 大綱規劃  | 選世界觀與角色 → 選篇幅 → AI 生成章節大綱 |
| ✍️ 故事生成  | 根據大綱分章節讓 D LLM 生成完整故事文本 |
| 🗃️ 封存箱   | 暫存不使用的世界觀、角色、大綱卡片 |

## 技術棧

- **前端框架**：React 19 + TypeScript
- **樣式**：Tailwind CSS v3
- **路由**：React Router v7
- **資料儲存**：IndexedDB（本地持久化，無需後端）
- **AI 串接**：dify.ai Chatbot / Completion API
- **PDF 匯出**：jsPDF
- **構建工具**：Vite

## 快速開始

詳細部署步驟請參閱 [DEPLOYMENT.md](./DEPLOYMENT.md)。

## Dify.ai 設定指引

請參閱 [DIFY_SETUP.md](./DIFY_SETUP.md) 了解如何設定四個 LLM 模型。

---

_此文件由 AI Story Forge 專案下載包自動生成_
`;

const DEPLOYMENT_MD = `# AI Story Forge — 部署指南

本指南將一步步帶你完成 AI Story Forge 的本地開發與生產環境部署。

---

## 目錄

1. [系統需求](#1-系統需求)
2. [取得原始碼](#2-取得原始碼)
3. [安裝依賴](#3-安裝依賴)
4. [本地開發](#4-本地開發)
5. [生產構建](#5-生產構建)
6. [部署選項](#6-部署選項)
   - [Vercel（推薦）](#vercel-推薦)
   - [Netlify](#netlify)
   - [GitHub Pages](#github-pages)
   - [自架伺服器（Nginx）](#自架伺服器-nginx)
7. [常見問題](#7-常見問題)

---

## 1. 系統需求

在開始之前，請確認你的電腦已安裝以下軟體：

| 軟體 | 最低版本 | 下載連結 |
|------|---------|---------|
| Node.js | 18.x 以上 | https://nodejs.org |
| npm | 9.x 以上（隨 Node.js 一起安裝）| — |
| Git | 任意版本 | https://git-scm.com |

驗證版本：
\`\`\`bash
node -v    # 應顯示 v18.x.x 或更高
npm -v     # 應顯示 9.x.x 或更高
\`\`\`

---

## 2. 取得原始碼

### 方式 A：從 Readdy.ai 匯出（推薦）

1. 前往 [readdy.ai](https://readdy.ai)，開啟此 AI Story Forge 專案
2. 點擊右上角「匯出專案」或「Export」按鈕
3. 下載 .zip 原始碼包後，解壓縮到你想要的目錄

### 方式 B：從 GitHub Clone

如果此專案已托管於 GitHub：
\`\`\`bash
git clone https://github.com/your-username/ai-story-forge.git
cd ai-story-forge
\`\`\`

---

## 3. 安裝依賴

進入專案目錄後，執行：

\`\`\`bash
npm install
\`\`\`

這會自動安裝所有必要的套件（約需 1-3 分鐘，取決於網路速度）。

---

## 4. 本地開發

啟動本地開發伺服器：

\`\`\`bash
npm run dev
\`\`\`

成功後，終端機會顯示：
\`\`\`
  VITE v8.x.x  ready in xxx ms
  ➜  Local:   http://localhost:5173/
  ➜  Network: http://192.168.x.x:5173/
\`\`\`

打開瀏覽器前往 http://localhost:5173 即可看到應用。

> **⚠️ 注意**：應用資料儲存在 IndexedDB（瀏覽器本地），每個瀏覽器的資料是獨立的。

---

## 5. 生產構建

構建優化後的靜態文件：

\`\`\`bash
npm run build
\`\`\`

構建完成後，靜態文件會輸出到 \`dist/\` 目錄。你可以本地預覽：

\`\`\`bash
npm run preview
\`\`\`

---

## 6. 部署選項

### Vercel（推薦）

Vercel 是最簡單的部署方式，完全免費（個人使用）：

**方式一：連接 GitHub 自動部署**
1. 將專案推送到 GitHub 倉庫
2. 前往 [vercel.com](https://vercel.com)，使用 GitHub 帳號登入
3. 點擊「New Project」，選擇你的 GitHub 倉庫
4. 保持預設設定，點擊「Deploy」
5. 幾分鐘後，你會得到一個 \`xxx.vercel.app\` 的網址

**方式二：使用 Vercel CLI**
\`\`\`bash
npm install -g vercel
vercel login
vercel
\`\`\`

**Vercel 設定（vercel.json）**—— 若遇到刷新頁面 404，請在專案根目錄建立此文件：
\`\`\`json
{
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
\`\`\`

---

### Netlify

1. 前往 [netlify.com](https://netlify.com)，登入後點擊「New site from Git」
2. 連接你的 GitHub/GitLab/Bitbucket 倉庫
3. 構建設定填入：
   - **Build command**：\`npm run build\`
   - **Publish directory**：\`dist\`
4. 點擊「Deploy site」

**解決刷新 404 問題**——在 \`public/\` 目錄建立 \`_redirects\` 文件：
\`\`\`
/*    /index.html   200
\`\`\`

---

### GitHub Pages

1. 在 \`vite.config.ts\` 中設定 base（替換為你的倉庫名稱）：
\`\`\`ts
export default defineConfig({
  base: '/ai-story-forge/',
  // ...
})
\`\`\`

2. 安裝部署套件：
\`\`\`bash
npm install --save-dev gh-pages
\`\`\`

3. 在 \`package.json\` 的 scripts 加入：
\`\`\`json
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"
\`\`\`

4. 執行部署：
\`\`\`bash
npm run deploy
\`\`\`

5. 到 GitHub 倉庫的 Settings > Pages，確認 Source 為 \`gh-pages\` 分支

---

### 自架伺服器（Nginx）

**Step 1**：構建靜態文件
\`\`\`bash
npm run build
\`\`\`

**Step 2**：將 \`dist/\` 目錄內容上傳至伺服器，例如 \`/var/www/ai-story-forge/\`

**Step 3**：設定 Nginx（\`/etc/nginx/sites-available/ai-story-forge\`）：
\`\`\`nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/ai-story-forge;
    index index.html;

    # 重要：SPA 路由支援
    location / {
        try_files $uri $uri/ /index.html;
    }

    # 靜態資源快取
    location ~* \\.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
\`\`\`

**Step 4**：重新載入 Nginx：
\`\`\`bash
sudo nginx -t
sudo systemctl reload nginx
\`\`\`

---

## 7. 常見問題

**Q：部署後刷新頁面顯示 404？**
A：這是 SPA 路由問題。請參考各平台的「解決刷新 404」章節，設定所有路徑都指向 \`index.html\`。

**Q：API 呼叫失敗，顯示 CORS 錯誤？**
A：請確認你在 dify.ai 的應用設定中，已允許你的部署網域進行 API 呼叫。

**Q：資料會遺失嗎？**
A：所有資料儲存在瀏覽器 IndexedDB，清除瀏覽器資料才會消失。建議定期使用「匯出資料庫」功能備份。

**Q：可以多人共用同一個部署嗎？**
A：由於資料儲存在瀏覽器本地，每個用戶的資料是獨立的，互不干擾，可以多人使用同一個網址。

---

_如有其他問題，歡迎在 Readdy.ai 社群提問_
`;

const DIFY_SETUP_MD = `# Dify.ai 模型設定指南

AI Story Forge 需要在你的 dify.ai 帳戶中建立 **4 個獨立的應用**，分別對應四種創作功能。

---

## 準備工作

1. 前往 [dify.ai](https://dify.ai)，登入或註冊帳號
2. 進入「工作室」（Studio）頁面
3. 依照以下步驟建立 4 個 Chatbot 或 Completion 應用

---

## 建立 4 個 LLM 應用

### A LLM — 世界觀設定模型

**用途**：根據使用者想法或現有故事，生成故事世界觀設定

**建立步驟**：
1. 點擊「建立應用」→ 選擇「文字生成」（Text Generation）或「聊天助手」
2. 應用名稱填入：\`AI Story Forge - 世界觀設定\`
3. 在 System Prompt（系統提示詞）填入：
\`\`\`
你是一位專業的奇幻/科幻/現代世界觀設計師，擅長構建豐富、完整、有內在邏輯的故事世界。
當用戶提供世界觀概念或現有故事時，你需要從以下維度進行世界觀設計：

1. **世界基礎設定**：地理、氣候、生態環境
2. **歷史背景**：重要歷史事件、時代背景
3. **社會結構**：政治制度、階級分層、種族/族群
4. **文化與信仰**：宗教、風俗、藝術、語言
5. **特殊設定**：魔法/科技系統、獨特規則（如有）
6. **衝突與張力**：世界中存在的主要矛盾與問題

請以條理清晰、易於理解的方式呈現，適合作為小說創作的參考設定。
\`\`\`
4. 儲存後，前往「API 訪問」頁面，複製 **API Key** 與 **Base URL**
5. 將這兩個值填入 AI Story Forge 的「API 設定」→「A LLM」欄位

---

### B LLM — 角色設定模型

**用途**：根據世界觀生成角色設定

**System Prompt 建議**：
\`\`\`
你是一位資深小說角色設計師，能夠根據故事世界觀設計立體、有深度的人物角色。
每個角色設計需包含：

1. **基本資料**：姓名、年齡、性別、種族/身分
2. **外貌描述**：簡短但有特色的外觀描述
3. **身份背景**：職業、社會地位、家庭背景
4. **性格特質**：核心性格、優點與缺點
5. **動機與目標**：角色的核心欲望與驅動力
6. **祕密或傷痛**：隱藏在表面下的深層背景（增加戲劇張力）

請確保每個角色與世界觀設定相符，且角色之間具有互動潛力。
以 JSON 格式回應，方便程式解析，並附上簡短的角色簡介。
\`\`\`

---

### C LLM — 大綱設定模型

**用途**：根據世界觀與角色生成故事大綱與章節規劃

**System Prompt 建議**：
\`\`\`
你是一位經驗豐富的故事結構設計師，熟悉三幕劇、英雄旅程、非線性敘事等各種敘事結構。
根據提供的世界觀與角色，設計引人入勝的故事大綱。

大綱設計原則：
1. **起點明確**：清楚的故事起始狀態與觸發事件
2. **衝突遞進**：主衝突的逐步升級
3. **角色成長**：主角在故事中的內外在轉變
4. **伏筆與轉折**：適當的懸念設置與情節轉折
5. **結局合理**：符合角色邏輯的故事結局

針對不同篇幅給予對應深度的大綱，短篇著重情節骨幹，長篇需設計章節結構。
\`\`\`

---

### D LLM — 故事生成模型

**用途**：根據大綱生成完整故事文本

**System Prompt 建議**：
\`\`\`
你是一位才華橫溢的小說家，擅長以優美流暢的文字將故事大綱轉化為生動的故事內容。

寫作風格要求：
1. **場景描寫**：運用感官細節，讓讀者身臨其境
2. **對話自然**：符合角色性格的對白，推動情節發展
3. **節奏把控**：張弛有度，高潮前的鋪墊與緊張時刻的渲染
4. **心理刻畫**：適時展現角色的內心世界與情感變化
5. **細節豐富**：符合世界觀設定的細節，增加真實感

嚴格依據提供的世界觀、角色設定與故事大綱進行創作，保持設定的一致性。
字數需接近用戶指定的目標字數。
\`\`\`

---

## 在 AI Story Forge 中填入設定

1. 打開應用，點擊左側邊欄底部的「API 設定」按鈕
2. 依序填入 4 個 LLM 的設定：
   - **Dify Base URL**：通常為 \`https://api.dify.ai/v1\`（自架 Dify 填入自己的網址）
   - **API Key**：在 dify.ai 各應用的「API 訪問」頁面取得，格式為 \`app-xxxxxxxxxxxxxxxxxx\`
3. 點擊「儲存設定」
4. 所有設定完成後，即可開始使用所有 AI 功能！

---

## 注意事項

- API Key 儲存在瀏覽器的 LocalStorage 中，僅你本人可見
- 每次呼叫 AI 功能都會消耗你在 dify.ai 的 Token 用量
- 建議在 dify.ai 設定使用量上限，避免意外超額

---

_需要更多幫助？前往 [dify.ai 官方文件](https://docs.dify.ai)_
`;

const ENV_EXAMPLE = `# AI Story Forge — 環境設定範例
# 複製此文件為 .env，並填入你的設定

# 應用基本設定
VITE_APP_TITLE=AI Story Forge

# 注意：Dify API Key 儲存在瀏覽器 LocalStorage 中
# 不需要在此設定，直接在應用的「API 設定」介面填入即可

# 如需自訂 Base URL（自架 Dify 用戶）
# VITE_DEFAULT_DIFY_BASE_URL=https://your-dify-instance.com/v1
`;

export async function downloadProjectZip(): Promise<void> {
  const [{ default: JSZip }, { projectFiles }] = await Promise.all([
    import('jszip'),
    import('./projectFilesBundle'),
  ]);

  const zip = new JSZip();
  const root = zip.folder('ai-story-forge');
  if (!root) return;

  // ── 所有原始碼檔案 ──────────────────────────────────────
  for (const file of projectFiles) {
    // 建立中間資料夾並放入檔案
    const segments = file.path.split('/');
    const fileName = segments.pop()!;
    let folder = root;
    for (const seg of segments) {
      folder = folder.folder(seg) ?? folder;
    }
    folder.file(fileName, file.content);
  }

  // ── 部署文檔（額外補充，方便使用者直接閱讀）──────────────
  root.file('README.md', README_MD);
  root.file('DEPLOYMENT.md', DEPLOYMENT_MD);
  root.file('DIFY_SETUP.md', DIFY_SETUP_MD);
  root.file('.env.example', ENV_EXAMPLE);

  const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 9 } });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'ai-story-forge.zip';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ─── JSON Database Export ──────────────────────────────────────────────────────
export async function exportDatabaseAsJSON(): Promise<void> {
  const data = await exportAllData();
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `ai-story-forge-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ─── Markdown Export ──────────────────────────────────────────────────────────
export function exportAsMarkdown(title: string, content: string): void {
  const markdown = `# ${title}\n\n${content}\n\n---\n_由 AI Story Forge 匯出 · ${new Date().toLocaleDateString('zh-TW')}_`;
  const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${title.replace(/\s+/g, '-')}.md`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ─── PDF Export ────────────────────────────────────────────────────────────────
export async function exportAsPDF(title: string, content: string): Promise<void> {
  const { jsPDF } = await import('jspdf');
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  const maxWidth = pageWidth - margin * 2;
  let y = margin;

  // Title
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  const titleLines = doc.splitTextToSize(title, maxWidth);
  doc.text(titleLines, margin, y);
  y += titleLines.length * 10 + 8;

  // Divider
  doc.setDrawColor(200, 180, 150);
  doc.line(margin, y, pageWidth - margin, y);
  y += 8;

  // Content
  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  const lines = doc.splitTextToSize(content, maxWidth);

  lines.forEach((line: string) => {
    if (y > pageHeight - margin) {
      doc.addPage();
      y = margin;
    }
    doc.text(line, margin, y);
    y += 6;
  });

  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(9);
    doc.setTextColor(150);
    doc.text(
      `AI Story Forge · ${new Date().toLocaleDateString('zh-TW')} · ${i} / ${pageCount}`,
      pageWidth / 2,
      pageHeight - 10,
      { align: 'center' }
    );
  }

  doc.save(`${title.replace(/\s+/g, '-')}.pdf`);
}
