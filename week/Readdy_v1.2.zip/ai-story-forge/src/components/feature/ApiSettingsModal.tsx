import { useState } from 'react';
import { loadApiSettings, saveApiSettings, type ApiSettings, type ApiConfig } from '../../utils/difyApi';
import { downloadProjectZip } from '../../utils/exportUtils';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

interface LlmFieldProps {
  label: string;
  desc: string;
  icon: string;
  color: string;
  config: ApiConfig;
  onChange: (field: keyof ApiConfig, value: string) => void;
}

function LlmField({ label, desc, icon, color, config, onChange }: LlmFieldProps) {
  return (
    <div className={`rounded-xl border-l-4 ${color} bg-white p-5`}>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-9 h-9 flex items-center justify-center rounded-lg bg-stone-100">
          <i className={`${icon} text-stone-700 text-base`} />
        </div>
        <div>
          <p className="font-semibold text-stone-800 text-sm">{label}</p>
          <p className="text-stone-500 text-xs">{desc}</p>
        </div>
      </div>
      <div className="space-y-3">
        <div>
          <label className="block text-xs font-medium text-stone-600 mb-1">Dify Base URL</label>
          <input
            type="url"
            value={config.baseUrl}
            onChange={(e) => onChange('baseUrl', e.target.value)}
            placeholder="https://api.dify.ai/v1"
            className="w-full px-3 py-2 text-sm border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-400 bg-stone-50"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-stone-600 mb-1">API Key</label>
          <input
            type="password"
            value={config.apiKey}
            onChange={(e) => onChange('apiKey', e.target.value)}
            placeholder="app-xxxxxxxxxxxxxxxx"
            className="w-full px-3 py-2 text-sm border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-400 bg-stone-50"
          />
        </div>
      </div>
    </div>
  );
}

export default function ApiSettingsModal({ isOpen, onClose }: Props) {
  const [settings, setSettings] = useState<ApiSettings>(() => loadApiSettings());
  const [saved, setSaved] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadDone, setDownloadDone] = useState(false);

  if (!isOpen) return null;

  const update = (llm: keyof ApiSettings, field: keyof ApiConfig, value: string) => {
    setSettings((prev) => ({ ...prev, [llm]: { ...prev[llm], [field]: value } }));
    setSaved(false);
  };

  const handleSave = () => {
    saveApiSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadProjectZip();
      setDownloadDone(true);
      setTimeout(() => setDownloadDone(false), 3000);
    } catch {
      // silent fail
    } finally {
      setDownloading(false);
    }
  };

  const llmConfigs: { key: keyof ApiSettings; label: string; desc: string; icon: string; color: string }[] = [
    { key: 'aLlm', label: 'A LLM — 世界觀設定模型', desc: '用於世界觀創造與擴展', icon: 'ri-earth-line', color: 'border-amber-400' },
    { key: 'bLlm', label: 'B LLM — 角色設定模型', desc: '用於角色生成與設定', icon: 'ri-user-3-line', color: 'border-rose-400' },
    { key: 'cLlm', label: 'C LLM — 大綱設定模型', desc: '用於故事大綱與章節規劃', icon: 'ri-file-list-3-line', color: 'border-teal-400' },
    { key: 'dLlm', label: 'D LLM — 故事生成模型', desc: '用於實際故事文本生成', icon: 'ri-quill-pen-line', color: 'border-violet-400' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-stone-50 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto mx-4 shadow-2xl">
        <div className="sticky top-0 bg-stone-50 border-b border-stone-200 px-6 py-5 flex items-center justify-between rounded-t-2xl">
          <div>
            <h2 className="text-lg font-bold text-stone-800">API 設定</h2>
            <p className="text-sm text-stone-500 mt-0.5">連接你的 dify.ai 模型，開始 AI 創作</p>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center rounded-lg hover:bg-stone-200 transition-colors cursor-pointer"
          >
            <i className="ri-close-line text-stone-600 text-xl" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3">
            <i className="ri-information-line text-amber-600 text-lg mt-0.5 flex-shrink-0" />
            <div className="text-sm text-amber-800">
              <p className="font-medium mb-1">如何設定 Dify API？</p>
              <p className="text-amber-700 text-xs leading-relaxed">
                請前往 dify.ai 為每個功能分別建立應用，並在各應用中設定好 System Prompt。
                取得 API Key 後，填入對應欄位。Base URL 通常為 <code className="bg-amber-100 px-1 rounded">https://api.dify.ai/v1</code>（自架者請填入自己的 URL）。
              </p>
            </div>
          </div>

          {llmConfigs.map((cfg) => (
            <LlmField
              key={cfg.key}
              label={cfg.label}
              desc={cfg.desc}
              icon={cfg.icon}
              color={cfg.color}
              config={settings[cfg.key]}
              onChange={(field, value) => update(cfg.key, field, value)}
            />
          ))}

          {/* Project Download Section */}
          <div className="rounded-xl border border-stone-200 bg-gradient-to-br from-stone-800 to-stone-900 p-5">
            <div className="flex items-start gap-4">
              <div className="w-11 h-11 flex items-center justify-center rounded-xl bg-amber-500/20 flex-shrink-0">
                <i className="ri-folder-zip-line text-amber-400 text-xl" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-white text-sm mb-1">專案下載</p>
                <p className="text-stone-400 text-xs leading-relaxed">
                  喜歡這個應用？下載 <strong className="text-stone-300">.zip</strong>，包含<strong className="text-stone-300">完整專案原始碼</strong>與部署教學，解壓縮後直接 <code className="bg-stone-700 px-1 rounded text-amber-300">npm install && npm run dev</code> 即可執行。
                </p>
                <div className="flex flex-wrap gap-2 mt-3">
                  {['所有 src/ 原始碼', 'package.json', 'vite.config.ts', 'DEPLOYMENT.md', 'DIFY_SETUP.md'].map((f) => (
                    <span key={f} className="text-xs bg-stone-700 text-stone-300 px-2 py-0.5 rounded-full font-mono">
                      {f}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <button
              onClick={handleDownload}
              disabled={downloading}
              className={`mt-4 w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                downloadDone
                  ? 'bg-green-500 text-white'
                  : 'bg-amber-500 hover:bg-amber-400 text-white'
              }`}
            >
              {downloading ? (
                <><i className="ri-loader-4-line animate-spin" /> 打包中...</>
              ) : downloadDone ? (
                <><i className="ri-check-double-line" /> 下載完成！</>
              ) : (
                <><i className="ri-download-cloud-line" /> 下載專案部署包</>
              )}
            </button>
          </div>
        </div>

        <div className="sticky bottom-0 bg-stone-50 border-t border-stone-200 px-6 py-4 flex justify-end gap-3 rounded-b-2xl">
          <button
            onClick={onClose}
            className="px-5 py-2.5 text-sm font-medium text-stone-600 hover:text-stone-800 hover:bg-stone-200 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            取消
          </button>
          <button
            onClick={handleSave}
            className={`px-5 py-2.5 text-sm font-medium rounded-lg transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
              saved
                ? 'bg-green-500 text-white'
                : 'bg-amber-500 hover:bg-amber-600 text-white'
            }`}
          >
            {saved ? (
              <><i className="ri-check-line" /> 已儲存！</>
            ) : (
              <><i className="ri-save-line" /> 儲存設定</>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
