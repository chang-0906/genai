import type { RouteObject } from 'react-router-dom';
import NotFound from '../pages/NotFound';
import AppLayout from '../components/feature/AppLayout';
import HomePage from '../pages/home/page';
import WorldviewPage from '../pages/worldview/page';
import CharactersPage from '../pages/characters/page';
import OutlinePage from '../pages/outline/page';
import StoryPage from '../pages/story/page';
import ArchivePage from '../pages/archive/page';

const routes: RouteObject[] = [
  {
    path: '/',
    element: (
      <AppLayout>
        <HomePage />
      </AppLayout>
    ),
  },
  {
    path: '/worldview',
    element: (
      <AppLayout>
        <WorldviewPage />
      </AppLayout>
    ),
  },
  {
    path: '/characters',
    element: (
      <AppLayout>
        <CharactersPage />
      </AppLayout>
    ),
  },
  {
    path: '/outline',
    element: (
      <AppLayout>
        <OutlinePage />
      </AppLayout>
    ),
  },
  {
    path: '/story',
    element: (
      <AppLayout>
        <StoryPage />
      </AppLayout>
    ),
  },
  {
    path: '/archive',
    element: (
      <AppLayout>
        <ArchivePage />
      </AppLayout>
    ),
  },
  {
    path: '*',
    element: <NotFound />,
  },
];

export default routes;
