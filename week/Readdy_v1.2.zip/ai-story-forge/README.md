# AI Story Forge

**AI Story Forge** 是一款 AI 輔助互動創作故事應用，整合 dify.ai 的 LLM API，讓使用者可以串接自己的 AI 模型，協助構建世界觀、角色、大綱，並生成完整故事。

## 核心功能

| 功能模組 | 說明 |
|----------|------|
| 🌍 世界觀創造 | 手動建立 / AI 擴展 / AI 從小說提取 三種模式 |
| 👤 角色設定  | 選擇世界觀 → AI 批量生成角色 → 留/棄/修改審閱流程 |
| 📋 大綱規劃  | 選世界觀與角色 → 選篇幅 → AI 生成章節大綱 |
| ✍️ 故事生成  | 根據大綱分章節讓 D LLM 生成完整故事文本 |
| 🗃️ 封存箱   | 暫存不使用的世界觀、角色、大綱卡片 |

## 技術棧

- **前端框架**：React 19 + TypeScript
- **樣式**：Tailwind CSS v3
- **路由**：React Router v7
- **資料儲存**：IndexedDB（本地持久化，無需後端）
- **AI 串接**：dify.ai Chatbot / Completion API
- **PDF 匯出**：jsPDF
- **構建工具**：Vite

## 快速開始

詳細部署步驟請參閱 [DEPLOYMENT.md](./DEPLOYMENT.md)。

## Dify.ai 設定指引

請參閱 [DIFY_SETUP.md](./DIFY_SETUP.md) 了解如何設定四個 LLM 模型。

---

_此文件由 AI Story Forge 專案下載包自動生成_
