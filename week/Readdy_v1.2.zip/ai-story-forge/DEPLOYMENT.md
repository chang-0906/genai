# AI Story Forge — 部署指南

本指南將一步步帶你完成 AI Story Forge 的本地開發與生產環境部署。

---

## 目錄

1. [系統需求](#1-系統需求)
2. [取得原始碼](#2-取得原始碼)
3. [安裝依賴](#3-安裝依賴)
4. [本地開發](#4-本地開發)
5. [生產構建](#5-生產構建)
6. [部署選項](#6-部署選項)
   - [Vercel（推薦）](#vercel-推薦)
   - [Netlify](#netlify)
   - [GitHub Pages](#github-pages)
   - [自架伺服器（Nginx）](#自架伺服器-nginx)
7. [常見問題](#7-常見問題)

---

## 1. 系統需求

在開始之前，請確認你的電腦已安裝以下軟體：

| 軟體 | 最低版本 | 下載連結 |
|------|---------|---------|
| Node.js | 18.x 以上 | https://nodejs.org |
| npm | 9.x 以上（隨 Node.js 一起安裝）| — |
| Git | 任意版本 | https://git-scm.com |

驗證版本：
```bash
node -v    # 應顯示 v18.x.x 或更高
npm -v     # 應顯示 9.x.x 或更高
```

---

## 2. 取得原始碼

### 方式 A：從 Readdy.ai 匯出（推薦）

1. 前往 [readdy.ai](https://readdy.ai)，開啟此 AI Story Forge 專案
2. 點擊右上角「匯出專案」或「Export」按鈕
3. 下載 .zip 原始碼包後，解壓縮到你想要的目錄

### 方式 B：從 GitHub Clone

如果此專案已托管於 GitHub：
```bash
git clone https://github.com/your-username/ai-story-forge.git
cd ai-story-forge
```

---

## 3. 安裝依賴

進入專案目錄後，執行：

```bash
npm install
```

這會自動安裝所有必要的套件（約需 1-3 分鐘，取決於網路速度）。

---

## 4. 本地開發

啟動本地開發伺服器：

```bash
npm run dev
```

成功後，終端機會顯示：
```
  VITE v8.x.x  ready in xxx ms
  ➜  Local:   http://localhost:5173/
  ➜  Network: http://192.168.x.x:5173/
```

打開瀏覽器前往 http://localhost:5173 即可看到應用。

> **⚠️ 注意**：應用資料儲存在 IndexedDB（瀏覽器本地），每個瀏覽器的資料是獨立的。

---

## 5. 生產構建

構建優化後的靜態文件：

```bash
npm run build
```

構建完成後，靜態文件會輸出到 `dist/` 目錄。你可以本地預覽：

```bash
npm run preview
```

---

## 6. 部署選項

### Vercel（推薦）

Vercel 是最簡單的部署方式，完全免費（個人使用）：

**方式一：連接 GitHub 自動部署**
1. 將專案推送到 GitHub 倉庫
2. 前往 [vercel.com](https://vercel.com)，使用 GitHub 帳號登入
3. 點擊「New Project」，選擇你的 GitHub 倉庫
4. 保持預設設定，點擊「Deploy」
5. 幾分鐘後，你會得到一個 `xxx.vercel.app` 的網址

**方式二：使用 Vercel CLI**
```bash
npm install -g vercel
vercel login
vercel
```

**Vercel 設定（vercel.json）**—— 若遇到刷新頁面 404，請在專案根目錄建立此文件：
```json
{
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

---

### Netlify

1. 前往 [netlify.com](https://netlify.com)，登入後點擊「New site from Git」
2. 連接你的 GitHub/GitLab/Bitbucket 倉庫
3. 構建設定填入：
   - **Build command**：`npm run build`
   - **Publish directory**：`dist`
4. 點擊「Deploy site」

**解決刷新 404 問題**——在 `public/` 目錄建立 `_redirects` 文件：
```
/*    /index.html   200
```

---

### GitHub Pages

1. 在 `vite.config.ts` 中設定 base（替換為你的倉庫名稱）：
```ts
export default defineConfig({
  base: '/ai-story-forge/',
  // ...
})
```

2. 安裝部署套件：
```bash
npm install --save-dev gh-pages
```

3. 在 `package.json` 的 scripts 加入：
```json
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"
```

4. 執行部署：
```bash
npm run deploy
```

5. 到 GitHub 倉庫的 Settings > Pages，確認 Source 為 `gh-pages` 分支

---

### 自架伺服器（Nginx）

**Step 1**：構建靜態文件
```bash
npm run build
```

**Step 2**：將 `dist/` 目錄內容上傳至伺服器，例如 `/var/www/ai-story-forge/`

**Step 3**：設定 Nginx（`/etc/nginx/sites-available/ai-story-forge`）：
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/ai-story-forge;
    index index.html;

    # 重要：SPA 路由支援
    location / {
        try_files $uri $uri/ /index.html;
    }

    # 靜態資源快取
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

**Step 4**：重新載入 Nginx：
```bash
sudo nginx -t
sudo systemctl reload nginx
```

---

## 7. 常見問題

**Q：部署後刷新頁面顯示 404？**
A：這是 SPA 路由問題。請參考各平台的「解決刷新 404」章節，設定所有路徑都指向 `index.html`。

**Q：API 呼叫失敗，顯示 CORS 錯誤？**
A：請確認你在 dify.ai 的應用設定中，已允許你的部署網域進行 API 呼叫。

**Q：資料會遺失嗎？**
A：所有資料儲存在瀏覽器 IndexedDB，清除瀏覽器資料才會消失。建議定期使用「匯出資料庫」功能備份。

**Q：可以多人共用同一個部署嗎？**
A：由於資料儲存在瀏覽器本地，每個用戶的資料是獨立的，互不干擾，可以多人使用同一個網址。

---

_如有其他問題，歡迎在 Readdy.ai 社群提問_
