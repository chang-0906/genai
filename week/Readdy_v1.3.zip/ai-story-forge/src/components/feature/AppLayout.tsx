import { useState, type ReactNode } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import ApiSettingsModal from './ApiSettingsModal';
import { exportDatabaseAsJSON, downloadProjectZip } from '../../utils/exportUtils';
import { useTheme } from '../../hooks/useTheme';

interface NavItem {
  to: string;
  icon: string;
  label: string;
  badge?: string;
  badgeColor?: string;
}

const navItems: NavItem[] = [
  { to: '/', icon: 'ri-compass-3-line', label: '儀表板' },
  { to: '/worldview', icon: 'ri-earth-line', label: '世界觀創造', badge: 'A', badgeColor: 'bg-amber-500' },
  { to: '/characters', icon: 'ri-user-3-line', label: '角色設定', badge: 'B', badgeColor: 'bg-rose-500' },
  { to: '/outline', icon: 'ri-file-list-3-line', label: '大綱規劃', badge: 'C', badgeColor: 'bg-teal-500' },
  { to: '/story', icon: 'ri-quill-pen-line', label: '故事生成', badge: 'D', badgeColor: 'bg-violet-500' },
];

const bottomNavItems: NavItem[] = [
  { to: '/archive', icon: 'ri-archive-line', label: '封存箱' },
];

interface AppLayoutProps {
  children: ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const [apiModalOpen, setApiModalOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const navigate = useNavigate();
  const { isDark, toggle } = useTheme();

  const handleExport = async () => {
    setExporting(true);
    try {
      await exportDatabaseAsJSON();
    } catch {
      // silent fail
    } finally {
      setExporting(false);
    }
  };

  const handleDownloadProject = async () => {
    setDownloading(true);
    try {
      await downloadProjectZip();
    } catch {
      // silent fail
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="flex h-screen bg-stone-50 dark:bg-stone-950 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-60 flex-shrink-0 bg-stone-900 flex flex-col">
        {/* Logo */}
        <div
          className="px-5 py-5 flex items-center gap-3 cursor-pointer"
          onClick={() => navigate('/')}
        >
          <img
            src="https://public.readdy.ai/ai/img_res/33134f09-22a1-4f62-b068-2a1e1b0eb504.png"
            alt="AI Story Forge"
            className="w-9 h-9 object-contain rounded-lg"
          />
          <div>
            <p className="text-white font-bold text-sm leading-tight">AI Story</p>
            <p className="text-amber-400 text-xs font-medium tracking-wider">FORGE</p>
          </div>
        </div>

        <div className="px-3 mb-2">
          <div className="h-px bg-stone-700" />
        </div>

        {/* Main Navigation */}
        <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
          <p className="text-stone-500 text-xs font-semibold uppercase tracking-wider px-3 py-2">創作流程</p>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-white'
                    : 'text-stone-400 hover:text-white hover:bg-stone-800'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <div className="w-5 h-5 flex items-center justify-center">
                    <i className={`${item.icon} text-base`} />
                  </div>
                  <span className="flex-1 whitespace-nowrap">{item.label}</span>
                  {item.badge && (
                    <span
                      className={`text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full flex-shrink-0 ${
                        isActive ? 'bg-white/30' : item.badgeColor
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </>
              )}
            </NavLink>
          ))}

          <div className="pt-4">
            <p className="text-stone-500 text-xs font-semibold uppercase tracking-wider px-3 py-2">管理</p>
            {bottomNavItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-amber-500 text-white'
                      : 'text-stone-400 hover:text-white hover:bg-stone-800'
                  }`
                }
              >
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className={`${item.icon} text-base`} />
                </div>
                <span className="whitespace-nowrap">{item.label}</span>
              </NavLink>
            ))}
          </div>
        </nav>

        {/* Bottom Actions */}
        <div className="px-3 pb-5 space-y-1 border-t border-stone-700 pt-3">
          {/* Theme Toggle */}
          <button
            onClick={toggle}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-stone-400 hover:text-white hover:bg-stone-800 transition-all cursor-pointer whitespace-nowrap"
          >
            <div className="w-5 h-5 flex items-center justify-center">
              <i className={`${isDark ? 'ri-sun-line' : 'ri-moon-line'} text-base`} />
            </div>
            <span>{isDark ? '切換淺色模式' : '切換深色模式'}</span>
          </button>

          <button
            onClick={handleExport}
            disabled={exporting}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-stone-400 hover:text-white hover:bg-stone-800 transition-all cursor-pointer whitespace-nowrap"
          >
            <div className="w-5 h-5 flex items-center justify-center">
              <i className={`${exporting ? 'ri-loader-4-line animate-spin' : 'ri-database-2-line'} text-base`} />
            </div>
            <span>{exporting ? '匯出中...' : '匯出資料庫'}</span>
          </button>
          <button
            onClick={handleDownloadProject}
            disabled={downloading}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-stone-400 hover:text-amber-300 hover:bg-stone-800 transition-all cursor-pointer whitespace-nowrap group"
          >
            <div className="w-5 h-5 flex items-center justify-center">
              <i className={`${downloading ? 'ri-loader-4-line animate-spin' : 'ri-folder-zip-line'} text-base`} />
            </div>
            <span className="flex-1 text-left">{downloading ? '準備中...' : '專案下載'}</span>
            {!downloading && (
              <span className="text-xs bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded-full font-medium group-hover:bg-amber-500/30">
                .zip
              </span>
            )}
          </button>
          <button
            onClick={() => setApiModalOpen(true)}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-stone-400 hover:text-white hover:bg-stone-800 transition-all cursor-pointer whitespace-nowrap"
          >
            <div className="w-5 h-5 flex items-center justify-center">
              <i className="ri-settings-3-line text-base" />
            </div>
            <span>API 設定</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto dark:bg-stone-950">
        {children}
      </main>

      <ApiSettingsModal isOpen={apiModalOpen} onClose={() => setApiModalOpen(false)} />
    </div>
  );
}
