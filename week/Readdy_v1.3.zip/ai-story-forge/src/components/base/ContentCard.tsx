import { useState, type ReactNode } from 'react';

interface ContentCardProps {
  title: string;
  content: string;
  tags?: string[];
  badges?: { label: string; color: string }[];
  onEdit?: (newContent: string, newTitle?: string) => void;
  onArchive?: () => void;
  onDelete?: () => void;
  onExportMd?: () => void;
  onExportPdf?: () => void;
  children?: ReactNode;
  headerExtra?: ReactNode;
  compact?: boolean;
}

export default function ContentCard({
  title,
  content,
  tags,
  badges,
  onEdit,
  onArchive,
  onDelete,
  onExportMd,
  onExportPdf,
  children,
  headerExtra,
  compact = false,
}: ContentCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(title);
  const [editContent, setEditContent] = useState(content);
  const [expanded, setExpanded] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const handleSave = () => {
    onEdit?.(editContent, editTitle);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditTitle(title);
    setEditContent(content);
    setIsEditing(false);
  };

  const displayContent = expanded ? content : (content.length > 300 ? content.slice(0, 300) + '…' : content);

  return (
    <div className="bg-white dark:bg-stone-800 rounded-2xl border border-stone-200 dark:border-stone-700 overflow-hidden transition-all hover:border-stone-300 dark:hover:border-stone-600">
      {/* Card Header */}
      <div className={`flex items-start justify-between gap-3 ${compact ? 'px-4 py-3' : 'px-5 py-4'} border-b border-stone-100 dark:border-stone-700`}>
        <div className="flex-1 min-w-0">
          {isEditing ? (
            <input
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              className="w-full text-sm font-bold text-stone-800 dark:text-stone-100 bg-amber-50 dark:bg-amber-900/30 border border-amber-300 dark:border-amber-600 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
          ) : (
            <h3 className={`font-bold text-stone-800 dark:text-stone-100 truncate ${compact ? 'text-sm' : 'text-base'}`}>{title}</h3>
          )}
          {badges && badges.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {badges.map((b, i) => (
                <span key={i} className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium text-white ${b.color}`}>
                  {b.label}
                </span>
              ))}
            </div>
          )}
          {tags && tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {tags.map((tag, i) => (
                <span key={i} className="px-2 py-0.5 rounded-full text-xs bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300">
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          {headerExtra}
          {onEdit && !isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-500 dark:text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 transition-colors cursor-pointer"
              title="編輯"
            >
              <i className="ri-pencil-line text-sm" />
            </button>
          )}
          {(onArchive || onDelete || onExportMd || onExportPdf) && (
            <div className="relative">
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-500 dark:text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 transition-colors cursor-pointer"
              >
                <i className="ri-more-2-line text-sm" />
              </button>
              {menuOpen && (
                <div className="absolute right-0 top-9 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl py-1.5 z-10 min-w-36">
                  {onExportMd && (
                    <button
                      onClick={() => { onExportMd(); setMenuOpen(false); }}
                      className="w-full flex items-center gap-2 px-4 py-2 text-sm text-stone-700 dark:text-stone-200 hover:bg-stone-50 dark:hover:bg-stone-700 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-markdown-line" /> 匯出 Markdown
                    </button>
                  )}
                  {onExportPdf && (
                    <button
                      onClick={() => { onExportPdf(); setMenuOpen(false); }}
                      className="w-full flex items-center gap-2 px-4 py-2 text-sm text-stone-700 dark:text-stone-200 hover:bg-stone-50 dark:hover:bg-stone-700 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-file-pdf-line" /> 匯出 PDF
                    </button>
                  )}
                  {onArchive && (
                    <button
                      onClick={() => { onArchive(); setMenuOpen(false); }}
                      className="w-full flex items-center gap-2 px-4 py-2 text-sm text-stone-700 dark:text-stone-200 hover:bg-stone-50 dark:hover:bg-stone-700 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-archive-line" /> 封存
                    </button>
                  )}
                  {onDelete && (
                    <button
                      onClick={() => { onDelete(); setMenuOpen(false); }}
                      className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-delete-bin-line" /> 刪除
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Card Body */}
      <div className={compact ? 'px-4 py-3' : 'px-5 py-4'}>
        {isEditing ? (
          <textarea
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            className="w-full min-h-40 text-sm text-stone-700 dark:text-stone-200 bg-amber-50 dark:bg-amber-900/20 border border-amber-300 dark:border-amber-600 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-amber-400 resize-y leading-relaxed"
          />
        ) : (
          <div>
            <p className="text-sm text-stone-600 dark:text-stone-300 leading-relaxed whitespace-pre-wrap">{displayContent}</p>
            {content.length > 300 && (
              <button
                onClick={() => setExpanded(!expanded)}
                className="mt-2 text-xs text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 font-medium cursor-pointer"
              >
                {expanded ? '收起' : '展開全文'}
              </button>
            )}
          </div>
        )}

        {children && <div className="mt-3">{children}</div>}

        {isEditing && (
          <div className="flex justify-end gap-2 mt-3">
            <button
              onClick={handleCancel}
              className="px-4 py-2 text-sm text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              取消
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 text-sm bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap"
            >
              儲存修改
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
