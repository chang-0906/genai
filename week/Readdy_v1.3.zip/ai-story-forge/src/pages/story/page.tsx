import { useState, useEffect, useRef } from 'react';
import {
  outlinesDB,
  storiesDB,
  worldviewsDB,
  charactersDB,
  type Outline,
  type Story,
  type StoryChapter,
} from '../../utils/db';
import {
  loadApiSettings,
  generateStory,
  generateStoryChapter,
  isApiConfigured,
} from '../../utils/difyApi';
import { mockStories } from '../../mocks/stories';
import {
  OutlineSelectorForStory,
  ChapterGenerationProgress,
  StoryCard,
  StoryReader,
  type ChapterProgress,
} from './components/StoryComponents';

type Step = 'select' | 'generating' | 'done';

export default function StoryPage() {
  const [step, setStep] = useState<Step>('select');
  const [outlines, setOutlines] = useState<Outline[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [selectedOutlineId, setSelectedOutlineId] = useState('');
  const [chapterProgress, setChapterProgress] = useState<ChapterProgress[]>([]);
  const [noChapterStatus, setNoChapterStatus] = useState<'pending' | 'generating' | 'done' | 'error'>('pending');
  const [error, setError] = useState('');
  const [readingStory, setReadingStory] = useState<Story | null>(null);
  const [storyTitle, setStoryTitle] = useState('');
  const [loaded, setLoaded] = useState(false);
  const abortRef = useRef(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [outAll, storyAll] = await Promise.all([outlinesDB.getAll(), storiesDB.getAll()]);
      setOutlines(outAll.filter((o) => !o.archived).sort((a, b) => b.createdAt - a.createdAt));
      const activeStories = storyAll.sort((a, b) => b.createdAt - a.createdAt);
      if (activeStories.length === 0) {
        await Promise.all(mockStories.map((s) => storiesDB.create(s)));
        const seeded = await storiesDB.getAll();
        setStories(seeded.sort((a, b) => b.createdAt - a.createdAt));
      } else {
        setStories(activeStories);
      }
    } catch {
      setOutlines([]);
      setStories([]);
    } finally {
      setLoaded(true);
    }
  };

  const selectedOutline = outlines.find((o) => o.id === selectedOutlineId);
  const hasChapters = (selectedOutline?.chapters.length ?? 0) > 0;

  const handleStartGeneration = async () => {
    if (!selectedOutline || !storyTitle.trim()) return;
    const settings = loadApiSettings();
    if (!isApiConfigured(settings.dLlm)) {
      setError('D LLM 尚未設定，請先在「API 設定」中填入故事生成模型的 Base URL 與 API Key');
      return;
    }

    setError('');
    setStep('generating');
    abortRef.current = false;

    const worldviewContent = await fetchWorldviewContent(selectedOutline.worldviewId);
    const charactersContent = await fetchCharactersContent(selectedOutline.characterIds);

    try {
      let generatedChapters: StoryChapter[] = [];

      if (hasChapters) {
        // Chapter by chapter generation
        const initialProgress: ChapterProgress[] = selectedOutline.chapters.map((ch) => ({
          index: ch.index,
          title: ch.title,
          status: 'pending',
        }));
        setChapterProgress(initialProgress);

        for (let i = 0; i < selectedOutline.chapters.length; i++) {
          if (abortRef.current) break;
          const ch = selectedOutline.chapters[i];
          const chWordCount = Math.floor(selectedOutline.wordCount / selectedOutline.chapters.length);

          setChapterProgress((prev) =>
            prev.map((p) => p.index === ch.index ? { ...p, status: 'generating' } : p)
          );

          try {
            const content = await generateStoryChapter(
              settings.dLlm,
              worldviewContent,
              charactersContent,
              selectedOutline.content,
              ch.title,
              ch.summary,
              chWordCount,
              ch.index,
              selectedOutline.chapters.length,
            );
            generatedChapters.push({ index: ch.index, title: ch.title, content });
            setChapterProgress((prev) =>
              prev.map((p) => p.index === ch.index ? { ...p, status: 'done' } : p)
            );
          } catch (e: unknown) {
            const msg = e instanceof Error ? e.message : '生成失敗';
            setChapterProgress((prev) =>
              prev.map((p) => p.index === ch.index ? { ...p, status: 'error', errorMsg: msg } : p)
            );
            setError(`第 ${ch.index} 章生成失敗：${msg}`);
            setStep('select');
            return;
          }
        }
      } else {
        // Single story generation
        setNoChapterStatus('generating');
        try {
          const content = await generateStory(
            settings.dLlm,
            worldviewContent,
            charactersContent,
            selectedOutline.content,
            selectedOutline.wordCount,
          );
          setNoChapterStatus('done');
          generatedChapters = [{ index: 1, title: storyTitle, content }];
        } catch (e: unknown) {
          setNoChapterStatus('error');
          const msg = e instanceof Error ? e.message : '生成失敗';
          setError(`故事生成失敗：${msg}`);
          setStep('select');
          return;
        }
      }

      // Save story
      const saved = await storiesDB.create({
        outlineId: selectedOutline.id,
        title: storyTitle,
        chapters: generatedChapters,
      });
      setStories((prev) => [saved, ...prev]);
      setStep('done');
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : '發生未知錯誤');
      setStep('select');
    }
  };

  const fetchWorldviewContent = async (worldviewId: string): Promise<string> => {
    try {
      const wv = await worldviewsDB.getById(worldviewId);
      return wv ? `${wv.title}\n\n${wv.content}` : '（無世界觀資料）';
    } catch {
      return '（無世界觀資料）';
    }
  };

  const fetchCharactersContent = async (characterIds: string[]): Promise<string> => {
    try {
      const all = await charactersDB.getAll();
      const selected = all.filter((c) => characterIds.includes(c.id));
      return selected.map((c) => `${c.name}（${c.age}歲）：${c.background}`).join('\n\n') || '（無角色資料）';
    } catch {
      return '（無角色資料）';
    }
  };

  const handleDeleteStory = async (id: string) => {
    await storiesDB.delete(id);
    setStories((prev) => prev.filter((s) => s.id !== id));
  };

  const handleReset = () => {
    setStep('select');
    setSelectedOutlineId('');
    setChapterProgress([]);
    setNoChapterStatus('pending');
    setError('');
    setStoryTitle('');
    abortRef.current = false;
  };

  const generationDone = hasChapters
    ? chapterProgress.length > 0 && chapterProgress.every((c) => c.status === 'done')
    : noChapterStatus === 'done';

  const generationProgress = hasChapters && chapterProgress.length > 0
    ? Math.round((chapterProgress.filter((c) => c.status === 'done').length / chapterProgress.length) * 100)
    : (noChapterStatus === 'done' ? 100 : 0);

  return (
    <div className="min-h-full bg-stone-50 dark:bg-stone-950">
      {/* Header */}
      <div className="bg-white dark:bg-stone-900 border-b border-stone-200 dark:border-stone-700 px-8 py-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 flex items-center justify-center bg-violet-100 dark:bg-violet-900/40 rounded-xl">
            <i className="ri-quill-pen-line text-violet-600 dark:text-violet-400 text-xl" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-stone-800 dark:text-stone-100">故事生成</h1>
            <p className="text-stone-500 dark:text-stone-400 text-sm">由大綱驅動，AI 為你創作完整故事 · D LLM 驅動</p>
          </div>
          <span className="ml-auto bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-400 text-xs font-bold px-3 py-1.5 rounded-full">
            {stories.length} 部故事
          </span>
        </div>
      </div>

      <div className="px-8 py-6 space-y-8 max-w-5xl">
        {/* Generation Panel */}
        <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-700 overflow-hidden">
          <div className="flex items-center gap-3 px-6 py-4 border-b border-stone-100 dark:border-stone-800 bg-stone-50 dark:bg-stone-800/50">
            <div className="w-7 h-7 flex items-center justify-center bg-violet-100 dark:bg-violet-900/40 rounded-lg">
              <i className="ri-sparkling-line text-violet-600 dark:text-violet-400 text-sm" />
            </div>
            <h2 className="font-bold text-stone-700 dark:text-stone-200 text-sm">開始生成新故事</h2>
            {step === 'generating' && (
              <div className="ml-auto flex items-center gap-2 text-xs text-violet-600 dark:text-violet-400">
                <i className="ri-loader-4-line animate-spin" />
                <span>生成中 {generationProgress}%</span>
              </div>
            )}
            {step === 'done' && (
              <span className="ml-auto flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                <i className="ri-check-circle-line" /> 故事已生成
              </span>
            )}
          </div>

          <div className="p-6 space-y-5">
            {/* Step: Select */}
            {step === 'select' && (
              <>
                <div>
                  <h3 className="font-bold text-stone-800 dark:text-stone-100 mb-1">選擇故事大綱</h3>
                  <p className="text-sm text-stone-500 dark:text-stone-400 mb-4">選擇一份已規劃的大綱，AI 將依據世界觀、角色與情節大綱創作故事</p>
                  <OutlineSelectorForStory
                    outlines={outlines}
                    selectedId={selectedOutlineId}
                    onSelect={(id) => {
                      setSelectedOutlineId(id);
                      const outline = outlines.find((o) => o.id === id);
                      if (outline) setStoryTitle(outline.title);
                    }}
                  />
                </div>

                {selectedOutline && (
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-semibold text-stone-700 dark:text-stone-200 mb-2">
                        故事標題 <span className="text-red-400">*</span>
                      </label>
                      <input
                        value={storyTitle}
                        onChange={(e) => setStoryTitle(e.target.value)}
                        placeholder="為生成的故事命名..."
                        className="w-full px-4 py-3 border border-stone-200 dark:border-stone-600 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-violet-400 bg-white dark:bg-stone-800 dark:text-stone-100 dark:placeholder-stone-500"
                      />
                    </div>

                    {selectedOutline.chapters.length > 0 && (
                      <div className="bg-violet-50 dark:bg-violet-900/20 border border-violet-200 dark:border-violet-700 rounded-xl p-4">
                        <p className="text-xs font-semibold text-violet-700 dark:text-violet-400 mb-2 flex items-center gap-1">
                          <i className="ri-information-line" />
                          此大綱有 {selectedOutline.chapters.length} 個章節，AI 將逐章生成故事
                        </p>
                        <div className="space-y-1">
                          {selectedOutline.chapters.map((ch) => (
                            <div key={ch.index} className="flex items-center gap-2 text-xs text-stone-600 dark:text-stone-400">
                              <span className="w-12 flex-shrink-0 text-violet-500 dark:text-violet-400 font-medium">第 {ch.index} 章</span>
                              <span>{ch.title}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {error && (
                  <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-xl p-4 text-sm text-red-700 dark:text-red-400 flex gap-2">
                    <i className="ri-error-warning-line flex-shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="flex justify-end">
                  <button
                    onClick={handleStartGeneration}
                    disabled={!selectedOutlineId || !storyTitle.trim()}
                    className="flex items-center gap-2 px-7 py-3 bg-violet-500 hover:bg-violet-600 disabled:opacity-50 text-white rounded-xl font-medium text-sm transition-all cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-sparkling-line" /> 開始生成故事
                  </button>
                </div>
              </>
            )}

            {/* Step: Generating */}
            {step === 'generating' && selectedOutline && (
              <div className="space-y-5">
                <div className="flex items-center gap-3 p-4 bg-violet-50 dark:bg-violet-900/20 border border-violet-200 dark:border-violet-700 rounded-xl">
                  <div className="w-10 h-10 flex items-center justify-center bg-violet-100 dark:bg-violet-900/40 rounded-xl flex-shrink-0">
                    <i className="ri-quill-pen-line text-violet-600 dark:text-violet-400 text-xl" />
                  </div>
                  <div>
                    <p className="font-bold text-stone-800 dark:text-stone-100 text-sm">{storyTitle}</p>
                    <p className="text-xs text-stone-500 dark:text-stone-400">基於「{selectedOutline.title}」生成中...</p>
                  </div>
                </div>
                <ChapterGenerationProgress
                  chapters={chapterProgress}
                  isNoChapter={!hasChapters}
                  noChapterStatus={noChapterStatus}
                  wordCount={selectedOutline.wordCount}
                />
                {error && (
                  <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-xl p-4 text-sm text-red-700 dark:text-red-400 flex gap-2">
                    <i className="ri-error-warning-line flex-shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}
              </div>
            )}

            {/* Step: Done */}
            {step === 'done' && (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 flex items-center justify-center bg-emerald-100 dark:bg-emerald-900/40 rounded-2xl mx-auto">
                  <i className="ri-check-double-line text-emerald-600 dark:text-emerald-400 text-3xl" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-800 dark:text-stone-100 text-lg mb-1">故事生成完成！</h3>
                  <p className="text-stone-500 dark:text-stone-400 text-sm">「{storyTitle}」已儲存，可在下方閱讀</p>
                </div>
                <div className="flex justify-center gap-3">
                  <button
                    onClick={() => {
                      const newStory = stories[0];
                      if (newStory) setReadingStory(newStory);
                    }}
                    className="flex items-center gap-2 px-6 py-3 bg-violet-500 hover:bg-violet-600 text-white rounded-xl text-sm font-medium cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-book-read-line" /> 立即閱讀
                  </button>
                  <button
                    onClick={handleReset}
                    className="flex items-center gap-2 px-6 py-3 border border-stone-200 dark:border-stone-600 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 rounded-xl text-sm font-medium cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-add-line" /> 再生成一部
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Stories List */}
        <div>
          <h2 className="text-lg font-bold text-stone-800 dark:text-stone-100 mb-5">已生成的故事</h2>
          {!loaded ? (
            <div className="flex items-center justify-center py-16 text-stone-400 dark:text-stone-500">
              <i className="ri-loader-4-line animate-spin text-2xl mr-3" />
              <span>載入中...</span>
            </div>
          ) : stories.length === 0 ? (
            <div className="text-center py-16 text-stone-400 dark:text-stone-500">
              <div className="w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <i className="ri-quill-pen-line text-4xl" />
              </div>
              <p className="font-medium text-stone-500 dark:text-stone-400 mb-1">尚無故事</p>
              <p className="text-sm">選擇一份大綱，讓 AI 為你創作第一部故事吧！</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
              {stories.map((story) => {
                const outline = outlines.find((o) => o.id === story.outlineId);
                return (
                  <StoryCard
                    key={story.id}
                    story={story}
                    outline={outline}
                    onRead={(s) => setReadingStory(s)}
                    onDelete={handleDeleteStory}
                  />
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Story Reader Modal */}
      {readingStory && (
        <StoryReader
          story={readingStory}
          onClose={() => setReadingStory(null)}
        />
      )}
    </div>
  );
}
