import { useState, useRef } from 'react';
import type { Character, WorldView } from '../../../utils/db';

interface ParsedCharacter {
  name: string;
  age: string;
  background: string;
}

export function parseCharactersFromAI(text: string): ParsedCharacter[] {
  const results: ParsedCharacter[] = [];
  const sections = text.split(/(?:\n\s*(?:#{1,3}|\-{3,}|角色\s*\d+|第\s*\d+\s*個角色|\d+\s*[.、])\s*)/);

  for (const section of sections) {
    if (!section.trim()) continue;
    const nameMatch = section.match(/(?:姓名|名字|名稱)[：:]\s*(.+)/);
    const ageMatch = section.match(/(?:年齡|歲)[：:]\s*(.+)/);
    const bgMatch = section.match(/(?:身分|背景|描述|身份背景)[：:]\s*([\s\S]+?)(?=(?:姓名|名字|年齡|$))/);

    if (nameMatch) {
      results.push({
        name: nameMatch[1].trim(),
        age: ageMatch ? ageMatch[1].trim() : '不明',
        background: bgMatch ? bgMatch[1].trim() : section.trim(),
      });
    }
  }

  if (results.length === 0 && text.trim()) {
    results.push({ name: '未命名角色', age: '不明', background: text.trim() });
  }

  return results;
}

interface CharacterCardProps {
  char: Character;
  onKeep?: () => void;
  onDiscard?: () => void;
  onEdit?: (data: Partial<Character>) => void;
  onArchive?: () => void;
  onDelete?: () => void;
  isReviewing?: boolean;
}

export function CharacterCard({
  char,
  onKeep,
  onDiscard,
  onEdit,
  onArchive,
  onDelete,
  isReviewing,
}: CharacterCardProps) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(char.name);
  const [age, setAge] = useState(char.age);
  const [background, setBackground] = useState(char.background);
  const [isAddingTag, setIsAddingTag] = useState(false);
  const [newTagInput, setNewTagInput] = useState('');
  const tagInputRef = useRef<HTMLInputElement>(null);

  const currentTags = char.tags ?? [];

  const handleSave = () => {
    onEdit?.({ name, age, background });
    setEditing(false);
  };

  const handleAddTag = () => {
    const trimmed = newTagInput.trim();
    if (!trimmed) {
      setIsAddingTag(false);
      return;
    }
    if (currentTags.includes(trimmed)) {
      setNewTagInput('');
      setIsAddingTag(false);
      return;
    }
    onEdit?.({ tags: [...currentTags, trimmed] });
    setNewTagInput('');
    setIsAddingTag(false);
  };

  const handleRemoveTag = (tag: string) => {
    onEdit?.({ tags: currentTags.filter((t) => t !== tag) });
  };

  const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddTag();
    }
    if (e.key === 'Escape') {
      setIsAddingTag(false);
      setNewTagInput('');
    }
  };

  return (
    <div className="bg-white dark:bg-stone-800 rounded-2xl border border-stone-200 dark:border-stone-700 overflow-hidden hover:border-stone-300 dark:hover:border-stone-600 transition-all">
      {/* Header */}
      <div className="flex items-start justify-between px-5 py-4 border-b border-stone-100 dark:border-stone-700 bg-gradient-to-r from-stone-50 dark:from-stone-800/80 to-white dark:to-stone-800">
        <div className="flex items-start gap-3 min-w-0 flex-1">
          <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-900/40 flex items-center justify-center flex-shrink-0 mt-0.5">
            <i className="ri-user-3-line text-rose-500 dark:text-rose-400 text-lg" />
          </div>
          <div className="min-w-0 flex-1">
            {editing ? (
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="text-sm font-bold border border-amber-300 dark:border-amber-600 rounded-lg px-2 py-1 bg-amber-50 dark:bg-amber-900/30 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
            ) : (
              <h3 className="font-bold text-stone-800 dark:text-stone-100 text-base leading-tight">{char.name}</h3>
            )}

            {/* Tags row — single line, horizontally scrollable */}
            <div className="flex items-center gap-1.5 mt-1.5 overflow-x-auto no-scrollbar">
              {editing ? (
                <input
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="text-xs border border-amber-300 dark:border-amber-600 rounded px-2 py-0.5 bg-amber-50 dark:bg-amber-900/30 dark:text-stone-100 focus:outline-none w-24 flex-shrink-0"
                  placeholder="年齡"
                />
              ) : (
                <span className="whitespace-nowrap flex-shrink-0 text-xs text-stone-500 dark:text-stone-400 bg-stone-100 dark:bg-stone-700 px-2 py-0.5 rounded-full">
                  {char.age} 歲
                </span>
              )}
              {char.worldviewTitle && (
                <span className="whitespace-nowrap flex-shrink-0 text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/30 px-2 py-0.5 rounded-full">
                  {char.worldviewTitle}
                </span>
              )}
              {currentTags.map((tag) => (
                <span
                  key={tag}
                  className="whitespace-nowrap flex-shrink-0 inline-flex items-center gap-0.5 text-xs text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-900/30 px-2 py-0.5 rounded-full"
                >
                  #{tag}
                  {!isReviewing && (
                    <button
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-0.5 text-rose-400 dark:text-rose-500 hover:text-rose-700 dark:hover:text-rose-300 cursor-pointer leading-none"
                      title="移除標籤"
                    >
                      <i className="ri-close-line" style={{ fontSize: '10px' }} />
                    </button>
                  )}
                </span>
              ))}
              {!isReviewing && (
                isAddingTag ? (
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <input
                      ref={tagInputRef}
                      autoFocus
                      value={newTagInput}
                      onChange={(e) => setNewTagInput(e.target.value)}
                      onKeyDown={handleTagKeyDown}
                      placeholder="標籤名稱"
                      maxLength={12}
                      className="text-xs border border-rose-300 dark:border-rose-600 rounded-full px-2 py-0.5 w-20 focus:outline-none bg-white dark:bg-stone-700 dark:text-stone-100"
                    />
                    <button
                      onClick={handleAddTag}
                      className="whitespace-nowrap flex-shrink-0 text-xs text-teal-600 dark:text-teal-400 hover:text-teal-700 cursor-pointer font-medium"
                    >
                      ✓
                    </button>
                    <button
                      onClick={() => { setIsAddingTag(false); setNewTagInput(''); }}
                      className="whitespace-nowrap flex-shrink-0 text-xs text-stone-400 dark:text-stone-500 hover:text-stone-600 dark:hover:text-stone-300 cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsAddingTag(true)}
                    className="whitespace-nowrap flex-shrink-0 text-xs text-stone-400 dark:text-stone-500 hover:text-stone-600 dark:hover:text-stone-300 flex items-center gap-0.5 cursor-pointer px-1.5 py-0.5 rounded-full hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors"
                    title="添加自訂標籤"
                  >
                    <i className="ri-add-line" /> 標籤
                  </button>
                )
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 flex-shrink-0 ml-2">
          {!isReviewing && (
            <>
              <button
                onClick={() => setEditing(!editing)}
                className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-500 dark:text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 transition-colors cursor-pointer"
              >
                <i className="ri-pencil-line text-sm" />
              </button>
              {onArchive && (
                <button
                  onClick={onArchive}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-stone-100 dark:hover:bg-stone-700 text-stone-500 dark:text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 transition-colors cursor-pointer"
                  title="封存"
                >
                  <i className="ri-archive-line text-sm" />
                </button>
              )}
              {onDelete && (
                <button
                  onClick={onDelete}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-red-50 dark:hover:bg-red-900/30 text-stone-500 dark:text-stone-400 hover:text-red-600 dark:hover:text-red-400 transition-colors cursor-pointer"
                  title="刪除"
                >
                  <i className="ri-delete-bin-line text-sm" />
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Background */}
      <div className="px-5 py-4">
        <p className="text-xs font-semibold text-stone-500 dark:text-stone-400 uppercase tracking-wider mb-2">身分背景</p>
        {editing ? (
          <textarea
            value={background}
            onChange={(e) => setBackground(e.target.value)}
            rows={4}
            className="w-full text-sm text-stone-700 dark:text-stone-200 border border-amber-300 dark:border-amber-600 rounded-xl p-3 bg-amber-50 dark:bg-amber-900/20 focus:outline-none focus:ring-2 focus:ring-amber-400 resize-none leading-relaxed"
          />
        ) : (
          <p className="text-sm text-stone-600 dark:text-stone-300 leading-relaxed">{char.background}</p>
        )}

        {editing && (
          <div className="flex justify-end gap-2 mt-3">
            <button
              onClick={() => {
                setEditing(false);
                setName(char.name);
                setAge(char.age);
                setBackground(char.background);
              }}
              className="px-4 py-2 text-sm text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-700 rounded-lg cursor-pointer whitespace-nowrap"
            >
              取消
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 text-sm bg-amber-500 hover:bg-amber-600 text-white rounded-lg font-medium cursor-pointer whitespace-nowrap"
            >
              儲存
            </button>
          </div>
        )}
      </div>

      {/* Review Actions */}
      {isReviewing && (
        <div className="flex border-t border-stone-100 dark:border-stone-700">
          <button
            onClick={onDiscard}
            className="flex-1 flex items-center justify-center gap-2 py-3 text-sm text-stone-500 dark:text-stone-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-close-circle-line" /> 捨棄
          </button>
          <div className="w-px bg-stone-100 dark:bg-stone-700" />
          <button
            onClick={() => setEditing(!editing)}
            className="flex-1 flex items-center justify-center gap-2 py-3 text-sm text-stone-500 dark:text-stone-400 hover:text-amber-600 dark:hover:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-edit-line" /> 修改
          </button>
          <div className="w-px bg-stone-100 dark:bg-stone-700" />
          <button
            onClick={onKeep}
            className="flex-1 flex items-center justify-center gap-2 py-3 text-sm text-stone-500 dark:text-stone-400 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-900/20 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-check-line" /> 保留
          </button>
        </div>
      )}
    </div>
  );
}

interface CharacterListProps {
  characters: Character[];
  onUpdate: (id: string, data: Partial<Character>) => void;
  onDelete: (id: string) => void;
}

export function CharacterList({ characters, onUpdate, onDelete }: CharacterListProps) {
  if (characters.length === 0) {
    return (
      <div className="text-center py-16 text-stone-400 dark:text-stone-500">
        <div className="w-16 h-16 flex items-center justify-center mx-auto mb-3">
          <i className="ri-group-line text-4xl" />
        </div>
        <p className="font-medium">尚無角色</p>
        <p className="text-sm mt-1">在上方選擇世界觀並生成角色吧！</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
      {characters.map((char) => (
        <CharacterCard
          key={char.id}
          char={char}
          onEdit={(data) => onUpdate(char.id, data)}
          onArchive={() => onUpdate(char.id, { archived: true })}
          onDelete={() => onDelete(char.id)}
        />
      ))}
    </div>
  );
}

interface WorldviewSelectorProps {
  worldviews: WorldView[];
  selectedId: string;
  onSelect: (id: string) => void;
}

export function WorldviewSelector({ worldviews, selectedId, onSelect }: WorldviewSelectorProps) {
  if (worldviews.length === 0) {
    return (
      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-xl p-4 text-sm text-amber-800 dark:text-amber-300 flex gap-2">
        <i className="ri-information-line flex-shrink-0 mt-0.5" />
        <span>尚無世界觀，請先前往「世界觀創造」建立世界觀。</span>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {worldviews.map((wv) => (
        <button
          key={wv.id}
          onClick={() => onSelect(wv.id)}
          className={`text-left px-4 py-3 rounded-xl border-2 transition-all cursor-pointer ${
            selectedId === wv.id
              ? 'border-amber-500 bg-amber-50 dark:bg-amber-900/30'
              : 'border-stone-200 dark:border-stone-600 bg-white dark:bg-stone-800 hover:border-amber-300 dark:hover:border-amber-600'
          }`}
        >
          <p className="font-semibold text-sm text-stone-800 dark:text-stone-100 truncate">{wv.title}</p>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 line-clamp-2">{wv.content.slice(0, 80)}...</p>
        </button>
      ))}
    </div>
  );
}
