import { useState, useEffect } from 'react';
import { worldviewsDB, charactersDB, outlinesDB, type WorldView, type Character, type Outline } from '../../utils/db';
import ContentCard from '../../components/base/ContentCard';

type ArchiveType = 'worldviews' | 'characters' | 'outlines';

export default function ArchivePage() {
  const [activeTab, setActiveTab] = useState<ArchiveType>('worldviews');
  const [archivedWorldviews, setArchivedWorldviews] = useState<WorldView[]>([]);
  const [archivedChars, setArchivedChars] = useState<Character[]>([]);
  const [archivedOutlines, setArchivedOutlines] = useState<Outline[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    loadArchived();
  }, []);

  const loadArchived = async () => {
    try {
      const [wv, ch, out] = await Promise.all([
        worldviewsDB.getAll(),
        charactersDB.getAll(),
        outlinesDB.getAll(),
      ]);
      setArchivedWorldviews(wv.filter((w) => w.archived));
      setArchivedChars(ch.filter((c) => c.archived));
      setArchivedOutlines(out.filter((o) => o.archived));
    } catch {
      setLoaded(true);
    } finally {
      setLoaded(true);
    }
  };

  const restoreWorldview = async (id: string) => {
    await worldviewsDB.update(id, { archived: false });
    setArchivedWorldviews((prev) => prev.filter((w) => w.id !== id));
  };

  const restoreChar = async (id: string) => {
    await charactersDB.update(id, { archived: false });
    setArchivedChars((prev) => prev.filter((c) => c.id !== id));
  };

  const restoreOutline = async (id: string) => {
    await outlinesDB.update(id, { archived: false });
    setArchivedOutlines((prev) => prev.filter((o) => o.id !== id));
  };

  const tabs: { key: ArchiveType; label: string; count: number; icon: string }[] = [
    { key: 'worldviews', label: '世界觀', count: archivedWorldviews.length, icon: 'ri-earth-line' },
    { key: 'characters', label: '角色', count: archivedChars.length, icon: 'ri-user-3-line' },
    { key: 'outlines', label: '大綱', count: archivedOutlines.length, icon: 'ri-file-list-3-line' },
  ];

  const totalArchived = archivedWorldviews.length + archivedChars.length + archivedOutlines.length;

  return (
    <div className="min-h-full bg-stone-50 dark:bg-stone-950">
      <div className="bg-white dark:bg-stone-900 border-b border-stone-200 dark:border-stone-700 px-8 py-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 flex items-center justify-center bg-stone-200 dark:bg-stone-700 rounded-xl">
            <i className="ri-archive-line text-stone-600 dark:text-stone-300 text-xl" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-stone-800 dark:text-stone-100">封存箱</h1>
            <p className="text-stone-500 dark:text-stone-400 text-sm">被封存的世界觀、角色與大綱</p>
          </div>
          <span className="ml-auto bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-300 text-xs font-bold px-3 py-1.5 rounded-full">
            {totalArchived} 項已封存
          </span>
        </div>
      </div>

      <div className="px-8 py-6 max-w-5xl space-y-6">
        {/* Tabs */}
        <div className="flex gap-2 bg-stone-100 dark:bg-stone-800 p-1 rounded-xl w-fit">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                activeTab === t.key ? 'bg-white dark:bg-stone-700 text-stone-800 dark:text-stone-100' : 'text-stone-500 dark:text-stone-400 hover:text-stone-700 dark:hover:text-stone-200'
              }`}
            >
              <div className="w-4 h-4 flex items-center justify-center">
                <i className={`${t.icon} text-sm`} />
              </div>
              {t.label}
              {t.count > 0 && (
                <span className="bg-stone-200 dark:bg-stone-600 text-stone-600 dark:text-stone-300 text-xs px-1.5 py-0.5 rounded-full">{t.count}</span>
              )}
            </button>
          ))}
        </div>

        {!loaded ? (
          <div className="flex items-center justify-center py-16 text-stone-400 dark:text-stone-500">
            <i className="ri-loader-4-line animate-spin text-2xl mr-3" />
            <span>載入中...</span>
          </div>
        ) : (
          <div>
            {activeTab === 'worldviews' && (
              archivedWorldviews.length === 0 ? (
                <EmptyArchive label="封存的世界觀" />
              ) : (
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                  {archivedWorldviews.map((wv) => (
                    <ContentCard
                      key={wv.id}
                      title={wv.title}
                      content={wv.content}
                      badges={[{ label: '已封存', color: 'bg-stone-400' }]}
                      headerExtra={
                        <button
                          onClick={() => restoreWorldview(wv.id)}
                          className="flex items-center gap-1 px-3 py-1.5 text-xs text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-900/30 border border-teal-200 dark:border-teal-700 rounded-lg hover:bg-teal-100 dark:hover:bg-teal-900/50 cursor-pointer whitespace-nowrap"
                        >
                          <i className="ri-arrow-go-back-line" /> 還原
                        </button>
                      }
                    />
                  ))}
                </div>
              )
            )}
            {activeTab === 'characters' && (
              archivedChars.length === 0 ? (
                <EmptyArchive label="封存的角色" />
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                  {archivedChars.map((c) => (
                    <ContentCard
                      key={c.id}
                      title={`${c.name}（${c.age} 歲）`}
                      content={c.background}
                      badges={[{ label: '已封存', color: 'bg-stone-400' }, { label: c.worldviewTitle ?? '', color: 'bg-amber-500' }]}
                      headerExtra={
                        <button
                          onClick={() => restoreChar(c.id)}
                          className="flex items-center gap-1 px-3 py-1.5 text-xs text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-900/30 border border-teal-200 dark:border-teal-700 rounded-lg hover:bg-teal-100 dark:hover:bg-teal-900/50 cursor-pointer whitespace-nowrap"
                        >
                          <i className="ri-arrow-go-back-line" /> 還原
                        </button>
                      }
                    />
                  ))}
                </div>
              )
            )}
            {activeTab === 'outlines' && (
              archivedOutlines.length === 0 ? (
                <EmptyArchive label="封存的大綱" />
              ) : (
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                  {archivedOutlines.map((o) => (
                    <ContentCard
                      key={o.id}
                      title={o.title}
                      content={o.content}
                      badges={[{ label: '已封存', color: 'bg-stone-400' }]}
                      headerExtra={
                        <button
                          onClick={() => restoreOutline(o.id)}
                          className="flex items-center gap-1 px-3 py-1.5 text-xs text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-900/30 border border-teal-200 dark:border-teal-700 rounded-lg hover:bg-teal-100 dark:hover:bg-teal-900/50 cursor-pointer whitespace-nowrap"
                        >
                          <i className="ri-arrow-go-back-line" /> 還原
                        </button>
                      }
                    />
                  ))}
                </div>
              )
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function EmptyArchive({ label }: { label: string }) {
  return (
    <div className="text-center py-16 text-stone-400 dark:text-stone-500">
      <div className="w-14 h-14 flex items-center justify-center mx-auto mb-3">
        <i className="ri-inbox-line text-4xl" />
      </div>
      <p className="font-medium">沒有{label}</p>
      <p className="text-sm mt-1">封存的項目會出現在這裡</p>
    </div>
  );
}
