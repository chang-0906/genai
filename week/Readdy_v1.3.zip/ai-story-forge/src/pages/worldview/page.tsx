import { useState, useEffect } from 'react';
import { worldviewsDB, type WorldView } from '../../utils/db';
import { mockWorldviews } from '../../mocks/worldviews';
import { ManualCreation, AICreation, WorldviewList } from './components/WorldviewComponents';

type CreationMode = 'manual' | 'expand' | 'extract';

interface TabItem {
  key: CreationMode;
  label: string;
  icon: string;
  desc: string;
}

const tabs: TabItem[] = [
  { key: 'manual', label: '手動建立', icon: 'ri-edit-2-line', desc: '自行填寫世界觀的各項設定' },
  { key: 'expand', label: 'AI 延伸擴展', icon: 'ri-sparkling-line', desc: '提出想法，由 AI 延伸設計' },
  { key: 'extract', label: 'AI 從小說提取', icon: 'ri-scissors-cut-line', desc: '給 AI 一篇小說，自動提取世界觀' },
];

export default function WorldviewPage() {
  const [activeTab, setActiveTab] = useState<CreationMode>('manual');
  const [worldviews, setWorldviews] = useState<WorldView[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    loadWorldviews();
  }, []);

  const loadWorldviews = async () => {
    try {
      const all = await worldviewsDB.getAll();
      const active = all.filter((w) => !w.archived);
      if (active.length === 0 && !loaded) {
        // Seed mock data on first load
        await Promise.all(mockWorldviews.map((m) => worldviewsDB.create(m)));
        const seeded = await worldviewsDB.getAll();
        setWorldviews(seeded.filter((w) => !w.archived).sort((a, b) => b.createdAt - a.createdAt));
      } else {
        setWorldviews(active.sort((a, b) => b.createdAt - a.createdAt));
      }
    } catch {
      setWorldviews([]);
    } finally {
      setLoaded(true);
    }
  };

  const handleSaved = (wv: WorldView) => {
    setWorldviews((prev) => [wv, ...prev]);
  };

  const handleUpdate = async (id: string, data: Partial<WorldView>) => {
    await worldviewsDB.update(id, data);
    if (data.archived) {
      setWorldviews((prev) => prev.filter((w) => w.id !== id));
    } else {
      setWorldviews((prev) => prev.map((w) => (w.id === id ? { ...w, ...data } : w)));
    }
  };

  const handleDelete = async (id: string) => {
    await worldviewsDB.delete(id);
    setWorldviews((prev) => prev.filter((w) => w.id !== id));
  };

  return (
    <div className="min-h-full bg-stone-50 dark:bg-stone-950">
      {/* Page Header */}
      <div className="bg-white dark:bg-stone-900 border-b border-stone-200 dark:border-stone-700 px-8 py-6">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-10 h-10 flex items-center justify-center bg-amber-100 dark:bg-amber-900/40 rounded-xl">
            <i className="ri-earth-line text-amber-600 dark:text-amber-400 text-xl" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-stone-800 dark:text-stone-100">世界觀創造</h1>
            <p className="text-stone-500 dark:text-stone-400 text-sm">設定你故事世界的基礎背景 · 由 A LLM 驅動</p>
          </div>
          <span className="ml-auto bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400 text-xs font-bold px-3 py-1.5 rounded-full">
            {worldviews.length} 個世界觀
          </span>
        </div>
      </div>

      <div className="px-8 py-6 space-y-8 max-w-5xl">
        {/* Creation Panel */}
        <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-700 overflow-hidden">
          {/* Tabs */}
          <div className="flex border-b border-stone-200 dark:border-stone-700">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex-1 flex flex-col items-center gap-1 px-4 py-4 text-sm font-medium transition-all cursor-pointer whitespace-nowrap border-b-2 ${
                  activeTab === tab.key
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20'
                    : 'border-transparent text-stone-500 dark:text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-50 dark:hover:bg-stone-800'
                }`}
              >
                <div className="w-5 h-5 flex items-center justify-center">
                  <i className={`${tab.icon} text-base`} />
                </div>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Tab Description */}
          <div className="bg-stone-50 dark:bg-stone-800/50 px-6 py-3 border-b border-stone-100 dark:border-stone-800">
            <p className="text-sm text-stone-500 dark:text-stone-400 flex items-center gap-2">
              <i className="ri-lightbulb-line text-amber-500" />
              {tabs.find((t) => t.key === activeTab)?.desc}
            </p>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {activeTab === 'manual' && <ManualCreation onSaved={handleSaved} />}
            {activeTab === 'expand' && <AICreation mode="expand" onSaved={handleSaved} />}
            {activeTab === 'extract' && <AICreation mode="extract" onSaved={handleSaved} />}
          </div>
        </div>

        {/* Worldview List */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-stone-800 dark:text-stone-100">已建立的世界觀</h2>
            {worldviews.length > 0 && (
              <p className="text-sm text-stone-500 dark:text-stone-400">點擊卡片右上角可編輯或封存</p>
            )}
          </div>
          {loaded ? (
            <WorldviewList
              worldviews={worldviews}
              onUpdate={handleUpdate}
              onDelete={handleDelete}
            />
          ) : (
            <div className="flex items-center justify-center py-16 text-stone-400 dark:text-stone-500">
              <i className="ri-loader-4-line animate-spin text-2xl mr-3" />
              <span>載入中...</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
